﻿#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using System.Threading;
using System.IO;
#endregion

namespace GameNamev1
{
    /// <summary>
    /// Purpose: Main game code.  Runs, updates, and draws the game.
    /// An amalgmataion from the entire group.  Currently has general draw and update
    /// functions, with more to be added in the form of pause menus, a more interactive HUD,
    /// and other game management elements.
    /// </summary>
    public class Game1 : Game
    {
        #region Game1Attributes

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //Matthew Turcz 3/11 3/18 4/1 | Various variables for the game
        //Attributes
        protected Rocket rocketLauncher; //Axel's rocket launcher

        //Player character attributes
        public Player Axel;
        protected Texture2D axelTexture; //Axel, the player's character Texture2D
        protected Texture2D rocketArm;
        Texture2D rocketTexture;  

        //Generic enemy attributes - more to be added as other enemy types are developed
        protected Texture2D enemyTexture;
        protected Rectangle enemyRect;

        //Specialized melee enemy
        protected Enemy meleeEnemy; //The melee enemy
        public Texture2D meleeEnemyTexture; //The melee enemy's Texture2D
        protected Rectangle meleeEnemyRect; //The melee enemy's rectange
        protected int meleeHealth; //The ranged enemy's health 

        //Specialized ranged enemy
        protected Enemy rangedEnemy; //The ranged enemy
        protected Texture2D rangedEnemyTexture; //The ranged enemy's Texture2D
        protected Rectangle rangedEnemyRect; //The ranged enemy's rectangle
        protected int rangedHealth; //The ranged enemy's health
        Texture2D Bullet;

        //Melee Enemy Property
        public Texture2D MET
        {
            get { return meleeEnemyTexture; }
        }

        //Axel's Rocket launcher
        protected Texture2D normalRocketTexture; //The normal, fire ready, Texture2D
        protected Rectangle normalRocketRect; //Fire ready rocket's rectangle

        protected Texture2D firedRocketTexture; //The fired rocket's Texture2D
        protected Rectangle firedRocketRect; //The fired rocket's rectangle

        protected Texture2D missileTexture; //The missile's Texture2D
        protected Rectangle missileRect; //The missile's rectangle

        protected Texture2D axelWithRocketTexture; //Texture2D for Axel holding the rocket launcher
        protected Rectangle axelWithRocketRect; //Rectangle for Axel holding the rocket launcher

        // Background Image
        protected Texture2D background;

        //Terrain Attributes
        protected Texture2D terrTexture;
        protected Rectangle terrRect;
        protected Texture2D explosion;

        protected Texture2D ledgeTexture;
        protected Rectangle ledgeRect;

        protected Texture2D topTileTexture;
        protected Rectangle topTileRect;

        protected Texture2D bottomTileTexture;
        protected Rectangle bottomTileRect;

        //The game's font
        SpriteFont font;

        //added by Robert - 3/30

        //Data structures to manage terrain and enemies
        protected List<Terrain> terrainBlocks = new List<Terrain>();
        protected List<Enemy> enemies = new List<Enemy>();

        //Added by Robert - 4/8 for pause screen
        protected bool paused;
        protected Texture2D pauseScreen;
        private bool pausedFrame;
        protected Texture2D pauseButton;
        //Map attributes
        protected MapReader imTheMap;
        protected string mapPath; //the file path to the current map text file.  

        protected bool newLevel = true;  //boolean for later level switching
        Texture2D actualRocket;
        //Variables for the game controls. - Simon and Matt
        bool[] wasd = { false, false, false, false };
        string[] wasdStr = { "W", "A", "S", "D" };
        KeyboardState kState; //The state of the keyboard
        public bool menu = true;//if the game is in the menu
        public bool ingame = false;//if the game is actually playing
        bool test = true; //Test variable used for testing

        //Kenny's HUD properties
        private int health; // HUD test 
        private int timeRemaining; // HUD test
        private int frameCount; // HUD test

        private int invincibleCount; //invincible test
        protected Rectangle changer; //rectangle which can be used as a placeholder for manipulating other rectangles

        #endregion
        //New attributes - Map control variables
        #region menu control attributes

        private int levelNum;
        private int segmentNum;
        private bool mapChange;

        //New attributes - main menu control
        private bool mainMenu;
        private bool startButton = false;
        private bool levelsButton = false;
        private bool creditsButton = false;

        // new attributes - levels menu control
        private bool levelsMenu;
        private bool backButton_Levels = false;
        List<LevelButton> buttons = new List<LevelButton>();
        LevelButton theChosenOne;

        // new attributes - paused menu control
        private bool quitButton_Paused = false;

        // new attributes - credits menu control
        private bool creditsMenu = false;
        private bool backButton_Credits = false;

        #endregion
        public List<Terrain> surr;

        //Constructor
        public Game1()
            : base()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        //Methods
        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            this.IsMouseVisible = true;  //makes mouse cursor invisible in frame
            imTheMap = new MapReader(); //instantiates the map reader
            //Kenny's test for the HUD
            //health = 100;
            timeRemaining = 300;
            invincibleCount = 0;
            surr = new List<Terrain>();
            //testing map scroll
            levelNum = 0;
            segmentNum = 1;
            mapChange = false;
            mainMenu = true;
            levelsMenu = false;
            base.Initialize();
            //paused = false;
            string directory = Directory.GetCurrentDirectory();
            string[] files = Directory.GetFiles(directory);

            List<string> maps = new List<string>();
            int i = 0;
            foreach (string file in files)
            {
                string mapTest = file.Substring((file.Length) - 9, 3);
                mapTest = mapTest.ToUpper();

                if (mapTest == "MAP")
                {
                    string sub = file.Substring((file.Length) - 9, 5);
                    maps.Add(sub);
                    Console.WriteLine(maps[i]);
                    i++;
                }
            }

            // creates buttons for all READABLE maps in the Debug folder
            foreach (string map in maps)
            {
                LevelButton button = new LevelButton(map);
                buttons.Add(button);
            }

            //upon startup, level 1-1 will be selected
            theChosenOne = buttons[0];
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // TODO: use this.Content to load your game content here
            //Loads the various textures/content for the game.

            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            actualRocket = Content.Load<Texture2D>(GameVariables.missileImage);

            //Axel
            axelTexture = Content.Load<Texture2D>(GameVariables.axelImage);
            rocketArm = Content.Load<Texture2D>(GameVariables.normalRocketImage);
            enemyTexture = Content.Load<Texture2D>(GameVariables.meleeEnemyImage);
            //Rocket
            rocketTexture = Content.Load<Texture2D>(GameVariables.axelMissileImage);
            terrTexture = Content.Load<Texture2D>(GameVariables.platformBottom);
            explosion = Content.Load<Texture2D>(GameVariables.explosionPlaceholder);
            //Enemies
            rangedEnemyTexture = Content.Load<Texture2D>(GameVariables.rangedEnemyImage);
            meleeEnemyTexture = Content.Load<Texture2D>(GameVariables.meleeEnemyImage);
            //Environment
            topTileTexture = Content.Load<Texture2D>(GameVariables.platformTop);
            bottomTileTexture = Content.Load<Texture2D>(GameVariables.platformBottom);
            ledgeTexture = Content.Load<Texture2D>(GameVariables.platformLedge);
            // terrTexture = Content.Load<Texture2D>(GameVariables.platform1Image);
            //Font
            font = Content.Load<SpriteFont>(GameVariables.font);
            //Ranged Enemy Bullet
            Bullet = Content.Load<Texture2D>(GameVariables.rangedBullet);
            // load up background
            background = Content.Load<Texture2D>(GameVariables.background);
   


            //Fills the various game piece rectangles
            // axelRect = new Rectangle(50, 385, 50, 75);
            meleeEnemyRect = new Rectangle(400, 333, 75, 150);
            terrRect = new Rectangle(200, 200, 20, 20); //placeholder for initilization in map parameter


            //Creates the axel and enemy pieces
            Axel = new Player(new Rectangle(0, 0, 50, 75), axelTexture, rocketArm, actualRocket);

            Axel.R.Exp = explosion;
            //Added by Rober 4/8 for pause screen
            pauseScreen = new Texture2D(graphics.GraphicsDevice, 1, 1);
            pauseScreen.SetData(new Color[] { Color.White });

            //Buttons - added by Robert
            pauseButton = new Texture2D(graphics.GraphicsDevice, 1, 1);
            pauseButton.SetData(new Color[] { Color.White });
            //Map code for testing maps from text files 
            //- Robert
            mapPath = "mapTest" + levelNum + segmentNum + ".txt";
            imTheMap.ReadMap(mapPath, Axel, enemies, meleeEnemyRect, meleeEnemyTexture, terrainBlocks, terrRect, terrTexture, rangedEnemyTexture, Bullet);
        }
        #region Unload - not used
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }
        #endregion
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            // levelNum and segmentNum update based on the current level
            string lvlStr = theChosenOne.Name.Substring(3, 1);
            string segStr = theChosenOne.Name.Substring(4, 1);

            int.TryParse(lvlStr, out levelNum);
            int.TryParse(segStr, out segmentNum);

            kState = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                Exit();


            // will only check for pause if not in a menu (excluding pause screen)
            if (!mainMenu && !levelsMenu && !creditsMenu)
            { CheckPause(kState); }

            // this checks for scrolling between level panes
            if (Axel.Pos.X > GraphicsDevice.PresentationParameters.BackBufferWidth)
            {
                Axel.Pos = new Rectangle(400, Axel.Pos.Y, Axel.Pos.Width, Axel.Pos.Height);
                Axel.Dir = new Vector2(0, 0);

                for (int i = 0; i < buttons.Count; i++)
                {
                    if (theChosenOne == buttons[i])
                    {
                        LevelButton old = theChosenOne;
                        if (i != buttons.Count - 1)
                        {
                            theChosenOne = buttons[i + 1];
                            if (theChosenOne.Name.Substring(3, 1) != old.Name.Substring(3, 1))
                            {
                                timeRemaining = 300;
                                Axel.Health = 100;
                            }
                            break;
                        }
                            // if no more levels to play, brings player to credits screen and sets the level to 1-1
                        else { theChosenOne = buttons[0]; creditsMenu = true; break; }
                    }
                }

                // reads next map
                mapPath = theChosenOne.Name + ".txt";

                enemies = new List<Enemy>();
                terrainBlocks = new List<Terrain>();

                imTheMap.ReadMap(mapPath, Axel, enemies, enemyRect, meleeEnemyTexture, terrainBlocks, terrRect, terrTexture, rangedEnemyTexture, Bullet);

            }
            if (!mainMenu)
            {
                //  }
                if (!paused)
                {

                    // behavior on level select menu and buttons and Credits menu and buttons
                    #region levels menus contronls
                    if (levelsMenu)
                    {
                        MouseState state = Mouse.GetState();
                        Point mouseLocation = new Point(state.X, state.Y);

                        Rectangle window = new Rectangle(0, 0, 800, 600);
                        Rectangle back = new Rectangle(665, 420, 125, 55);

                        // creates locations for all buttons
                        List<Rectangle> buttLocations = new List<Rectangle>();

                        foreach (LevelButton butt in buttons)
                        {
                            Rectangle buttRect = butt.DetectionRectangle;
                            buttLocations.Add(buttRect);
                        }

                        // test all of the level buttons
                        foreach (Rectangle buttRect in buttLocations)
                        {
                            foreach (LevelButton button in buttons)
                            {
                                if (buttRect == button.DetectionRectangle)
                                {
                                    if (buttRect.Contains(mouseLocation))
                                    {
                                        // highlight blue if hoverd over
                                        button.Hovered = true;
                                        if (state.LeftButton == ButtonState.Pressed)
                                        {
                                            // if clicked, button is now chosen level
                                            theChosenOne = button;
                                        }
                                    }
                                    else
                                    {
                                        button.Hovered = false;
                                    }
                                }
                            }
                        }

                        // highlight chosen level and load that level up
                        foreach (LevelButton button in buttons)
                        {
                            button.Chosen = false;
                            if (theChosenOne == button)
                            {
                                button.Chosen = true;
                                imTheMap.ReadMap(button.Name + ".txt", Axel, enemies, enemyRect, enemyTexture, terrainBlocks, terrRect, terrTexture, rangedEnemyTexture, Bullet);
                            }
                        }


                        // test all of the level buttons
                        /*foreach (Rectangle buttRect in buttLocations)
                        {
                            foreach (LevelButton button in buttons)
                            {
                                if (buttRect == button.DetectionRectangle)
                                {
                                    if (buttRect.Contains(mouseLocation))
                                    {
                                        button.Hovered = true;
                                        if (state.LeftButton == ButtonState.Pressed)
                                        {
                                            theChosenOne = button;
                                        }
                                    }
                                    else
                                    {
                                        button.Hovered = false;
                                    }
                                }
                            }
                        }

                        // highlight chosen level and load that level up
                        foreach (LevelButton button in buttons)
                        {
                            button.Chosen = false;
                            if (theChosenOne == button)
                            {
                                button.Chosen = true;
                            }
                        }*/

                        // back button, to bring back to main menu
                        if (back.Contains(mouseLocation))
                        {
                            backButton_Levels = true;

                        }

                        if (window.Contains(mouseLocation) && !back.Contains(mouseLocation))
                        {
                            backButton_Levels = false;
                        }

                        // back button clicked
                        if (backButton_Levels && state.LeftButton == ButtonState.Pressed)
                        {
                            Thread.Sleep(100);
                            mainMenu = true;
                            levelsMenu = false;
                        }
                    }


                    // behavior on credits menu and buttons
                    else if (creditsMenu)
                    {
                        MouseState state = Mouse.GetState();
                        Point mouseLocation = new Point(state.X, state.Y);

                        Rectangle window = new Rectangle(0, 0, 800, 600);
                        Rectangle back = new Rectangle(665, 420, 125, 55);

                        // highlight button hovered over
                        if (back.Contains(mouseLocation))
                        {
                            backButton_Credits = true;
                        }

                        if (window.Contains(mouseLocation) && !back.Contains(mouseLocation))
                        {
                            backButton_Credits = false;
                        }

                        // back button clicked
                        if (backButton_Credits && state.LeftButton == ButtonState.Pressed)
                        {
                            Thread.Sleep(100);
                            mainMenu = true;
                            creditsMenu = false;
                        }
                    }
                    #endregion
                    else
                    {
                        //Game processing 
                        #region Game update
                        // check for invincibility
                        if (Axel.Invincible)
                        {
                            invincibleCount++;
                            if (invincibleCount == 180)
                            {
                                Axel.Invincible = false;
                                invincibleCount = 0;
                            }
                        }
                        frameCount++;
                        // decrease time by 1 every 60 frames
                        if (frameCount == 60)
                        {
                            timeRemaining--;
                            frameCount = 0;
                        }

                        //Checks for input, and then uses the Simon's basic collision detection to see what the Rocket has hit
                        Axel.input();

                        //Axel collision detection.  Gets the squares around Axel's current position (updated at the end of every frame)
                        //And adjusts him if needed
                        List<Terrain> surr = getSurrSquares();
                        Axel.cordCollision(surr);

                        //A simple system to detect if the player has fallen to their death | Matt Turcz 5/11
                        if (!mainMenu && !paused && !levelsMenu && !creditsMenu)
                        {
                            if ((Axel.fallCase1 == true || Axel.fallCase2 == true || Axel.fallCase3 == true || Axel.fall == true) && Axel.Pos.Y == 1000) //If all the fall death cases are true and the Pos.Y is at 1000, then the player has fallen and died.
                            {
                                Axel.Health = 0;
                            }

                            foreach (Enemy e in enemies)
                            {
                                if (enemies.Count != 0)
                                {
                                    if (Axel.R.IsColliding(e.Pos))
                                    {
                                        meleeHealth = e.Attacked(50);
                                        Axel.R.Exploded = true;
                                        Axel.fired = false;  //if the rocket collided with an enemy (thus disappearing), Axel can fire again

                                        if (e.Health == 0)
                                        {
                                            e.EnemyRectangle = new Rectangle(0, 0, 0, 0);
                                            e.Pos = new Rectangle(0, 0, 0, 0);
                                        }
                                    }
                                    if (Axel.IsColliding(e.Pos))
                                    {
                                        Axel.takeDamage(e.DamageOutput);
                                    }
                                    //Enemy collision detection - gets the surrounding squares (Adjusted for the enemies being larger)
                                    //And tests for collisions
                                    e.getCord();
                                    List<Terrain> enSurr = getSurrSquares(e);
                                    e.cordCollision(enSurr);
                                    //Has the melee enemy move - Matt's code || 4/8 if the melee enemy is not currently attacking then he is just doing his normal walking behavior
                                    if (!e.Projectile)
                                        e.NormalBehavior();
                                    else
                                    {
                                        e.Attack();
                                        if (Axel.Pos.Intersects(e.Bullet.Pos) && e.Fired)
                                        {
                                            Axel.Health -= 10;
                                            e.Fired = false;
                                        }
                                    }

                                }

                            }
                            foreach (Terrain element in terrainBlocks)
                            {
                                if (element.IsColliding(Axel.R.Pos))
                                {
                                    Axel.R.Exploded = true;
                                    Axel.fired = false;
                                }
                            }
                            //If the rocket exploded
                            if (Axel.R.Exploded)
                            {
                                //If axel hasn't rocketjumped and axel is close enough to the collision
                                if (Axel.R.Explode(Axel.Pos) >= 1 && Axel.RocketJump == false)
                                {
                                    //Gets the rocket's vector
                                    Axel.Rvector = new Vector2(Axel.R.Center.X - (Axel.Pos.X + Axel.Pos.Width / 2), (Axel.R.Center.Y - (Axel.Pos.Y + Axel.Pos.Height / 2)));
                                    Axel.RocketJump = true;
                                    Axel.Rvector = (Axel.Rvector / Axel.Rvector.Length()) * GameVariables.ROCKET_JUMP;
                                    //Sends Axel in the direction opposite the rocket's vector.  If the rocket is fired back, he goes forward
                                    Axel.Dir -= Axel.Rvector;
                                    //If axel is too close, he gets damaged
                                    if (Axel.R.Explode(Axel.Pos) == 1)
                                    {
                                        Axel.Health -= 10;
                                    }

                                }
                            }

                            //IF axel runs out of time, he dies
                            if (timeRemaining <= 0)
                            {
                                Axel.Health = 0;
                            }
                            //If he dies, the game is paused before going to the death screen
                            if (Axel.Health == 0)
                            {
                                paused = true;
                            }
                            //Updates Axel's position - uses a string for debugging if needed
                            string s = Axel.getCord();
                        #endregion
                        }

                        
                    }
                }
                #region pause screen behavior
                //behavior on pause screen and buttons
                else
                {
                    MouseState state = Mouse.GetState();
                    Point mouseLocation = new Point(state.X, state.Y);

                    Rectangle window = new Rectangle(0, 0, 800, 600);
                    Rectangle quit = new Rectangle(665, 420, 125, 55);

                    // highlight button hovered over
                    if (quit.Contains(mouseLocation))
                    {
                        quitButton_Paused = true;
                    }

                    if (window.Contains(mouseLocation) && !quit.Contains(mouseLocation))
                    {
                        quitButton_Paused = false;
                    }

                    // quit button clicked
                    if (quitButton_Paused && state.LeftButton == ButtonState.Pressed)
                    {
                        //Thread.Sleep(200);
                        Thread.Sleep(300);
                        mainMenu = true;
                        paused = false;
                        theChosenOne = buttons[0];
                    }
                #endregion
                }
            }

            // behavior on main menu and buttons
            #region menu controlls
            else
            {
                paused = false;

                // reset player health to 100 on main menu
                Axel.Health = 100;

                MouseState state = Mouse.GetState();
                Point mouseLocation = new Point(state.X, state.Y);

                // rectangles for buttons
                Rectangle start = new Rectangle(340, 100, 125, 55);
                Rectangle levels = new Rectangle(340, 200, 125, 55);
                Rectangle credits = new Rectangle(340, 300, 125, 55);
                Rectangle window = new Rectangle(0, 0, 800, 600);

                // highlight button hovered over, reacts to all buttons on main menu
                if (start.Contains(mouseLocation))
                {
                    startButton = true;
                    levelsButton = false;
                    creditsButton = false;
                }
                if (levels.Contains(mouseLocation))
                {
                    startButton = false;
                    levelsButton = true;
                    creditsButton = false;
                }
                if (credits.Contains(mouseLocation))
                {
                    startButton = false;
                    levelsButton = false;
                    creditsButton = true;
                }
                if (window.Contains(mouseLocation) && !start.Contains(mouseLocation) && !levels.Contains(mouseLocation) && !credits.Contains(mouseLocation))
                {
                    startButton = false;
                    levelsButton = false;
                    creditsButton = false;
                }

                // start button clicked, health goes to 100 (as a second safety measure) and time goes to 300. reads in the map selected
                if (startButton && state.LeftButton == ButtonState.Pressed)
                {
                    Thread.Sleep(100);
                    Axel.Health = 100;
                    timeRemaining = 300;

                    enemies = new List<Enemy>();
                    terrainBlocks = new List<Terrain>();

                    foreach (LevelButton button in buttons)
                    {
                        if (theChosenOne == button)
                        {
                            imTheMap.ReadMap(button.Name + ".txt", Axel, enemies, enemyRect, enemyTexture, terrainBlocks, terrRect, terrTexture, rangedEnemyTexture, Bullet);
                        }
                    }

                    Axel.Pos = new Rectangle(Axel.Pos.X, Axel.Pos.Y - 100, Axel.Pos.Width, Axel.Pos.Height);

                    mainMenu = false;


                }

                // levels button clicked, brings to Level Select screen
                if (levelsButton && state.LeftButton == ButtonState.Pressed)
                {
                    Thread.Sleep(100);
                    mainMenu = false;
                    levelsMenu = true;
                }

                // credits button clicked, brings to Credits screen
                if (creditsButton && state.LeftButton == ButtonState.Pressed)
                {
                    Thread.Sleep(100);
                    mainMenu = false;
                    creditsMenu = true;
                }
            #endregion
            }

                base.Update(gameTime);

            }
        

        //Both collision detection take more squares than the final algorithm checks, but the added squares were for debugging and 
        //for possible future additions
        #region player collision detection
        //Gets the squares around Axel.  It gets the squares in the form
        ///  TTT
        /// TAAAT
        /// TAAAT
        /// TAAAT
        /// TAAAT
        /// TTTTT
        ///  These squares will move Axel around in his cordCollision method
        ///  The cordinates are all relative to Axel's upper left corner, and he is assumed to be 80px tall and 6
        public List<Terrain> getSurrSquares()
        {
            List<Terrain> surroundings = new List<Terrain>();

            int cordX = Axel.cX;
            int cordY = Axel.cY;

            foreach (Terrain t in terrainBlocks)
            {
                //squares above axel
                if (t.getThis(cordX, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 1, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 2, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }


                //squares on Axel's middle sides
                    //Goes left then right for each row
                else if (t.getThis(cordX - 1, cordY) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 1) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 2) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 2) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 3) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 3) != null)
                {
                    surroundings.Add(t);
                }


                //Squares below axel

                if (t.getThis(cordX, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 1, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 2, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }
                if (t.getThis(cordX, cordY + 5) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 1, cordY + 5) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 2, cordY + 5) != null)
                {
                    surroundings.Add(t);
                }

            }
            //debugging purposes
            string testing = "";
            foreach (Terrain s in surroundings)
            {
                testing += "Cord X: " + s.cX + " Cord Y: " + s.cY + "\n";
            }
            surr = surroundings;
            return surroundings;
        }
        #endregion
        #region Enemy collision detection
        //Follows the same idea as axel's get surrounding squares, but adjusted for the enemy size
        public List<Terrain> getSurrSquares(Enemy en)
        {
            List<Terrain> surroundings = new List<Terrain>();

            int cordX = en.cX;
            int cordY = en.cY;

            foreach (Terrain t in terrainBlocks)
            {

                //squares above the enemy
                if (t.getThis(cordX - 1, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 1, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 2, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY - 1) != null)
                {
                    surroundings.Add(t);
                }

                //squares on Enemy's middle sides
                else if (t.getThis(cordX - 1, cordY) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 1) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 1) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 2) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 2) != null)
                {
                    surroundings.Add(t);
                }

                else if (t.getThis(cordX - 1, cordY + 3) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 3) != null)
                {
                    surroundings.Add(t);
                }

                if (t.getThis(cordX - 1, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 4) != null)
                {
                    surroundings.Add(t);
                }

                if (t.getThis(cordX - 1, cordY + 5) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 5) != null)
                {
                    surroundings.Add(t);
                }

                //Squares below the enemy
                if (t.getThis(cordX - 1, cordY + 6) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX, cordY + 6) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 1, cordY + 6) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 2, cordY + 6) != null)
                {
                    surroundings.Add(t);
                }
                else if (t.getThis(cordX + 3, cordY + 6) != null)
                {
                    surroundings.Add(t);
                }
            }
            //debugging test
            string testing = "";
            foreach (Terrain s in surroundings)
            {
                testing += "Cord X: " + s.cX + " Cord Y: " + s.cY + "\n";
            }
            surr = surroundings;
            return surroundings;
        }
        #endregion

        #region PauseMethods
        //Checks if the pause key has been pressed.  If it has, calls the pause game method
        protected void CheckPause(KeyboardState ks)
        {
            if (!pausedFrame && ks.IsKeyDown(Keys.Escape))
            {
                if (!paused)
                    PauseGame();
                else
                    UnPauseGame();
            }
            //This makes sure the game doesn't rapidly unpause and pause by holding down the escape key for more than
            //1/60th of a second
            pausedFrame = ks.IsKeyDown(Keys.Escape);
        }

        //Sets pause to tree, and sets paused frame to true
        protected void PauseGame()
        {
            paused = true;
            pausedFrame = true;
        }

        //Resets the pause variables, and sends the player to the main menu if they died
        protected void UnPauseGame()
        {
            paused = false;
            pausedFrame = false;
            if (Axel.Health == 0)
            {
                mainMenu = true;
            }
        }
        #endregion
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin(); //Begin 
            if (!mainMenu)
            {
                if (!paused)
                {
                    //draw the level select menu
                    #region level select screen
                    if (levelsMenu)
                    {
                        // title
                        spriteBatch.Draw(pauseScreen, graphics.GraphicsDevice.PresentationParameters.Bounds, Color.LightGray);
                        spriteBatch.DrawString(font, "Level Select", new Vector2(325, 15), Color.Red);
                        spriteBatch.Draw(rocketTexture, new Rectangle(320, 48, 155, 3), Color.Red);

                        // no buttons hovered over
                        if (!backButton_Levels)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Gray);
                            //                            spriteBatch.Draw(rocketTexture, new Rectangle(75, 175, 125, 55), Color.Gray);
                            //                            spriteBatch.Draw(rocketTexture, new Rectangle(225, 175, 125, 55), Color.Gray);
                        }

                        // back button hovered over
                        if (backButton_Levels)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Blue);

                        }

                        // always display "back" text and inner rectangle
                        spriteBatch.Draw(rocketTexture, new Rectangle(670, 425, 115, 45), Color.DarkGray);
                        spriteBatch.DrawString(font, "Back", new Vector2(698, 432), Color.Red);

                        // writes out "custom" if custom levels are present
                        foreach (LevelButton butt in buttons)
                        {
                            if (butt.Name.Substring(3, 1) == "4")
                            {
                                spriteBatch.DrawString(font, "Custom: ", new Vector2(533, 70), Color.Red);
                            }
                        }
                        // draw all of the loaded levels and their corresponding buttons
                        foreach (LevelButton butt in buttons)
                        {
                            butt.DrawButton(spriteBatch, rocketTexture, font);
                        }
                    }
                    // draw the credits
                    else if (creditsMenu)
                    {
                        spriteBatch.Draw(pauseScreen, graphics.GraphicsDevice.PresentationParameters.Bounds, Color.LightGray);
                        spriteBatch.DrawString(font, "Credits", new Vector2(355, 15), Color.Red);
                        spriteBatch.Draw(rocketTexture, new Rectangle(352, 48, 90, 3), Color.Red);

                        spriteBatch.DrawString(font, "Thank you for Playing!!!", new Vector2(250, 55), Color.LimeGreen);
                        spriteBatch.DrawString(font, "Robert Bailey", new Vector2(300, 110), Color.Blue);
                        spriteBatch.DrawString(font, "Kenneth Probeck", new Vector2(300, 160), Color.Blue);
                        spriteBatch.DrawString(font, "Matthew Turczmanovicz", new Vector2(300, 210), Color.Blue);
                        spriteBatch.DrawString(font, "Simon Voorhees", new Vector2(300, 260), Color.Blue);
                        spriteBatch.DrawString(font, "A Game By: Placeholder Productions", new Vector2(180, 330), Color.Blue);

                        // no buttons hovered over
                        if (!backButton_Credits)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Gray);
                        }

                        // back button hovered over
                        if (backButton_Credits)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Blue);
                        }

                        // always display "back" text and inner rectangle
                        spriteBatch.Draw(rocketTexture, new Rectangle(670, 425, 115, 45), Color.DarkGray);
                        spriteBatch.DrawString(font, "Back", new Vector2(698, 432), Color.Red);
                    }
                    #endregion
                    // draw the game
                    else
                    {
                        // draw the background
                        spriteBatch.Draw(background, new Rectangle(0, -100, 800, 600), Color.White);


                        //Draws each terrain in the array.  The enemy array is not implemented yet due to only one enemy being used currently
                        foreach (Terrain t in terrainBlocks)
                        {
                            t.Draw(spriteBatch);

                        }


                        // HUD backdrop - Kenny created the HUD
                        spriteBatch.Draw(rocketTexture, new Rectangle(0, 0, 800, 50), Color.Gray);
                        spriteBatch.Draw(rocketTexture, new Rectangle(5, 5, 790, 40), Color.LightGray);

                        // draw the current level (level # and pane)
                        spriteBatch.DrawString(font, "Level: " + levelNum + "-" + segmentNum, new Vector2(300, 8), Color.Red);



                        // HUD STATS
                        spriteBatch.DrawString(font, "Health: ", new Vector2(545, 8), Color.Red);
                        #region Health bar
                        // HEALTH BAR, depends on current health.  USes the rocket texture as a quick and dity way to draw the health bar in segments
                        if (Axel.Health == 100)
                            spriteBatch.Draw(rocketTexture, new Rectangle(770, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(770, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 90)
                            spriteBatch.Draw(rocketTexture, new Rectangle(755, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(755, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 80)
                            spriteBatch.Draw(rocketTexture, new Rectangle(740, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(740, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 70)
                            spriteBatch.Draw(rocketTexture, new Rectangle(725, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(725, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 60)
                            spriteBatch.Draw(rocketTexture, new Rectangle(710, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(710, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 50)
                            spriteBatch.Draw(rocketTexture, new Rectangle(695, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(695, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 40)
                            spriteBatch.Draw(rocketTexture, new Rectangle(680, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(680, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 30)
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 20)
                            spriteBatch.Draw(rocketTexture, new Rectangle(650, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(650, 10, 10, 29), Color.Red);
                        if (Axel.Health >= 10)
                            spriteBatch.Draw(rocketTexture, new Rectangle(635, 10, 10, 29), Color.Green);
                        else
                            spriteBatch.Draw(rocketTexture, new Rectangle(635, 10, 10, 29), Color.Red);
                        #endregion
                        // says you got a kill if hit detection from rocket to enemy is true, only works in top-left corner for a brief flash

                        Axel.Draw(spriteBatch);
                        foreach (Enemy e in enemies)
                        {
                            e.Draw(spriteBatch);
                            //stup - unsure how to complete until other enemy types are implemented (Robert)
                        }


                        // time counter
                        spriteBatch.DrawString(font, "Time: " + timeRemaining, new Vector2(10, 8), Color.Red);
                    }
                }
                //death and pause screen draw
                else
                {
                    // death screen, includes ascii art
                    if (Axel.Health == 0)
                    {
                        spriteBatch.Draw(pauseScreen, graphics.GraphicsDevice.PresentationParameters.Bounds, Color.DarkGray);
                        spriteBatch.DrawString(font, "YOU'RE DEAD, BROTHER!", new Vector2(230, 15), Color.Red);
                        spriteBatch.Draw(rocketTexture, new Rectangle(230, 48, 337, 3), Color.Red);
                        spriteBatch.DrawString(font, " (Press Escape to return to Main Menu)", new Vector2(152, 430), Color.Blue);
                        spriteBatch.DrawString(font, "o", new Vector2(375, 140), Color.Yellow);
                        spriteBatch.DrawString(font, "( T _ T )", new Vector2(342, 180), Color.Red);
                        spriteBatch.DrawString(font, "|    |", new Vector2(367, 220), Color.Red);
                        spriteBatch.DrawString(font, "/|    |\\", new Vector2(357, 250), Color.Red);
                        spriteBatch.DrawString(font, "/ \\   / \\", new Vector2(352, 280), Color.Red);
                        spriteBatch.DrawString(font, "\\ /", new Vector2(373, 310), Color.Red);
                    }

                    // normal pause screen
                    else
                    {
                        // title
                        spriteBatch.Draw(pauseScreen, graphics.GraphicsDevice.PresentationParameters.Bounds, Color.LightGray);
                        spriteBatch.DrawString(font, "PAUSED", new Vector2(355, 15), Color.Red);
                        spriteBatch.Draw(rocketTexture, new Rectangle(350, 48, 112, 3), Color.Red);
                        spriteBatch.DrawString(font, " (Press Escape to return to the action)", new Vector2(170, 60), Color.Blue);

                        // no buttons hovered over
                        if (!quitButton_Paused)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Gray);
                        }

                        // quit button hovered over
                        if (quitButton_Paused)
                        {
                            spriteBatch.Draw(rocketTexture, new Rectangle(665, 420, 125, 55), Color.Blue);
                        }

                        // always display "quit" text and inner rectangle
                        spriteBatch.Draw(rocketTexture, new Rectangle(670, 425, 115, 45), Color.DarkGray);
                        spriteBatch.DrawString(font, "QUIT", new Vector2(695, 432), Color.Red);
                    }
                }
            }
                // draw the Main Menu
            else
            {
                // title
                spriteBatch.Draw(pauseScreen, graphics.GraphicsDevice.PresentationParameters.Bounds, Color.LightGray);
                spriteBatch.DrawString(font, "Rocket Jump!!!", new Vector2(315, 15), Color.Red);
                spriteBatch.Draw(rocketTexture, new Rectangle(310, 48, 186, 3), Color.Red);

                // no buttons hovered over
                if (!startButton && !levelsButton && !creditsButton)
                {
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 100, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 200, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 300, 125, 55), Color.Gray);
                }

                // start button hovered over
                if (startButton)
                {
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 100, 125, 55), Color.Blue);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 200, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 300, 125, 55), Color.Gray);
                }

                // levels button hovered over
                if (levelsButton)
                {
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 100, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 200, 125, 55), Color.Blue);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 300, 125, 55), Color.Gray);
                }

                // credits button hovered over
                if (creditsButton)
                {
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 100, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 200, 125, 55), Color.Gray);
                    spriteBatch.Draw(rocketTexture, new Rectangle(340, 300, 125, 55), Color.Blue);
                }

                // always display "Start" "Levels" and "credits text and inner rectangles
                spriteBatch.Draw(rocketTexture, new Rectangle(345, 105, 115, 45), Color.DarkGray);
                spriteBatch.Draw(rocketTexture, new Rectangle(345, 205, 115, 45), Color.DarkGray);
                spriteBatch.Draw(rocketTexture, new Rectangle(345, 305, 115, 45), Color.DarkGray);

                spriteBatch.DrawString(font, "Start", new Vector2(372, 112), Color.Red);
                spriteBatch.DrawString(font, "Levels", new Vector2(365, 212), Color.Red);
                spriteBatch.DrawString(font, "Credits", new Vector2(360, 312), Color.Red);
            }

            spriteBatch.End(); //End

            base.Draw(gameTime);
        }
    }
}
