﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{
    //Terrain's not too special, and it's basic collision detection can be handled referring back to GamePiece.
    //However, we wanted to have this class active in case we decided to have special terrain actions
    public class Terrain : GamePiece
    {
        //Attributes
        private int corX;
        private int corY;
        public Color tcolor = Color.White;
        public int cX;
        public int cY;

        //Properties
        public int CorX
        {
            get { return corX; }
        }

        public int CorY
        {
            get { return corY; }
        }

        //Constructor - sets the x and y position, as well as the x and y coordinates
        //for the cordinnate collision methods.
        //The cordinates for the grid are cX and cY, and assume the screen is broken into a grid of 20x20 pixel squares
        //The x position is rounded down, the y position is rounded up
        public Terrain(Rectangle rect, Texture2D img, int xCor, int yCor)
            : base(rect, img)
        {
            corX = xCor;
            corY = yCor;
            double holdX = pos.X / 20;
            double holdY = pos.Y / 20;
            cX = (int)Math.Floor(holdX);
            cY = (int)Math.Ceiling(holdY);
        }
        //Draw
        public override void Draw(SpriteBatch spritebatch)
        {
            spritebatch.Draw(sprite, pos, tcolor);
        }



        //This allows tests so see if there is a terrain in a square, thus indirectly
        //referring to the square without needing to keep an indexed array, and assigns the positions
        //when needed
        //The only thing needed to get a terrain block is the predicted coordinate.
        //Uses object for debugging.  getThis wasn't needed anymore in the Player or enemy class, but stayed in Terrain
        public object getThis(int xPos, int yPos)
        {
            
            if (cX == xPos && cY == yPos)
            {
                return this;
            }
            else
            {
                return null;
            }
        }
    }
}