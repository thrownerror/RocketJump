﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{//created by Simon 3/11/15 Most recent edit: 
    public class GamePiece
    {//the basic class for all things being drawn to the screen

        protected Rectangle pos;//the position of the object
        protected Texture2D sprite;//the texture that is being drawn to the screen

        //Constructor 
        public GamePiece(Rectangle rect, Texture2D img)//parameretized constructor accepting a rectangle and a texture
        {
            pos = rect;
            sprite = img;
        }

        //Properties
        public Rectangle Pos
        {
            get { return pos; }
            set { pos = value; }
        }
        public Texture2D Sprite
        {
            get { return sprite; }
            set { sprite = value; }
        }

        //Draw Method
        public virtual void Draw(SpriteBatch spritebatch)
        {
            spritebatch.Draw(sprite, pos, Color.White);
        }

        //Collision Method
        public bool IsColliding(Rectangle gmpc)
        {

            if (pos.Intersects(gmpc))
                return true;
            return false;
        }
    }
}