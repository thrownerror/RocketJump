﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

using System.IO;
namespace GameNamev1
{
    //Written by Robert, current edition writen at 4/3/2015
    //Purpose: To read a map file (a basic .txt format) generated from the map tool.  This relies on the file
    //having set characteristics (may add a keyline at the start of each file as a basic test) for a proper analysis and
    //correct tile placement.
    //Caveats:  Currently places the mpa higher than intended on the game screen.  However, it preserves the intended shape
    //of the mapTest.txt file, albeit slightly squished.  This will be improved upon on future milestones, as well as adding correct enemy
    //placement, and possibly other types of tiles.
    public class MapReader//:Game1
    {
        //Attributes - mainly here for troubleshooting when needed
        private string mapRoute;  //file destination

        //reading position
        private int readingX; 
        private int readingY;
        private int xCor;
        private int yCor;
        //counts of the enemy, walls and terrain for double checking the arrays, currently not needed 
        //but preserved for testing
        //private int enemyCount;
        //private int terrainCount;
        //public int wallCount;

        //Checks to ensure only one player exists
        private bool playerExists;

        
        //Constructor
        public MapReader()
        {
            mapRoute = "";
            playerExists = false;
            string str = Directory.GetCurrentDirectory();
            //readingX and Y are set to 40 to allow room for the timer and health display at the top of the screen
            readingX = 0;
            readingY = 40;
            //enemyCount = 0;
            //terrainCount = 0;
            xCor = 0;
            yCor = 0;


        }

        //The core of the map reader class -takes the game pieces an Lists from Game to generate a new map screen.
        //The final goal is to have "scrolling" similar to megaman or Shovel knight, where there are active screens which change only 
        //when advancing to the next segment
        //Method
        public void ReadMap(string path, Player Axel, List<Enemy> enemies, Rectangle enemyRect, Texture2D enTextMelee,
            List<Terrain> terrainBlocks, Rectangle newTerr, Texture2D terrainTexture, Texture2D enTextRanged, Texture2D bullet)
        {

            //Generates the reader
            StreamReader reader;
            mapRoute = path;

            //If the file exists
            if (File.Exists(mapRoute))
            {
                //Completes the reader
                reader = new StreamReader(mapRoute);
                string read;
                char[] characters;

                //The line is turned into a character array, and then navigated usinga for loop
                while ((read = reader.ReadLine()) != null)
                {
                    characters = read.ToCharArray();
                    for (int i = 0; i < characters.Length; i++)
                    {

                        //All placement follows the same loop - a new rectangle is generated using
                        //the readingX and readingY positions, and then a new character is created using
                        //the new rectangle and the passed in texture for each type.
                        //Axel is the only exception, as his rectangle changes, but a new Axel is not generated
                        //This code navigates the screen as if it was a 40x20 grid of 20px x 20px squares

                        //Generates the player at the position of the P in the map file.
                        if (characters[i] == 'P')
                        {
                            //But only if the player hasn't already been placed
                                Rectangle newAxel = Axel.Pos;
                                newAxel.X = readingX;
                                newAxel.Y = readingY;
                                Axel.Pos = newAxel;
                        }

                        //Generates the position of the melee enemy
                        if (characters[i] == 'E')
                        {
                            Rectangle newEnemy = enemyRect;
                            enemyRect.X = readingX;
                            enemyRect.Y = readingY;
                            enemyRect.Width = 60;
                            enemyRect.Height = 120;
                            enemies.Add(new Enemy(enemyRect, enTextMelee));
                        }
                        //Generate sthe position of the gun enemy
                        if (characters[i] == 'G')
                        {
                            Rectangle newEnemy = enemyRect;
                            enemyRect.X = readingX;
                            enemyRect.Y = readingY;
                            enemyRect.Width = 60;
                            enemyRect.Height = 120;
                            enemies.Add(new Enemy(enemyRect, enTextRanged, bullet));
                        }

                        //Generates the position of the walls - both the wall analysis and enemy analysis add the new object
                        //to it's respective array
                        if (characters[i] == '#')
                        {
                            Rectangle terr = newTerr;
                            newTerr.X = readingX;
                            newTerr.Y = readingY;
                            Terrain terrainS = new Terrain(newTerr, terrainTexture, xCor, yCor);
                            terrainBlocks.Add(terrainS);
                        }
                        if (characters[i] == ' ')
                        {
                            //creates a blank space
                        }
                        //increase the readingX by 20px on the screen, or one square on the map tool
                        readingX += 20;
                        xCor++;
                    }
                    //At this point, the line is finished.  Advances the Y position, and resets the X
                    readingX = 0;
                    readingY += 20;
                    yCor++;
                }

            }
            //resets the readingX and readingY for the next screen, as well as the player exists boolean
            readingX = 0;
            readingY = 40;
            playerExists = false;
        }
    }
}