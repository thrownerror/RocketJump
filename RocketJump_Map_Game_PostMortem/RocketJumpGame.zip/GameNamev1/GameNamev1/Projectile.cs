﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{
    //Purpose: A subclass of movableGamePieces, this will likely be used for special functions for enemy projectiles
    //The rocket was decided to be too specific to be placed in here with enemy weapons.
    public class Projectile:MovableGamePiece
    { 
        //Constructor
        public Projectile(Rectangle rect, Texture2D img, Vector2 dir)
            : base(rect, img, dir)
        {

        }
    }
}
