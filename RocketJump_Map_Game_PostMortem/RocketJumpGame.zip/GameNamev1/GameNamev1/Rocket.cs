﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{//Purpose: Manages Axel's rocket.  Will eventually determine the rocket jumping radius, and have damage traits.
    //Currently, only has a basic form of collision detection.
    //4/3/15
    public class Rocket : Projectile
    {
        //Attributes
        bool exploded = false;
        int inner = 30;
        int outer = 60;
        int timer = 0;
        public bool flipped;
        Texture2D exp;
        int offset = 0;
        Vector2 center;//the center of the explosion
        //Constructor
        public Rocket(Rectangle rect, Texture2D img, Vector2 dir)
            : base(rect, img, dir)
        {
            center = new Vector2(pos.X + pos.Width, pos.Y + pos.Height);
        }
        //Properties
        public bool Exploded
        {
            get { return exploded; }
            set { exploded = value; }
        }
        public Texture2D Exp
        {
            get { return exp; }
            set { exp = value; }
        }
        public Vector2 Center
        {
            get { return center; }
        }
        //Draw
        //Basic draw method implemented by Simon
        public override void Draw(SpriteBatch spritebatch)
        {
            if (exploded == false)
            {
                if(!flipped)
                    spritebatch.Draw(sprite, pos, new Rectangle(offset, 0, 20, 10), Color.White, (float)Math.Atan(dir.Y / dir.X), new Vector2(sprite.Width / 2, sprite.Height / 2), SpriteEffects.None, 0f);
                else
                    spritebatch.Draw(sprite, pos, new Rectangle(offset, 0, 20, 10), Color.White, (float)Math.Atan(dir.Y / dir.X), new Vector2(sprite.Width / 2, sprite.Height / 2), SpriteEffects.FlipHorizontally, 0f);
                if (offset == 20)
                    offset = 0;
                else
                    offset = 20;
            }
            else
            {
                spritebatch.Draw(exp, new Vector2(pos.X - 40, pos.Y - 40));
                timer++;
                if (timer > 5)
                {
                    exploded = false;
                    timer = 0;
                    pos.X = -20;
                }
            }
        }
        //Method
        public int Explode(Rectangle rect)
        {
            center = new Vector2(pos.X + pos.Width, pos.Y + pos.Height);
            //checks if the rectangle is within the inner explosion
            if ((Math.Abs(rect.X +rect.Width/2 - center.X) <= inner &&
                Math.Abs(rect.Y +rect.Height/2 - center.Y) <= inner))
            {
                return 1;
            }
            //checks if the rectangle is within the outer explosion
            else if ((Math.Abs(rect.X +rect.Width/2 - center.X) <= outer &&
                Math.Abs(rect.Y +rect.Height/2 - center.Y) <= outer))
            {
                return 2;
            }
            return 0;
        }
    }
}