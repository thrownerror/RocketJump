﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameNamev1
{
    //Created by Matthew Tuczmanovicz | 3/11/15 Updated 3/18 & 4/1 & 5/12
    class GameVariables //This class contains the various variables in the game. It can be used to easily change the values of specific game variables.
    {
        //Gravity!
        public const double GRAVITY = -0.25;
        //This is the death elevation. If Axel reaches a y position of 1000, then he has died! 
        public const int ELEVATION = 1000;

        //Movement Speeds
         public static int axelWalkSpeed = 3;
         public static int axelJumpSpeed = 10;


        public static int axelRocketSpeed = 20;
        public static int rangedEnemyBulletSpeed = 12;

 
         public const int ROCKET_JUMP = 15;
 
        //Axel Images
        public static string axelMissileImage = "Rocket/Dummy"; //Rocket missile placeholder
        public static string axelImage = "Axel/axelBluebot"; //Axel's image in the game
        public static string normalRocketImage = "Axel/axelBlueBotRocket"; //Rocket loaded with the missile, ready for fire
        public static string firedRocketImage = "Axel/axelBlueBotFiredRocket"; //Rocket without the missle, it has just been fired.
        public static string missileImage = "Rocket/rocket"; //The rocket's missle | for some reason it does not work, needs to be fixed
        public static string axelWithRocketImage = "Axel/axelBlueBot"; //Axel with a rocket launcher

        //Enemies Images
        public static string meleeEnemyImage = "Enemies/melee_enemy"; //Basic melee-based enemey
        public static string rangedEnemyImage = "Enemies/ranged_enemy"; //The ranged-based enemy
        public static string rangedBullet = "Enemies/spinning_bullet_thang"; //The ranged enemy's bullet

        //Environment
        public static string platform1Image = "Environment/blackSquare"; //Test tile 
        public static string platformLedge = "Environment/ledge";
        public static string platformTop = "Environment/ground_tile_top";
        public static string platformBottom = "Environment/ground_tile_lower";
        public static string background = "Environment/rocket_jump_background"; //The game's background
 
         //Text font 
         public static string font = "Arial";

        //Placeholder Images
        public static string axelImagePlaceholder = "Axel/PlayerPlaceholder";
        public static string enemy1ImagePlaceholder = "Enemies/EnemyPlaceholder";
        public static string explosionPlaceholder = "Rocket/explosion_placeholder";
    }
}