﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


/*Purpose: Manages the general enemy classes.  More behaviors or traits may be added
for new enemy classes as devolpment continues.  Inherits from the MovableGamePiece
 * Date: 4/3/15
 */
namespace GameNamev1
{
    public class Enemy : MovableGamePiece
    {
        //Attributes
        //basic enemy rectangle and texture
        Rectangle enemyRectangle;
        Texture2D enemyTexture;
        int num = 0;
        int health = 100;
        int interval = 50;
        Texture2D bullet;
        Projectile bul;
        bool projectile;
        bool fired;

        //Coordinate system variables
        public int cX;
        public int cY;
        int moveControl;

        //Properties
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public Rectangle EnemyRectangle
        {
            get { return enemyRectangle; }
            set { enemyRectangle = value; }
        }

        public bool Projectile
        {
            get { return projectile; }
        }
        public Projectile Bullet
        {
            get { return bul; }
        }
        public bool Fired
        {
            get { return fired; }
            set { fired = value; }
        }

        // attribute, damageOutput
        private int damageOutput;

        //Property for damageOutput
        public int DamageOutput
        {
            get { return damageOutput; }
        }
        //constructor for the melee enemy
        public Enemy(Rectangle rect, Texture2D img)
            : base(rect, img, new Vector2(0, 0))
        {
            enemyRectangle = rect;
            enemyTexture = img;
            damageOutput = 40;
            moveControl = 0;
            projectile = false;
        }
        //the constructor for the ranged enemy class. accepts a bullet texture
        public Enemy(Rectangle rect, Texture2D img, Texture2D bullet)
            : base(rect, img, new Vector2(0, 0))
        {
            enemyRectangle = rect;
            enemyTexture = img;
            damageOutput = 20;
            projectile = true;
            moveControl = 0;
            this.bullet = bullet;
            fired = false;
            bul = new Projectile(new Rectangle(pos.X, pos.Y + 50, 10, 10), bullet, new Vector2(-5, 0));
        }

        //Matthew Turcz | 4/1/15
        //Methods
        public void NormalBehavior() //A very basic move pattern for the enemies  Currently just the enemy pacing
            //Originally, had the enemy move for a set time, controlled by interating moveControl.  This was changed with collision detection
        {
            if (!projectile)  //projectile enemies do not move, they need time to aim
            {
                if (moveControl > 60 && moveControl <= 120)
                {
                    pos.X -= GameVariables.axelWalkSpeed;

                }
                if (moveControl >= 0 && moveControl <= 60)
                {
                    pos.X += GameVariables.axelWalkSpeed;

                }
                if (moveControl > 120)
                {
                    moveControl = 0;
                }
            }
            else
            {
                Attack();
            }
        }

        //Matthew Turcz | 3/18
        public void Attack() //Method for the enemy attack AI - ranged enemies attack, melee enemies just charge with no AI
        {

            if (interval >= 150)// if enough time has elapsed, fire
            {
                interval = 0;
                bul.Pos = new Rectangle(pos.X, pos.Y + 50, 10, 10);
                fired = true;
            }
            if (fired)//moves the bullet
                bul.Move();
            interval++;
        }

        public int Attacked(int damage) //Method for dealing with the player attacking enemies
        {
            health -= damage;
            if (health <= 0)
            {
                health = 0;
            }

            return health;
        }
        //Draw
        new public virtual void Draw(SpriteBatch spritebatch)
        {

            if (projectile && fired)// if its a ranged enemy draw the bullet
                bul.Draw(spritebatch);

            spritebatch.Draw(sprite, pos, Color.White);

        }

        //Get the coordinates for the collision method
        //The coordinates work by dividing the screen into a grid of 20x20 squares.
        //The cordinate is the square that starts from the upper left hand corner of the enemy
        //Rounded down to nearest y, up to nearest x
        //Returns a string for debuggin purposes

        public string getCord()
        {
            int cordX;
            int cordY;

            double holdX;
            double holdY;
            //Divides the pixel position by 20, rounds down, and then casts into the x cordinate
            holdX = pos.X / 20;
            holdX = Math.Ceiling(holdX);
            cordX = (int)holdX;

            //Divides the pixel position by 20, rounds up, and then casts into the y cordinate

            holdY = (pos.Y) / 20;
            holdY = Math.Floor(holdY);
            cordY = (int)holdY;
            cX = cordX;
            cY = cordY;
            return "X: " + cordX + " Y: " + cordY;
        }

        //Collision Method - similar to Axel's, but only checks the left and right extremes.
        //If the enemy would collide with a wall or walk off the edge, they move in the opposite direction
        public void cordCollision(List<Terrain> surroundings)
        {
            
            bool rightBorder = false;
            bool leftBorder = false;
            foreach (Terrain t in surroundings)
            {
                //LEFT EXTREME - checks the squares to the Enemy's left
                if (t.cX <= this.cX - 1)
                {

                    //LEFT HEAD
                    if (t.cY == this.cY)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {

                            pos.X += GameVariables.axelWalkSpeed;
                            moveControl = 0;
                        }
                        leftBorder = true;

                    }
                    //LEFT CHEST
                    if (t.cY == this.cY + 1)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {

                            pos.X += GameVariables.axelWalkSpeed;
                            moveControl = 0;

                        }
                        leftBorder = true;

                    }
                    //LEFT SHIN
                    if (t.cY == this.cY + 2)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {

                            pos.X += GameVariables.axelWalkSpeed;
                            moveControl = 0;


                        }
                        leftBorder = true;

                    }
                    //LEFT FOOT
                    if (t.cY == this.cY + 5)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {

                            pos.X += GameVariables.axelWalkSpeed;
                            moveControl = 0;

                        }
                        leftBorder = true;

                    }
                    //LOWER LEFT
                    if (t.cY == this.cY + 6)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {

                        }
                        leftBorder = true;

                    }
                }

                //RIGHT EXTREME (column 5)
                if (t.cX == this.cX + 3)
                {
                    //RIGHT HEAD
                    if (t.cY == this.cY)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            pos.X -= GameVariables.axelWalkSpeed;
                            moveControl = 70;

                        }
                        rightBorder = true;
                    }
                    //RIGHT CHEST
                    if (t.cY == this.cY + 1)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            pos.X -= GameVariables.axelWalkSpeed;
                            moveControl = 70;

                        }
                        rightBorder = true;

                    }
                    //RIGHT SHIN
                    if (t.cY == this.cY + 2)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            pos.X -= GameVariables.axelWalkSpeed;
                            moveControl = 70;


                        }
                        rightBorder = true;

                    }
                    //RIGHT FOOT
                    if (t.cY == this.cY + 5)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            pos.X -= GameVariables.axelWalkSpeed;
                            moveControl = 70;

                        }
                        rightBorder = true;

                    }
                    //LOWER RIGHT
                    if (t.cY == this.cY + 6)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {

                        }
                        rightBorder = true;
                    }
                }

            }
            //If the left border was never set to true, then the enemy has hit the border, and no longer
            //has space to move in that direction.  the enemy moves right by setting the number within the 0-60 range
            if (!leftBorder && (moveControl >= 60 && moveControl <= 120))
            {
                moveControl = 10;
            }
            //If the right border was never set to true, then the enemy has hit the border, and no longer
            //has space to move in that direction.  the enemy moves left by setting the number within the 60-120 range
            if (!rightBorder && (moveControl >= 0 && moveControl < 60))
            {
                moveControl = 70;
            }
        }
    }
}