﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.GamerServices;


namespace GameNamev1
{
    // this class is to represent and generate buttons based on the map files present in the Debug folder
    class LevelButton
    {
        // attributes
        private string name;
        private bool hovered;
        private bool chosen;

        // rectangle for hovering / choosing
        private Rectangle detectionRectangle;

        // properties
        public string Name { get { return name; } }
        public Rectangle DetectionRectangle { get { return detectionRectangle; } }
        public bool Hovered { get { return hovered; } set { hovered = value; } }
        public bool Chosen { get { return chosen; } set { chosen = value; } }

        // constructor
        public LevelButton(string file)
        {
            name = file;

            string level = name.Substring(3, 1);
            string pane = name.Substring(4, 1);

            int levelNum = 0;
            int levelPane = 0;

            int.TryParse(level, out levelNum);
            int.TryParse(pane, out levelPane);

            detectionRectangle = new Rectangle(140 * levelNum - 40, 70 * levelPane + 40, 125, 55);
        }

        // DrawButton method
        public void DrawButton(SpriteBatch spritebatch, Texture2D rocketTexture, SpriteFont font)
        {
            string level = name.Substring(3, 1);
            string pane = name.Substring(4, 1);

            int levelNum = 0;
            int levelPane = 0;

            int.TryParse(level, out levelNum);
            int.TryParse(pane, out levelPane);

            // draws depending on the button is chosen, hovered, or neither
            if (chosen) { spritebatch.Draw(rocketTexture, detectionRectangle, Color.Green); }
            else if (hovered) { spritebatch.Draw(rocketTexture, detectionRectangle, Color.Blue); }
            else { spritebatch.Draw(rocketTexture, detectionRectangle, Color.Gray); }


            // even seperates level numbers and pane numbers
            spritebatch.Draw(rocketTexture, new Rectangle(140 * levelNum - 35, 70 * levelPane + 45, 115, 45), Color.DarkGray);
            if (name.Substring(3, 1) == "1")
            {
                spritebatch.DrawString(font, name.Substring(3, 1) + "-" + name.Substring(4, 1), new Vector2(150 * levelNum - 5, 70 * levelPane + 52), Color.Red);
            }
            else if (name.Substring(3, 1) == "2")
            {
                spritebatch.DrawString(font, name.Substring(3, 1) + "-" + name.Substring(4, 1), new Vector2(150 * levelNum -15, 70 * levelPane + 52), Color.Red);
            }
            else if (name.Substring(3, 1) == "3")
            {
                spritebatch.DrawString(font, name.Substring(3, 1) + "-" + name.Substring(4, 1), new Vector2(150 * levelNum - 25, 70 * levelPane + 52), Color.Red);
            }
            else if (name.Substring(3, 1) == "4")
            {
                spritebatch.DrawString(font, name.Substring(3, 1) + "-" + name.Substring(4, 1), new Vector2(150 * levelNum - 35, 70 * levelPane + 52), Color.Red);
            }
        }
    }
}
