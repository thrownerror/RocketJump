﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{
    //Purpose: Parent class for all moving pieces in Rocket Jump.  Manages the basic vector direction for possible special squares/enemies 
    //and has the base move method.  4/3/15

    public class MovableGamePiece : GamePiece
    {//created by Simon 3/11/15 Most recent edit:
        //Attribute 
        protected Vector2 dir;//a vector2 for direction to accomadate jumping for the player and the full range of the mouse
        //Property
        public Vector2 Dir
        {
            get { return dir; }
            set { dir = value; }
        }
        //Constructor
        public MovableGamePiece(Rectangle rect, Texture2D sprite, Vector2 direction)//adds the direction vector to the parameretized constructor of the parent class
            : base(rect, sprite)
        {
            dir = direction;
        }
        //Method
        public void Move()//adds the direction to the x and y of the position rectangle
        {
            pos.X += (int)dir.X;
            pos.Y += (int)dir.Y;
        }
    }
}
