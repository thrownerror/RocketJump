﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;


namespace GameNamev1
{
    //Purpose - this class manages the Player Character Axel, including input processing and whether or not
    //the player can fire again
    //Caveats - collision detection does not currently work for axel with objects in the screen
    public class Player : MovableGamePiece
    {
        //Attributes
        public KeyboardState kState;
        //       public Rectangle axelRectangle;
        //       Texture2D axelTexture;
        Texture2D rocketTexture;
        Texture2D rocketArm;
        public bool flipped;//a boolean to check if the player is facing left or right. true for left false for right
        bool[] wasd = { false, false, false, false };
        string[] wasdStr = { "W", "A", "S", "D" };
        bool isJump;
        public bool fired = false;
        public Rocket R;//the rocket the player fires
        public Vector2 Rvector;
        bool rocketJump = false;//a boolean to see if the player has rocketjumped
        private int health;
        private bool invincible;
        private int flicker = 0;
        public int axelElevation = GameVariables.ELEVATION;//the elevation of the player used to reset variables
        int jump = GameVariables.axelJumpSpeed;//how high the player jumps
        public bool fall;//a boolean to check if the player is in the air
        int interval = 0;//used to check how recently he fired the rocket
        int walkInterval = 0;//used to time his walk animation
        int offset = 0;//used to move through the spritesheet

        //Cases for falling. If none of the bottom box collision cases are false, then the player has fallen to their death. | Matt Turcz 5/11
        public bool fallCase1;
        public bool fallCase2;
        public bool fallCase3;

        //coordinate properties
        public int cX;
        public int cY;
        //Properties - Kenny 4/8
        public int Health
        {
            get { return health; }
            set
            {
                if (value > 100) // no health over 100
                {
                    health = 100;
                }
                else if (value < 0) // no negative health
                {
                    health = 0;
                }
                else // set health to new value
                {
                    health = value;
                }
            }
        }

        public bool RocketJump
        {
            get { return rocketJump; }
            set { rocketJump = value; }
        }
        public bool Invincible
        {
            get { return invincible; }
            set { invincible = value; }
        }
        //Constructor
        public Player(Rectangle rect, Texture2D img, Texture2D rocketArm, Texture2D rock)
            : base(rect, img, new Vector2(0, 0))
        {//accepts 2 extra textures one for the rocket arm the other for the rocket
            this.rocketArm = rocketArm;
            rocketTexture = rock;
            R = new Rocket(new Rectangle(pos.X, pos.Y, 20, 10), rocketTexture, new Vector2(1, 0));
            health = 100;
        }
        //Methods 
        //Matthew Turcz 3/11 | Player input to move Axel
        public void input()
        {

            kState = Keyboard.GetState();


            if (kState.IsKeyDown(Keys.W)) wasd[0] = true; else wasd[0] = false;
            if (kState.IsKeyDown(Keys.A)) wasd[1] = true; else wasd[1] = false;
            if (kState.IsKeyDown(Keys.S)) wasd[2] = true; else wasd[2] = false;
            if (kState.IsKeyDown(Keys.D)) wasd[3] = true; else wasd[3] = false;

            //Matthew Turcz 3/18 | The game's basic jump mechanic
            if (isJump == true && (rocketJump || pos.Y >= axelElevation))//adds the jump amount to the dir.
            {
                dir.Y -= jump;
                jump = 0;

            }

            if (wasd[0] && isJump == false) //starts the jump
            {

                isJump = true;
                jump = GameVariables.axelJumpSpeed;

            }
            else if (wasd[1])//a move left
            {
                //pos.X -= GameVariables.axelWalkSpeed;
                if (dir.X > -GameVariables.axelWalkSpeed)
                    dir.X -= 2;
                //if statement added by Robert to limit the character to the active screen and prevent 
                //axel from running off the screen
                //4/3/15
                if (walkInterval == 20 || walkInterval == 40 || walkInterval == 60)//every 20 frames change the walk cycle
                    offset += 20;
                if (walkInterval >= 80)//resets the walk cycle
                {
                    offset = 0;
                    walkInterval = 0;
                }
                if (pos.X <= 0)
                {
                    pos.X = 0;
                }
            }
            
            else if (wasd[3])//d move right
            {
                if (dir.X < GameVariables.axelWalkSpeed)
                    dir.X += 2;
                if (walkInterval == 20 || walkInterval == 40 || walkInterval == 60)//every 20 frames change the walk cycle
                    offset += 20;
                if (walkInterval >= 80)//resets the walk cycle
                {
                    offset = 0;
                    walkInterval = 0;
                }
                //Again, this limiting if statement was added by Robert - 4/3/15
                if (pos.X >= 800)
                {
                    //pos.X = 800;
                }
            }
            else// if axel isn't moving revert to his standing animation
                offset = 0;
            if (fired)//moves the rocket if its been fired
            {
                //Increase the rocket's position, but also limits it only to the active area
                R.Move();
                if (R.Pos.X < 0 || R.Pos.X > 800)
                    fired = false;
                if (R.Pos.Y < 0 || R.Pos.Y > 500)
                    fired = false;

            }

            if (dir.X > 0 && pos.Y >= axelElevation)// if the player is on the ground decrease his momentum
                dir.X--;
            else if (dir.X < 0 && pos.Y >= axelElevation)
                dir.X++;



            //If there is no other active rocket fired by Axel on the screen, and he has waited enough time he can fire again
            if (Mouse.GetState().LeftButton == ButtonState.Pressed && fired == false && R.Exploded == false && rocketJump == false && interval > 50)
            {
                fire();
                interval = 0;
            }
            if (pos.X >= 800)
            {
                pos.X = 800;
            }
            if (pos.X <= 0)
            {
                pos.X = 0;
            }
            if (pos.Y < axelElevation)//if axel is above the ground
            {
                offset = 20;//his in the air sprite
                dir.Y++;//every frame accelerate towards the ground
            }

            else if (pos.Y >= axelElevation && dir.Y > 0)
            {//if the player is at or below the current elevation and he would move below it reset his state
                dir.Y = 0;
                pos.Y = axelElevation;
                if (rocketJump)
                    rocketJump = false;
                if (isJump)
                    isJump = false;
                offset = 0;
            }
            
            interval++;//
            walkInterval++;
        }
        //Simon 4/1/15 a method to fire the rocket. creates a rocket object in the direction of the mouse
        public void fire()
        {

            R.Dir = new Vector2(Mouse.GetState().X - pos.X, Mouse.GetState().Y - pos.Y);
            R.Dir = R.Dir / R.Dir.Length() * GameVariables.axelRocketSpeed;
            R.flipped = flipped;
            if (!flipped)//positions the rocket based on which way the player is facing
                R.Pos = new Rectangle(pos.X + 15, pos.Y + 30, 20, 10);
            else
                R.Pos = new Rectangle(pos.X + 35, pos.Y + 34, 20, 10);
            fired = true;

        }
        // takeDamage method that will be called, and the parameter depends upon the enemy dealing damage to the player
        public void takeDamage(int enemyDamageOutput)
        {
            if (invincible == true)
            {
                return;
            }

            health = health - enemyDamageOutput;
            if (health < 0)
            {
                health = 0;
                return;
            }
            invincible = true;
        }
        //Draw
        public override void Draw(SpriteBatch spritebatch)
        {
            if (Mouse.GetState().X >= pos.X)//if the mouse is infront of the player
                flipped = false;
            else
                flipped = true;
            Vector2 angleVector = new Vector2(Mouse.GetState().X - pos.X, Mouse.GetState().Y - pos.Y);
            float angle = (float)Math.Atan(angleVector.Y / angleVector.X);//gets the angle based off the mouse relative to the player's position
            Color axelColor = Color.White;//defaults the color to white
            if (invincible)
            {
                if (flicker >= 0 && flicker < 15)
                {
                    axelColor = Color.Aquamarine;
                    flicker++;
                }

                else if (flicker >= 15 && flicker < 30)
                {
                    axelColor = Color.Yellow;
                    flicker++;
                }
                if (flicker == 30)
                {
                    flicker = 0;
                }
            }

            if (!flipped)//if he's facing right
            {
                spritebatch.Draw(sprite, pos, new Rectangle(offset, 0, 19, 40), axelColor);
                spritebatch.Draw(rocketArm, new Rectangle(pos.X + 14, pos.Y + 28, 42, 55), null, axelColor, angle, new Vector2(4, 15), SpriteEffects.None, 0f);

            }
            else//if hes facing left
            {
                spritebatch.Draw(sprite, pos, new Rectangle(offset, 0, 19, 40), axelColor, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 0f);
                spritebatch.Draw(rocketArm, new Rectangle(pos.X + 35, pos.Y + 28, 42, 55), null, axelColor, angle, new Vector2(18, 15), SpriteEffects.FlipHorizontally, 0f);

            }

            if (fired || R.Exploded)
                R.Draw(spritebatch);

        }

        //Get the coordinates for the collision method
        //The coordinates work by dividing the screen into a grid of 20x20 squares.
        //The cordinate is the square that starts from the upper left hand corner of Axel
        //Rounded down to nearest y, up to nearest x
        //Returns a string for debuggin purposes
        public string getCord()
        {
            int cordX;
            int cordY;
            double holdX;
            double holdY;
            //Divides the pixel position by 20, rounds down, and then casts into the x cordinate
            holdX = pos.X / 20;
            holdX = Math.Ceiling(holdX);
            cordX = (int)holdX;
            //Divides the pixel position by 20, rounds up, and then casts into the y cordinate
            holdY = (pos.Y) / 20;
            holdY = Math.Floor(holdY);
            cordY = (int)holdY;

            cX = cordX;
            cY = cordY;
            return "X: " + cordX + " Y: " + cordY;
        }

        //The collision detection method - uses the cordinate system from earlier
        public void cordCollision(List<Terrain> surroundings)
        {
            List<Terrain> testing = surroundings;
            /*
             * Array has possibility of:
             * 
             *   T T T 
             * T A A A T
             * T A A A T
             * T A A A T
             * T A A A T
             * T T T T T
             * 
             * It will check each possible slot for a tile, reacting to collisions with Axel 
             * accordingly.  Top and bottom rows push him to the center in y, left and right columns push
             * him towards the center in x
             * 
             * Currently, collisions just cause dir.X and dir.Y to equal 0.  This means that Axel's momentum
             * in those directions should halt with any collision.  Jumping and rocket jump variable reseting
             * is not currently implemented.
             * 
             */
            if (this.Pos.X <= 21)
            {
                dir.X = 1;
                // if (this.Pos.Y <= 385)
                //   dir.Y = -1;
            }
            fall = true;
            foreach (Terrain t in surroundings)
            {
                //Checks each column of blocks (so a single x value

                #region Left side
                //LEFT EXTREME - checks the squares to Axel's left
                if (t.cX <= this.cX - 1)
                {

                    //LEFT HEAD
                    if (t.cY == this.cY)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {
                            if (dir.X < 0)
                                dir.X = 0;
                        }

                    }
                    //LEFT CHEST
                    if (t.cY == this.cY + 1)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {
                            if (dir.X < 0)
                                dir.X = 0;
                        }
                    }
                    //LEFT SHIN
                    if (t.cY == this.cY + 2)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {
                            if (dir.X < 0)
                                dir.X = 0;

                        }
                    }
                    //LEFT FOOT
                    if (t.cY == this.cY + 3)
                    {
                        if (this.Pos.X <= t.Pos.X + t.Pos.Width + 1 || pos.X + dir.X <= t.Pos.X + t.Pos.Width + 1)
                        {
                            if (dir.X < 0)
                                dir.X = 0;
                        }
                    }

                }
                #endregion
                #region Right side

                //RIGHT EXTREME (column 5)
                if (t.cX == this.cX + 3)
                {
                    
                    //RIGHT HEAD
                    if (t.cY == this.cY)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            if (dir.X > 0)
                                dir.X = 0;
                        }
                    }
                    //RIGHT CHEST
                    if (t.cY == this.cY + 1)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            if (dir.X > 0)
                                dir.X = 0;
                        }
                    }
                    //RIGHT SHIN
                    if (t.cY == this.cY + 2)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            if (dir.X > 0)
                                dir.X = 0;

                        }
                    }
                    //RIGHT FOOT
                    if (t.cY == this.cY + 3)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {
                            if (dir.X > 0)
                                dir.X = 0;
                        }
                    }
                    
                }
                #endregion
                #region middle
                //Column 4
                if (t.cX == this.cX + 2)
                {
                    //Top of box
                    if (t.cY == this.cY - 1)
                    {
                        if (new Rectangle(pos.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))
                        {
                            dir.Y = 0;
                            if (pos.Y >= axelElevation)
                            {
                                isJump = false;
                                rocketJump = false;
                            }
                        }
                    }
                    //bottom of box
                    if (t.cY == this.cY + 4)
                    {
                        if (this.Pos.Intersects(t.Pos) || new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos) ||pos.Y+(int)dir.Y>t.cY)
                        {

                            axelElevation = t.Pos.Y - this.Pos.Height + 2;//sets the elevation to slightly above the terrain
                            fall = false;
                            fallCase1 = false;
                        }
                    }
                    fallCase1 = true;
                    if (t.cY == this.cY + 5)
                    {
                        if (new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))//if his position would intersect with the terrain object 2 below him
                        {
                            dir.Y = 5;
                        }
                    }

                    
                }
                //Column 3
                if (t.cX == this.cX + 1)
                {
                    //Top of box
                    if (t.cY == this.cY - 1)
                    {
                        if (new Rectangle(pos.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))
                        {
                            dir.Y = 0;
                            if (pos.Y >= axelElevation)
                            {
                                isJump = false;
                                rocketJump = false;
                            }
                        }
                    }
                    //bottom of box
                    if (t.cY == this.cY + 4)
                    {
                        if (this.Pos.Intersects(t.Pos) || new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos) || pos.Y + (int)dir.Y > t.Pos.Y)
                        {

                            axelElevation = t.Pos.Y - this.Pos.Height + 2;//sets the elevation to slightly above the terrain
                            fall = false;
                            fallCase2 = false;
                        }
                    }
                    fallCase2 = true;
                    if (t.cY == this.cY + 5)
                    {
                        if (new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))//if his position would intersect with the terrain object 2 below him
                        {
                            dir.Y = 5;
                        }
                    }
                    
                }
                //Column 2
                if (t.cX == this.cX)
                {
                    //Top of box
                    if (t.cY == this.cY - 1)
                    {
                        if (new Rectangle(pos.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))
                        {
                            dir.Y = 0;
                            if (pos.Y >= axelElevation)
                            {
                                isJump = false;
                                rocketJump = false;
                            }
                        }
                        
                    }
                    //bottom of box
                        if (this.Pos.Intersects(t.Pos) || new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos) || pos.Y + (int)dir.Y > t.Pos.Y)
                    {
                        if (this.Pos.Intersects(t.Pos))
                        {

                            fall = false;
                            axelElevation = t.Pos.Y - this.Pos.Height + 2;//sets the elevation to slightly above the terrain
                            fallCase3 = false;
                        }
                        fallCase3 = true;
                    }
                        if (t.cY == this.cY + 5)
                        {
                            if (new Rectangle(pos.X + (int)dir.X, pos.Y + (int)dir.Y, pos.Width, pos.Height).Intersects(t.Pos))//if his position would intersect with the terrain object 2 below him
                            {
                                dir.Y = 5;
                            }
                        }
                #endregion
                }




            }
            //Allows updates of the dir.X and dir.Y for movement, since otherwise axel could phase through blocks
            //unintentoally.  This hgas been moved from the input class to address that.
            if (fall)
            {
                axelElevation = GameVariables.ELEVATION;
            }
            pos.Y += (int)(dir.Y);//adds the direction to the player position after the collision detection is done
            pos.X += (int)(dir.X);


        }
   

    }
}