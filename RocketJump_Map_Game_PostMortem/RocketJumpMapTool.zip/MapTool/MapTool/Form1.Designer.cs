﻿namespace MapTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.referencePlayer = new System.Windows.Forms.PictureBox();
            this.labelPlayer = new System.Windows.Forms.Label();
            this.labelEnemy = new System.Windows.Forms.Label();
            this.labelFloor = new System.Windows.Forms.Label();
            this.labelLedge = new System.Windows.Forms.Label();
            this.referenceEnemy = new System.Windows.Forms.PictureBox();
            this.referenceFloor = new System.Windows.Forms.PictureBox();
            this.referenceLedge = new System.Windows.Forms.PictureBox();
            this.groupBoxKey = new System.Windows.Forms.GroupBox();
            this.labelBlank = new System.Windows.Forms.Label();
            this.referenceBlank = new System.Windows.Forms.PictureBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.editor = new System.Windows.Forms.GroupBox();
            this.tile873 = new System.Windows.Forms.PictureBox();
            this.tile874 = new System.Windows.Forms.PictureBox();
            this.tile875 = new System.Windows.Forms.PictureBox();
            this.tile876 = new System.Windows.Forms.PictureBox();
            this.tile877 = new System.Windows.Forms.PictureBox();
            this.tile878 = new System.Windows.Forms.PictureBox();
            this.tile880 = new System.Windows.Forms.PictureBox();
            this.tile879 = new System.Windows.Forms.PictureBox();
            this.tile872 = new System.Windows.Forms.PictureBox();
            this.tile871 = new System.Windows.Forms.PictureBox();
            this.tile868 = new System.Windows.Forms.PictureBox();
            this.tile867 = new System.Windows.Forms.PictureBox();
            this.tile866 = new System.Windows.Forms.PictureBox();
            this.tile865 = new System.Windows.Forms.PictureBox();
            this.tile864 = new System.Windows.Forms.PictureBox();
            this.tile863 = new System.Windows.Forms.PictureBox();
            this.tile861 = new System.Windows.Forms.PictureBox();
            this.tile862 = new System.Windows.Forms.PictureBox();
            this.tile869 = new System.Windows.Forms.PictureBox();
            this.tile870 = new System.Windows.Forms.PictureBox();
            this.tile853 = new System.Windows.Forms.PictureBox();
            this.tile854 = new System.Windows.Forms.PictureBox();
            this.tile855 = new System.Windows.Forms.PictureBox();
            this.tile856 = new System.Windows.Forms.PictureBox();
            this.tile857 = new System.Windows.Forms.PictureBox();
            this.tile858 = new System.Windows.Forms.PictureBox();
            this.tile859 = new System.Windows.Forms.PictureBox();
            this.tile860 = new System.Windows.Forms.PictureBox();
            this.tile852 = new System.Windows.Forms.PictureBox();
            this.tile851 = new System.Windows.Forms.PictureBox();
            this.tile843 = new System.Windows.Forms.PictureBox();
            this.tile844 = new System.Windows.Forms.PictureBox();
            this.tile845 = new System.Windows.Forms.PictureBox();
            this.tile846 = new System.Windows.Forms.PictureBox();
            this.tile847 = new System.Windows.Forms.PictureBox();
            this.tile848 = new System.Windows.Forms.PictureBox();
            this.tile849 = new System.Windows.Forms.PictureBox();
            this.tile850 = new System.Windows.Forms.PictureBox();
            this.tile842 = new System.Windows.Forms.PictureBox();
            this.tile841 = new System.Windows.Forms.PictureBox();
            this.tile833 = new System.Windows.Forms.PictureBox();
            this.tile834 = new System.Windows.Forms.PictureBox();
            this.tile835 = new System.Windows.Forms.PictureBox();
            this.tile836 = new System.Windows.Forms.PictureBox();
            this.tile837 = new System.Windows.Forms.PictureBox();
            this.tile838 = new System.Windows.Forms.PictureBox();
            this.tile840 = new System.Windows.Forms.PictureBox();
            this.tile839 = new System.Windows.Forms.PictureBox();
            this.tile832 = new System.Windows.Forms.PictureBox();
            this.tile831 = new System.Windows.Forms.PictureBox();
            this.tile828 = new System.Windows.Forms.PictureBox();
            this.tile827 = new System.Windows.Forms.PictureBox();
            this.tile826 = new System.Windows.Forms.PictureBox();
            this.tile825 = new System.Windows.Forms.PictureBox();
            this.tile824 = new System.Windows.Forms.PictureBox();
            this.tile823 = new System.Windows.Forms.PictureBox();
            this.tile821 = new System.Windows.Forms.PictureBox();
            this.tile822 = new System.Windows.Forms.PictureBox();
            this.tile829 = new System.Windows.Forms.PictureBox();
            this.tile830 = new System.Windows.Forms.PictureBox();
            this.tile813 = new System.Windows.Forms.PictureBox();
            this.tile814 = new System.Windows.Forms.PictureBox();
            this.tile815 = new System.Windows.Forms.PictureBox();
            this.tile816 = new System.Windows.Forms.PictureBox();
            this.tile817 = new System.Windows.Forms.PictureBox();
            this.tile818 = new System.Windows.Forms.PictureBox();
            this.tile819 = new System.Windows.Forms.PictureBox();
            this.tile820 = new System.Windows.Forms.PictureBox();
            this.tile812 = new System.Windows.Forms.PictureBox();
            this.tile811 = new System.Windows.Forms.PictureBox();
            this.tile803 = new System.Windows.Forms.PictureBox();
            this.tile804 = new System.Windows.Forms.PictureBox();
            this.tile805 = new System.Windows.Forms.PictureBox();
            this.tile806 = new System.Windows.Forms.PictureBox();
            this.tile807 = new System.Windows.Forms.PictureBox();
            this.tile808 = new System.Windows.Forms.PictureBox();
            this.tile809 = new System.Windows.Forms.PictureBox();
            this.tile810 = new System.Windows.Forms.PictureBox();
            this.tile802 = new System.Windows.Forms.PictureBox();
            this.tile801 = new System.Windows.Forms.PictureBox();
            this.tile793 = new System.Windows.Forms.PictureBox();
            this.tile794 = new System.Windows.Forms.PictureBox();
            this.tile795 = new System.Windows.Forms.PictureBox();
            this.tile796 = new System.Windows.Forms.PictureBox();
            this.tile797 = new System.Windows.Forms.PictureBox();
            this.tile798 = new System.Windows.Forms.PictureBox();
            this.tile800 = new System.Windows.Forms.PictureBox();
            this.tile799 = new System.Windows.Forms.PictureBox();
            this.tile792 = new System.Windows.Forms.PictureBox();
            this.tile791 = new System.Windows.Forms.PictureBox();
            this.tile788 = new System.Windows.Forms.PictureBox();
            this.tile787 = new System.Windows.Forms.PictureBox();
            this.tile786 = new System.Windows.Forms.PictureBox();
            this.tile785 = new System.Windows.Forms.PictureBox();
            this.tile784 = new System.Windows.Forms.PictureBox();
            this.tile783 = new System.Windows.Forms.PictureBox();
            this.tile781 = new System.Windows.Forms.PictureBox();
            this.tile782 = new System.Windows.Forms.PictureBox();
            this.tile789 = new System.Windows.Forms.PictureBox();
            this.tile790 = new System.Windows.Forms.PictureBox();
            this.tile773 = new System.Windows.Forms.PictureBox();
            this.tile774 = new System.Windows.Forms.PictureBox();
            this.tile775 = new System.Windows.Forms.PictureBox();
            this.tile776 = new System.Windows.Forms.PictureBox();
            this.tile777 = new System.Windows.Forms.PictureBox();
            this.tile778 = new System.Windows.Forms.PictureBox();
            this.tile779 = new System.Windows.Forms.PictureBox();
            this.tile780 = new System.Windows.Forms.PictureBox();
            this.tile772 = new System.Windows.Forms.PictureBox();
            this.tile771 = new System.Windows.Forms.PictureBox();
            this.tile763 = new System.Windows.Forms.PictureBox();
            this.tile764 = new System.Windows.Forms.PictureBox();
            this.tile765 = new System.Windows.Forms.PictureBox();
            this.tile766 = new System.Windows.Forms.PictureBox();
            this.tile767 = new System.Windows.Forms.PictureBox();
            this.tile768 = new System.Windows.Forms.PictureBox();
            this.tile769 = new System.Windows.Forms.PictureBox();
            this.tile770 = new System.Windows.Forms.PictureBox();
            this.tile762 = new System.Windows.Forms.PictureBox();
            this.tile761 = new System.Windows.Forms.PictureBox();
            this.tile753 = new System.Windows.Forms.PictureBox();
            this.tile754 = new System.Windows.Forms.PictureBox();
            this.tile755 = new System.Windows.Forms.PictureBox();
            this.tile756 = new System.Windows.Forms.PictureBox();
            this.tile757 = new System.Windows.Forms.PictureBox();
            this.tile758 = new System.Windows.Forms.PictureBox();
            this.tile760 = new System.Windows.Forms.PictureBox();
            this.tile759 = new System.Windows.Forms.PictureBox();
            this.tile752 = new System.Windows.Forms.PictureBox();
            this.tile751 = new System.Windows.Forms.PictureBox();
            this.tile748 = new System.Windows.Forms.PictureBox();
            this.tile747 = new System.Windows.Forms.PictureBox();
            this.tile746 = new System.Windows.Forms.PictureBox();
            this.tile745 = new System.Windows.Forms.PictureBox();
            this.tile744 = new System.Windows.Forms.PictureBox();
            this.tile743 = new System.Windows.Forms.PictureBox();
            this.tile741 = new System.Windows.Forms.PictureBox();
            this.tile742 = new System.Windows.Forms.PictureBox();
            this.tile749 = new System.Windows.Forms.PictureBox();
            this.tile750 = new System.Windows.Forms.PictureBox();
            this.tile733 = new System.Windows.Forms.PictureBox();
            this.tile734 = new System.Windows.Forms.PictureBox();
            this.tile735 = new System.Windows.Forms.PictureBox();
            this.tile736 = new System.Windows.Forms.PictureBox();
            this.tile737 = new System.Windows.Forms.PictureBox();
            this.tile738 = new System.Windows.Forms.PictureBox();
            this.tile739 = new System.Windows.Forms.PictureBox();
            this.tile740 = new System.Windows.Forms.PictureBox();
            this.tile732 = new System.Windows.Forms.PictureBox();
            this.tile731 = new System.Windows.Forms.PictureBox();
            this.tile723 = new System.Windows.Forms.PictureBox();
            this.tile724 = new System.Windows.Forms.PictureBox();
            this.tile725 = new System.Windows.Forms.PictureBox();
            this.tile726 = new System.Windows.Forms.PictureBox();
            this.tile727 = new System.Windows.Forms.PictureBox();
            this.tile728 = new System.Windows.Forms.PictureBox();
            this.tile729 = new System.Windows.Forms.PictureBox();
            this.tile730 = new System.Windows.Forms.PictureBox();
            this.tile722 = new System.Windows.Forms.PictureBox();
            this.tile721 = new System.Windows.Forms.PictureBox();
            this.tile713 = new System.Windows.Forms.PictureBox();
            this.tile714 = new System.Windows.Forms.PictureBox();
            this.tile715 = new System.Windows.Forms.PictureBox();
            this.tile716 = new System.Windows.Forms.PictureBox();
            this.tile717 = new System.Windows.Forms.PictureBox();
            this.tile718 = new System.Windows.Forms.PictureBox();
            this.tile720 = new System.Windows.Forms.PictureBox();
            this.tile719 = new System.Windows.Forms.PictureBox();
            this.tile712 = new System.Windows.Forms.PictureBox();
            this.tile711 = new System.Windows.Forms.PictureBox();
            this.tile708 = new System.Windows.Forms.PictureBox();
            this.tile707 = new System.Windows.Forms.PictureBox();
            this.tile706 = new System.Windows.Forms.PictureBox();
            this.tile705 = new System.Windows.Forms.PictureBox();
            this.tile704 = new System.Windows.Forms.PictureBox();
            this.tile703 = new System.Windows.Forms.PictureBox();
            this.tile701 = new System.Windows.Forms.PictureBox();
            this.tile702 = new System.Windows.Forms.PictureBox();
            this.tile709 = new System.Windows.Forms.PictureBox();
            this.tile710 = new System.Windows.Forms.PictureBox();
            this.tile693 = new System.Windows.Forms.PictureBox();
            this.tile694 = new System.Windows.Forms.PictureBox();
            this.tile695 = new System.Windows.Forms.PictureBox();
            this.tile696 = new System.Windows.Forms.PictureBox();
            this.tile697 = new System.Windows.Forms.PictureBox();
            this.tile698 = new System.Windows.Forms.PictureBox();
            this.tile699 = new System.Windows.Forms.PictureBox();
            this.tile700 = new System.Windows.Forms.PictureBox();
            this.tile692 = new System.Windows.Forms.PictureBox();
            this.tile691 = new System.Windows.Forms.PictureBox();
            this.tile683 = new System.Windows.Forms.PictureBox();
            this.tile684 = new System.Windows.Forms.PictureBox();
            this.tile685 = new System.Windows.Forms.PictureBox();
            this.tile686 = new System.Windows.Forms.PictureBox();
            this.tile687 = new System.Windows.Forms.PictureBox();
            this.tile688 = new System.Windows.Forms.PictureBox();
            this.tile689 = new System.Windows.Forms.PictureBox();
            this.tile690 = new System.Windows.Forms.PictureBox();
            this.tile682 = new System.Windows.Forms.PictureBox();
            this.tile681 = new System.Windows.Forms.PictureBox();
            this.tile673 = new System.Windows.Forms.PictureBox();
            this.tile674 = new System.Windows.Forms.PictureBox();
            this.tile675 = new System.Windows.Forms.PictureBox();
            this.tile676 = new System.Windows.Forms.PictureBox();
            this.tile677 = new System.Windows.Forms.PictureBox();
            this.tile678 = new System.Windows.Forms.PictureBox();
            this.tile680 = new System.Windows.Forms.PictureBox();
            this.tile679 = new System.Windows.Forms.PictureBox();
            this.tile672 = new System.Windows.Forms.PictureBox();
            this.tile671 = new System.Windows.Forms.PictureBox();
            this.tile668 = new System.Windows.Forms.PictureBox();
            this.tile667 = new System.Windows.Forms.PictureBox();
            this.tile666 = new System.Windows.Forms.PictureBox();
            this.tile665 = new System.Windows.Forms.PictureBox();
            this.tile664 = new System.Windows.Forms.PictureBox();
            this.tile663 = new System.Windows.Forms.PictureBox();
            this.tile661 = new System.Windows.Forms.PictureBox();
            this.tile662 = new System.Windows.Forms.PictureBox();
            this.tile669 = new System.Windows.Forms.PictureBox();
            this.tile670 = new System.Windows.Forms.PictureBox();
            this.tile653 = new System.Windows.Forms.PictureBox();
            this.tile654 = new System.Windows.Forms.PictureBox();
            this.tile655 = new System.Windows.Forms.PictureBox();
            this.tile656 = new System.Windows.Forms.PictureBox();
            this.tile657 = new System.Windows.Forms.PictureBox();
            this.tile658 = new System.Windows.Forms.PictureBox();
            this.tile659 = new System.Windows.Forms.PictureBox();
            this.tile660 = new System.Windows.Forms.PictureBox();
            this.tile652 = new System.Windows.Forms.PictureBox();
            this.tile651 = new System.Windows.Forms.PictureBox();
            this.tile643 = new System.Windows.Forms.PictureBox();
            this.tile644 = new System.Windows.Forms.PictureBox();
            this.tile645 = new System.Windows.Forms.PictureBox();
            this.tile646 = new System.Windows.Forms.PictureBox();
            this.tile647 = new System.Windows.Forms.PictureBox();
            this.tile648 = new System.Windows.Forms.PictureBox();
            this.tile649 = new System.Windows.Forms.PictureBox();
            this.tile650 = new System.Windows.Forms.PictureBox();
            this.tile642 = new System.Windows.Forms.PictureBox();
            this.tile641 = new System.Windows.Forms.PictureBox();
            this.tile633 = new System.Windows.Forms.PictureBox();
            this.tile634 = new System.Windows.Forms.PictureBox();
            this.tile635 = new System.Windows.Forms.PictureBox();
            this.tile636 = new System.Windows.Forms.PictureBox();
            this.tile637 = new System.Windows.Forms.PictureBox();
            this.tile638 = new System.Windows.Forms.PictureBox();
            this.tile640 = new System.Windows.Forms.PictureBox();
            this.tile639 = new System.Windows.Forms.PictureBox();
            this.tile632 = new System.Windows.Forms.PictureBox();
            this.tile631 = new System.Windows.Forms.PictureBox();
            this.tile628 = new System.Windows.Forms.PictureBox();
            this.tile627 = new System.Windows.Forms.PictureBox();
            this.tile626 = new System.Windows.Forms.PictureBox();
            this.tile625 = new System.Windows.Forms.PictureBox();
            this.tile624 = new System.Windows.Forms.PictureBox();
            this.tile623 = new System.Windows.Forms.PictureBox();
            this.tile621 = new System.Windows.Forms.PictureBox();
            this.tile622 = new System.Windows.Forms.PictureBox();
            this.tile629 = new System.Windows.Forms.PictureBox();
            this.tile630 = new System.Windows.Forms.PictureBox();
            this.tile613 = new System.Windows.Forms.PictureBox();
            this.tile614 = new System.Windows.Forms.PictureBox();
            this.tile615 = new System.Windows.Forms.PictureBox();
            this.tile616 = new System.Windows.Forms.PictureBox();
            this.tile617 = new System.Windows.Forms.PictureBox();
            this.tile618 = new System.Windows.Forms.PictureBox();
            this.tile619 = new System.Windows.Forms.PictureBox();
            this.tile620 = new System.Windows.Forms.PictureBox();
            this.tile612 = new System.Windows.Forms.PictureBox();
            this.tile611 = new System.Windows.Forms.PictureBox();
            this.tile603 = new System.Windows.Forms.PictureBox();
            this.tile604 = new System.Windows.Forms.PictureBox();
            this.tile605 = new System.Windows.Forms.PictureBox();
            this.tile606 = new System.Windows.Forms.PictureBox();
            this.tile607 = new System.Windows.Forms.PictureBox();
            this.tile608 = new System.Windows.Forms.PictureBox();
            this.tile609 = new System.Windows.Forms.PictureBox();
            this.tile610 = new System.Windows.Forms.PictureBox();
            this.tile602 = new System.Windows.Forms.PictureBox();
            this.tile601 = new System.Windows.Forms.PictureBox();
            this.tile593 = new System.Windows.Forms.PictureBox();
            this.tile594 = new System.Windows.Forms.PictureBox();
            this.tile595 = new System.Windows.Forms.PictureBox();
            this.tile596 = new System.Windows.Forms.PictureBox();
            this.tile597 = new System.Windows.Forms.PictureBox();
            this.tile598 = new System.Windows.Forms.PictureBox();
            this.tile600 = new System.Windows.Forms.PictureBox();
            this.tile599 = new System.Windows.Forms.PictureBox();
            this.tile592 = new System.Windows.Forms.PictureBox();
            this.tile591 = new System.Windows.Forms.PictureBox();
            this.tile588 = new System.Windows.Forms.PictureBox();
            this.tile587 = new System.Windows.Forms.PictureBox();
            this.tile586 = new System.Windows.Forms.PictureBox();
            this.tile585 = new System.Windows.Forms.PictureBox();
            this.tile584 = new System.Windows.Forms.PictureBox();
            this.tile583 = new System.Windows.Forms.PictureBox();
            this.tile581 = new System.Windows.Forms.PictureBox();
            this.tile582 = new System.Windows.Forms.PictureBox();
            this.tile589 = new System.Windows.Forms.PictureBox();
            this.tile590 = new System.Windows.Forms.PictureBox();
            this.tile573 = new System.Windows.Forms.PictureBox();
            this.tile574 = new System.Windows.Forms.PictureBox();
            this.tile575 = new System.Windows.Forms.PictureBox();
            this.tile576 = new System.Windows.Forms.PictureBox();
            this.tile577 = new System.Windows.Forms.PictureBox();
            this.tile578 = new System.Windows.Forms.PictureBox();
            this.tile579 = new System.Windows.Forms.PictureBox();
            this.tile580 = new System.Windows.Forms.PictureBox();
            this.tile572 = new System.Windows.Forms.PictureBox();
            this.tile571 = new System.Windows.Forms.PictureBox();
            this.tile563 = new System.Windows.Forms.PictureBox();
            this.tile564 = new System.Windows.Forms.PictureBox();
            this.tile565 = new System.Windows.Forms.PictureBox();
            this.tile566 = new System.Windows.Forms.PictureBox();
            this.tile567 = new System.Windows.Forms.PictureBox();
            this.tile568 = new System.Windows.Forms.PictureBox();
            this.tile569 = new System.Windows.Forms.PictureBox();
            this.tile570 = new System.Windows.Forms.PictureBox();
            this.tile562 = new System.Windows.Forms.PictureBox();
            this.tile561 = new System.Windows.Forms.PictureBox();
            this.tile553 = new System.Windows.Forms.PictureBox();
            this.tile554 = new System.Windows.Forms.PictureBox();
            this.tile555 = new System.Windows.Forms.PictureBox();
            this.tile556 = new System.Windows.Forms.PictureBox();
            this.tile557 = new System.Windows.Forms.PictureBox();
            this.tile558 = new System.Windows.Forms.PictureBox();
            this.tile560 = new System.Windows.Forms.PictureBox();
            this.tile559 = new System.Windows.Forms.PictureBox();
            this.tile552 = new System.Windows.Forms.PictureBox();
            this.tile551 = new System.Windows.Forms.PictureBox();
            this.tile548 = new System.Windows.Forms.PictureBox();
            this.tile547 = new System.Windows.Forms.PictureBox();
            this.tile546 = new System.Windows.Forms.PictureBox();
            this.tile545 = new System.Windows.Forms.PictureBox();
            this.tile544 = new System.Windows.Forms.PictureBox();
            this.tile543 = new System.Windows.Forms.PictureBox();
            this.tile541 = new System.Windows.Forms.PictureBox();
            this.tile542 = new System.Windows.Forms.PictureBox();
            this.tile549 = new System.Windows.Forms.PictureBox();
            this.tile550 = new System.Windows.Forms.PictureBox();
            this.tile533 = new System.Windows.Forms.PictureBox();
            this.tile534 = new System.Windows.Forms.PictureBox();
            this.tile535 = new System.Windows.Forms.PictureBox();
            this.tile536 = new System.Windows.Forms.PictureBox();
            this.tile537 = new System.Windows.Forms.PictureBox();
            this.tile538 = new System.Windows.Forms.PictureBox();
            this.tile539 = new System.Windows.Forms.PictureBox();
            this.tile540 = new System.Windows.Forms.PictureBox();
            this.tile532 = new System.Windows.Forms.PictureBox();
            this.tile531 = new System.Windows.Forms.PictureBox();
            this.tile523 = new System.Windows.Forms.PictureBox();
            this.tile524 = new System.Windows.Forms.PictureBox();
            this.tile525 = new System.Windows.Forms.PictureBox();
            this.tile526 = new System.Windows.Forms.PictureBox();
            this.tile527 = new System.Windows.Forms.PictureBox();
            this.tile528 = new System.Windows.Forms.PictureBox();
            this.tile529 = new System.Windows.Forms.PictureBox();
            this.tile530 = new System.Windows.Forms.PictureBox();
            this.tile522 = new System.Windows.Forms.PictureBox();
            this.tile521 = new System.Windows.Forms.PictureBox();
            this.tile513 = new System.Windows.Forms.PictureBox();
            this.tile514 = new System.Windows.Forms.PictureBox();
            this.tile515 = new System.Windows.Forms.PictureBox();
            this.tile516 = new System.Windows.Forms.PictureBox();
            this.tile517 = new System.Windows.Forms.PictureBox();
            this.tile518 = new System.Windows.Forms.PictureBox();
            this.tile520 = new System.Windows.Forms.PictureBox();
            this.tile519 = new System.Windows.Forms.PictureBox();
            this.tile512 = new System.Windows.Forms.PictureBox();
            this.tile511 = new System.Windows.Forms.PictureBox();
            this.tile508 = new System.Windows.Forms.PictureBox();
            this.tile507 = new System.Windows.Forms.PictureBox();
            this.tile506 = new System.Windows.Forms.PictureBox();
            this.tile505 = new System.Windows.Forms.PictureBox();
            this.tile504 = new System.Windows.Forms.PictureBox();
            this.tile503 = new System.Windows.Forms.PictureBox();
            this.tile501 = new System.Windows.Forms.PictureBox();
            this.tile502 = new System.Windows.Forms.PictureBox();
            this.tile509 = new System.Windows.Forms.PictureBox();
            this.tile510 = new System.Windows.Forms.PictureBox();
            this.tile493 = new System.Windows.Forms.PictureBox();
            this.tile494 = new System.Windows.Forms.PictureBox();
            this.tile495 = new System.Windows.Forms.PictureBox();
            this.tile496 = new System.Windows.Forms.PictureBox();
            this.tile497 = new System.Windows.Forms.PictureBox();
            this.tile498 = new System.Windows.Forms.PictureBox();
            this.tile499 = new System.Windows.Forms.PictureBox();
            this.tile500 = new System.Windows.Forms.PictureBox();
            this.tile492 = new System.Windows.Forms.PictureBox();
            this.tile491 = new System.Windows.Forms.PictureBox();
            this.tile483 = new System.Windows.Forms.PictureBox();
            this.tile484 = new System.Windows.Forms.PictureBox();
            this.tile485 = new System.Windows.Forms.PictureBox();
            this.tile486 = new System.Windows.Forms.PictureBox();
            this.tile487 = new System.Windows.Forms.PictureBox();
            this.tile488 = new System.Windows.Forms.PictureBox();
            this.tile489 = new System.Windows.Forms.PictureBox();
            this.tile490 = new System.Windows.Forms.PictureBox();
            this.tile482 = new System.Windows.Forms.PictureBox();
            this.tile481 = new System.Windows.Forms.PictureBox();
            this.tile473 = new System.Windows.Forms.PictureBox();
            this.tile474 = new System.Windows.Forms.PictureBox();
            this.tile475 = new System.Windows.Forms.PictureBox();
            this.tile476 = new System.Windows.Forms.PictureBox();
            this.tile477 = new System.Windows.Forms.PictureBox();
            this.tile478 = new System.Windows.Forms.PictureBox();
            this.tile480 = new System.Windows.Forms.PictureBox();
            this.tile479 = new System.Windows.Forms.PictureBox();
            this.tile472 = new System.Windows.Forms.PictureBox();
            this.tile471 = new System.Windows.Forms.PictureBox();
            this.tile468 = new System.Windows.Forms.PictureBox();
            this.tile467 = new System.Windows.Forms.PictureBox();
            this.tile466 = new System.Windows.Forms.PictureBox();
            this.tile465 = new System.Windows.Forms.PictureBox();
            this.tile464 = new System.Windows.Forms.PictureBox();
            this.tile463 = new System.Windows.Forms.PictureBox();
            this.tile461 = new System.Windows.Forms.PictureBox();
            this.tile462 = new System.Windows.Forms.PictureBox();
            this.tile469 = new System.Windows.Forms.PictureBox();
            this.tile470 = new System.Windows.Forms.PictureBox();
            this.tile453 = new System.Windows.Forms.PictureBox();
            this.tile454 = new System.Windows.Forms.PictureBox();
            this.tile455 = new System.Windows.Forms.PictureBox();
            this.tile456 = new System.Windows.Forms.PictureBox();
            this.tile457 = new System.Windows.Forms.PictureBox();
            this.tile458 = new System.Windows.Forms.PictureBox();
            this.tile459 = new System.Windows.Forms.PictureBox();
            this.tile460 = new System.Windows.Forms.PictureBox();
            this.tile452 = new System.Windows.Forms.PictureBox();
            this.tile451 = new System.Windows.Forms.PictureBox();
            this.tile443 = new System.Windows.Forms.PictureBox();
            this.tile444 = new System.Windows.Forms.PictureBox();
            this.tile445 = new System.Windows.Forms.PictureBox();
            this.tile446 = new System.Windows.Forms.PictureBox();
            this.tile447 = new System.Windows.Forms.PictureBox();
            this.tile448 = new System.Windows.Forms.PictureBox();
            this.tile449 = new System.Windows.Forms.PictureBox();
            this.tile450 = new System.Windows.Forms.PictureBox();
            this.tile442 = new System.Windows.Forms.PictureBox();
            this.tile441 = new System.Windows.Forms.PictureBox();
            this.tile433 = new System.Windows.Forms.PictureBox();
            this.tile434 = new System.Windows.Forms.PictureBox();
            this.tile435 = new System.Windows.Forms.PictureBox();
            this.tile436 = new System.Windows.Forms.PictureBox();
            this.tile437 = new System.Windows.Forms.PictureBox();
            this.tile438 = new System.Windows.Forms.PictureBox();
            this.tile440 = new System.Windows.Forms.PictureBox();
            this.tile439 = new System.Windows.Forms.PictureBox();
            this.tile432 = new System.Windows.Forms.PictureBox();
            this.tile431 = new System.Windows.Forms.PictureBox();
            this.tile428 = new System.Windows.Forms.PictureBox();
            this.tile427 = new System.Windows.Forms.PictureBox();
            this.tile426 = new System.Windows.Forms.PictureBox();
            this.tile425 = new System.Windows.Forms.PictureBox();
            this.tile424 = new System.Windows.Forms.PictureBox();
            this.tile423 = new System.Windows.Forms.PictureBox();
            this.tile421 = new System.Windows.Forms.PictureBox();
            this.tile422 = new System.Windows.Forms.PictureBox();
            this.tile429 = new System.Windows.Forms.PictureBox();
            this.tile430 = new System.Windows.Forms.PictureBox();
            this.tile413 = new System.Windows.Forms.PictureBox();
            this.tile414 = new System.Windows.Forms.PictureBox();
            this.tile415 = new System.Windows.Forms.PictureBox();
            this.tile416 = new System.Windows.Forms.PictureBox();
            this.tile417 = new System.Windows.Forms.PictureBox();
            this.tile418 = new System.Windows.Forms.PictureBox();
            this.tile419 = new System.Windows.Forms.PictureBox();
            this.tile420 = new System.Windows.Forms.PictureBox();
            this.tile412 = new System.Windows.Forms.PictureBox();
            this.tile411 = new System.Windows.Forms.PictureBox();
            this.tile403 = new System.Windows.Forms.PictureBox();
            this.tile404 = new System.Windows.Forms.PictureBox();
            this.tile405 = new System.Windows.Forms.PictureBox();
            this.tile406 = new System.Windows.Forms.PictureBox();
            this.tile407 = new System.Windows.Forms.PictureBox();
            this.tile408 = new System.Windows.Forms.PictureBox();
            this.tile409 = new System.Windows.Forms.PictureBox();
            this.tile410 = new System.Windows.Forms.PictureBox();
            this.tile402 = new System.Windows.Forms.PictureBox();
            this.tile401 = new System.Windows.Forms.PictureBox();
            this.tile393 = new System.Windows.Forms.PictureBox();
            this.tile394 = new System.Windows.Forms.PictureBox();
            this.tile395 = new System.Windows.Forms.PictureBox();
            this.tile396 = new System.Windows.Forms.PictureBox();
            this.tile397 = new System.Windows.Forms.PictureBox();
            this.tile398 = new System.Windows.Forms.PictureBox();
            this.tile400 = new System.Windows.Forms.PictureBox();
            this.tile399 = new System.Windows.Forms.PictureBox();
            this.tile392 = new System.Windows.Forms.PictureBox();
            this.tile391 = new System.Windows.Forms.PictureBox();
            this.tile388 = new System.Windows.Forms.PictureBox();
            this.tile387 = new System.Windows.Forms.PictureBox();
            this.tile386 = new System.Windows.Forms.PictureBox();
            this.tile385 = new System.Windows.Forms.PictureBox();
            this.tile384 = new System.Windows.Forms.PictureBox();
            this.tile383 = new System.Windows.Forms.PictureBox();
            this.tile381 = new System.Windows.Forms.PictureBox();
            this.tile382 = new System.Windows.Forms.PictureBox();
            this.tile389 = new System.Windows.Forms.PictureBox();
            this.tile390 = new System.Windows.Forms.PictureBox();
            this.tile373 = new System.Windows.Forms.PictureBox();
            this.tile374 = new System.Windows.Forms.PictureBox();
            this.tile375 = new System.Windows.Forms.PictureBox();
            this.tile376 = new System.Windows.Forms.PictureBox();
            this.tile377 = new System.Windows.Forms.PictureBox();
            this.tile378 = new System.Windows.Forms.PictureBox();
            this.tile379 = new System.Windows.Forms.PictureBox();
            this.tile380 = new System.Windows.Forms.PictureBox();
            this.tile372 = new System.Windows.Forms.PictureBox();
            this.tile371 = new System.Windows.Forms.PictureBox();
            this.tile363 = new System.Windows.Forms.PictureBox();
            this.tile364 = new System.Windows.Forms.PictureBox();
            this.tile365 = new System.Windows.Forms.PictureBox();
            this.tile366 = new System.Windows.Forms.PictureBox();
            this.tile367 = new System.Windows.Forms.PictureBox();
            this.tile368 = new System.Windows.Forms.PictureBox();
            this.tile369 = new System.Windows.Forms.PictureBox();
            this.tile370 = new System.Windows.Forms.PictureBox();
            this.tile362 = new System.Windows.Forms.PictureBox();
            this.tile361 = new System.Windows.Forms.PictureBox();
            this.tile353 = new System.Windows.Forms.PictureBox();
            this.tile354 = new System.Windows.Forms.PictureBox();
            this.tile355 = new System.Windows.Forms.PictureBox();
            this.tile356 = new System.Windows.Forms.PictureBox();
            this.tile357 = new System.Windows.Forms.PictureBox();
            this.tile358 = new System.Windows.Forms.PictureBox();
            this.tile360 = new System.Windows.Forms.PictureBox();
            this.tile359 = new System.Windows.Forms.PictureBox();
            this.tile352 = new System.Windows.Forms.PictureBox();
            this.tile351 = new System.Windows.Forms.PictureBox();
            this.tile348 = new System.Windows.Forms.PictureBox();
            this.tile347 = new System.Windows.Forms.PictureBox();
            this.tile346 = new System.Windows.Forms.PictureBox();
            this.tile345 = new System.Windows.Forms.PictureBox();
            this.tile344 = new System.Windows.Forms.PictureBox();
            this.tile343 = new System.Windows.Forms.PictureBox();
            this.tile341 = new System.Windows.Forms.PictureBox();
            this.tile342 = new System.Windows.Forms.PictureBox();
            this.tile349 = new System.Windows.Forms.PictureBox();
            this.tile350 = new System.Windows.Forms.PictureBox();
            this.tile333 = new System.Windows.Forms.PictureBox();
            this.tile334 = new System.Windows.Forms.PictureBox();
            this.tile335 = new System.Windows.Forms.PictureBox();
            this.tile336 = new System.Windows.Forms.PictureBox();
            this.tile337 = new System.Windows.Forms.PictureBox();
            this.tile338 = new System.Windows.Forms.PictureBox();
            this.tile339 = new System.Windows.Forms.PictureBox();
            this.tile340 = new System.Windows.Forms.PictureBox();
            this.tile332 = new System.Windows.Forms.PictureBox();
            this.tile331 = new System.Windows.Forms.PictureBox();
            this.tile323 = new System.Windows.Forms.PictureBox();
            this.tile324 = new System.Windows.Forms.PictureBox();
            this.tile325 = new System.Windows.Forms.PictureBox();
            this.tile326 = new System.Windows.Forms.PictureBox();
            this.tile327 = new System.Windows.Forms.PictureBox();
            this.tile328 = new System.Windows.Forms.PictureBox();
            this.tile329 = new System.Windows.Forms.PictureBox();
            this.tile330 = new System.Windows.Forms.PictureBox();
            this.tile322 = new System.Windows.Forms.PictureBox();
            this.tile321 = new System.Windows.Forms.PictureBox();
            this.tile313 = new System.Windows.Forms.PictureBox();
            this.tile314 = new System.Windows.Forms.PictureBox();
            this.tile315 = new System.Windows.Forms.PictureBox();
            this.tile316 = new System.Windows.Forms.PictureBox();
            this.tile317 = new System.Windows.Forms.PictureBox();
            this.tile318 = new System.Windows.Forms.PictureBox();
            this.tile320 = new System.Windows.Forms.PictureBox();
            this.tile319 = new System.Windows.Forms.PictureBox();
            this.tile312 = new System.Windows.Forms.PictureBox();
            this.tile311 = new System.Windows.Forms.PictureBox();
            this.tile308 = new System.Windows.Forms.PictureBox();
            this.tile307 = new System.Windows.Forms.PictureBox();
            this.tile306 = new System.Windows.Forms.PictureBox();
            this.tile305 = new System.Windows.Forms.PictureBox();
            this.tile304 = new System.Windows.Forms.PictureBox();
            this.tile303 = new System.Windows.Forms.PictureBox();
            this.tile301 = new System.Windows.Forms.PictureBox();
            this.tile302 = new System.Windows.Forms.PictureBox();
            this.tile309 = new System.Windows.Forms.PictureBox();
            this.tile310 = new System.Windows.Forms.PictureBox();
            this.tile293 = new System.Windows.Forms.PictureBox();
            this.tile294 = new System.Windows.Forms.PictureBox();
            this.tile295 = new System.Windows.Forms.PictureBox();
            this.tile296 = new System.Windows.Forms.PictureBox();
            this.tile297 = new System.Windows.Forms.PictureBox();
            this.tile298 = new System.Windows.Forms.PictureBox();
            this.tile299 = new System.Windows.Forms.PictureBox();
            this.tile300 = new System.Windows.Forms.PictureBox();
            this.tile292 = new System.Windows.Forms.PictureBox();
            this.tile291 = new System.Windows.Forms.PictureBox();
            this.tile283 = new System.Windows.Forms.PictureBox();
            this.tile284 = new System.Windows.Forms.PictureBox();
            this.tile285 = new System.Windows.Forms.PictureBox();
            this.tile286 = new System.Windows.Forms.PictureBox();
            this.tile287 = new System.Windows.Forms.PictureBox();
            this.tile288 = new System.Windows.Forms.PictureBox();
            this.tile289 = new System.Windows.Forms.PictureBox();
            this.tile290 = new System.Windows.Forms.PictureBox();
            this.tile282 = new System.Windows.Forms.PictureBox();
            this.tile281 = new System.Windows.Forms.PictureBox();
            this.tile273 = new System.Windows.Forms.PictureBox();
            this.tile274 = new System.Windows.Forms.PictureBox();
            this.tile275 = new System.Windows.Forms.PictureBox();
            this.tile276 = new System.Windows.Forms.PictureBox();
            this.tile277 = new System.Windows.Forms.PictureBox();
            this.tile278 = new System.Windows.Forms.PictureBox();
            this.tile280 = new System.Windows.Forms.PictureBox();
            this.tile279 = new System.Windows.Forms.PictureBox();
            this.tile272 = new System.Windows.Forms.PictureBox();
            this.tile271 = new System.Windows.Forms.PictureBox();
            this.tile268 = new System.Windows.Forms.PictureBox();
            this.tile267 = new System.Windows.Forms.PictureBox();
            this.tile266 = new System.Windows.Forms.PictureBox();
            this.tile265 = new System.Windows.Forms.PictureBox();
            this.tile264 = new System.Windows.Forms.PictureBox();
            this.tile263 = new System.Windows.Forms.PictureBox();
            this.tile261 = new System.Windows.Forms.PictureBox();
            this.tile262 = new System.Windows.Forms.PictureBox();
            this.tile269 = new System.Windows.Forms.PictureBox();
            this.tile270 = new System.Windows.Forms.PictureBox();
            this.tile253 = new System.Windows.Forms.PictureBox();
            this.tile254 = new System.Windows.Forms.PictureBox();
            this.tile255 = new System.Windows.Forms.PictureBox();
            this.tile256 = new System.Windows.Forms.PictureBox();
            this.tile257 = new System.Windows.Forms.PictureBox();
            this.tile258 = new System.Windows.Forms.PictureBox();
            this.tile259 = new System.Windows.Forms.PictureBox();
            this.tile260 = new System.Windows.Forms.PictureBox();
            this.tile252 = new System.Windows.Forms.PictureBox();
            this.tile251 = new System.Windows.Forms.PictureBox();
            this.tile243 = new System.Windows.Forms.PictureBox();
            this.tile244 = new System.Windows.Forms.PictureBox();
            this.tile245 = new System.Windows.Forms.PictureBox();
            this.tile246 = new System.Windows.Forms.PictureBox();
            this.tile247 = new System.Windows.Forms.PictureBox();
            this.tile248 = new System.Windows.Forms.PictureBox();
            this.tile249 = new System.Windows.Forms.PictureBox();
            this.tile250 = new System.Windows.Forms.PictureBox();
            this.tile242 = new System.Windows.Forms.PictureBox();
            this.tile241 = new System.Windows.Forms.PictureBox();
            this.tile233 = new System.Windows.Forms.PictureBox();
            this.tile234 = new System.Windows.Forms.PictureBox();
            this.tile235 = new System.Windows.Forms.PictureBox();
            this.tile236 = new System.Windows.Forms.PictureBox();
            this.tile237 = new System.Windows.Forms.PictureBox();
            this.tile238 = new System.Windows.Forms.PictureBox();
            this.tile240 = new System.Windows.Forms.PictureBox();
            this.tile239 = new System.Windows.Forms.PictureBox();
            this.tile232 = new System.Windows.Forms.PictureBox();
            this.tile231 = new System.Windows.Forms.PictureBox();
            this.tile228 = new System.Windows.Forms.PictureBox();
            this.tile227 = new System.Windows.Forms.PictureBox();
            this.tile226 = new System.Windows.Forms.PictureBox();
            this.tile225 = new System.Windows.Forms.PictureBox();
            this.tile224 = new System.Windows.Forms.PictureBox();
            this.tile223 = new System.Windows.Forms.PictureBox();
            this.tile221 = new System.Windows.Forms.PictureBox();
            this.tile222 = new System.Windows.Forms.PictureBox();
            this.tile229 = new System.Windows.Forms.PictureBox();
            this.tile230 = new System.Windows.Forms.PictureBox();
            this.tile213 = new System.Windows.Forms.PictureBox();
            this.tile214 = new System.Windows.Forms.PictureBox();
            this.tile215 = new System.Windows.Forms.PictureBox();
            this.tile216 = new System.Windows.Forms.PictureBox();
            this.tile217 = new System.Windows.Forms.PictureBox();
            this.tile218 = new System.Windows.Forms.PictureBox();
            this.tile219 = new System.Windows.Forms.PictureBox();
            this.tile220 = new System.Windows.Forms.PictureBox();
            this.tile212 = new System.Windows.Forms.PictureBox();
            this.tile211 = new System.Windows.Forms.PictureBox();
            this.tile203 = new System.Windows.Forms.PictureBox();
            this.tile204 = new System.Windows.Forms.PictureBox();
            this.tile205 = new System.Windows.Forms.PictureBox();
            this.tile206 = new System.Windows.Forms.PictureBox();
            this.tile207 = new System.Windows.Forms.PictureBox();
            this.tile208 = new System.Windows.Forms.PictureBox();
            this.tile209 = new System.Windows.Forms.PictureBox();
            this.tile210 = new System.Windows.Forms.PictureBox();
            this.tile202 = new System.Windows.Forms.PictureBox();
            this.tile201 = new System.Windows.Forms.PictureBox();
            this.tile193 = new System.Windows.Forms.PictureBox();
            this.tile194 = new System.Windows.Forms.PictureBox();
            this.tile195 = new System.Windows.Forms.PictureBox();
            this.tile196 = new System.Windows.Forms.PictureBox();
            this.tile197 = new System.Windows.Forms.PictureBox();
            this.tile198 = new System.Windows.Forms.PictureBox();
            this.tile200 = new System.Windows.Forms.PictureBox();
            this.tile199 = new System.Windows.Forms.PictureBox();
            this.tile192 = new System.Windows.Forms.PictureBox();
            this.tile191 = new System.Windows.Forms.PictureBox();
            this.tile188 = new System.Windows.Forms.PictureBox();
            this.tile187 = new System.Windows.Forms.PictureBox();
            this.tile186 = new System.Windows.Forms.PictureBox();
            this.tile185 = new System.Windows.Forms.PictureBox();
            this.tile184 = new System.Windows.Forms.PictureBox();
            this.tile183 = new System.Windows.Forms.PictureBox();
            this.tile181 = new System.Windows.Forms.PictureBox();
            this.tile182 = new System.Windows.Forms.PictureBox();
            this.tile189 = new System.Windows.Forms.PictureBox();
            this.tile190 = new System.Windows.Forms.PictureBox();
            this.tile173 = new System.Windows.Forms.PictureBox();
            this.tile174 = new System.Windows.Forms.PictureBox();
            this.tile175 = new System.Windows.Forms.PictureBox();
            this.tile176 = new System.Windows.Forms.PictureBox();
            this.tile177 = new System.Windows.Forms.PictureBox();
            this.tile178 = new System.Windows.Forms.PictureBox();
            this.tile179 = new System.Windows.Forms.PictureBox();
            this.tile180 = new System.Windows.Forms.PictureBox();
            this.tile172 = new System.Windows.Forms.PictureBox();
            this.tile171 = new System.Windows.Forms.PictureBox();
            this.tile163 = new System.Windows.Forms.PictureBox();
            this.tile164 = new System.Windows.Forms.PictureBox();
            this.tile165 = new System.Windows.Forms.PictureBox();
            this.tile166 = new System.Windows.Forms.PictureBox();
            this.tile167 = new System.Windows.Forms.PictureBox();
            this.tile168 = new System.Windows.Forms.PictureBox();
            this.tile169 = new System.Windows.Forms.PictureBox();
            this.tile170 = new System.Windows.Forms.PictureBox();
            this.tile162 = new System.Windows.Forms.PictureBox();
            this.tile161 = new System.Windows.Forms.PictureBox();
            this.tile153 = new System.Windows.Forms.PictureBox();
            this.tile154 = new System.Windows.Forms.PictureBox();
            this.tile155 = new System.Windows.Forms.PictureBox();
            this.tile156 = new System.Windows.Forms.PictureBox();
            this.tile157 = new System.Windows.Forms.PictureBox();
            this.tile158 = new System.Windows.Forms.PictureBox();
            this.tile160 = new System.Windows.Forms.PictureBox();
            this.tile159 = new System.Windows.Forms.PictureBox();
            this.tile152 = new System.Windows.Forms.PictureBox();
            this.tile151 = new System.Windows.Forms.PictureBox();
            this.tile148 = new System.Windows.Forms.PictureBox();
            this.tile147 = new System.Windows.Forms.PictureBox();
            this.tile146 = new System.Windows.Forms.PictureBox();
            this.tile145 = new System.Windows.Forms.PictureBox();
            this.tile144 = new System.Windows.Forms.PictureBox();
            this.tile143 = new System.Windows.Forms.PictureBox();
            this.tile141 = new System.Windows.Forms.PictureBox();
            this.tile142 = new System.Windows.Forms.PictureBox();
            this.tile149 = new System.Windows.Forms.PictureBox();
            this.tile150 = new System.Windows.Forms.PictureBox();
            this.tile133 = new System.Windows.Forms.PictureBox();
            this.tile134 = new System.Windows.Forms.PictureBox();
            this.tile135 = new System.Windows.Forms.PictureBox();
            this.tile136 = new System.Windows.Forms.PictureBox();
            this.tile137 = new System.Windows.Forms.PictureBox();
            this.tile138 = new System.Windows.Forms.PictureBox();
            this.tile139 = new System.Windows.Forms.PictureBox();
            this.tile140 = new System.Windows.Forms.PictureBox();
            this.tile132 = new System.Windows.Forms.PictureBox();
            this.tile131 = new System.Windows.Forms.PictureBox();
            this.tile123 = new System.Windows.Forms.PictureBox();
            this.tile124 = new System.Windows.Forms.PictureBox();
            this.tile125 = new System.Windows.Forms.PictureBox();
            this.tile126 = new System.Windows.Forms.PictureBox();
            this.tile127 = new System.Windows.Forms.PictureBox();
            this.tile128 = new System.Windows.Forms.PictureBox();
            this.tile129 = new System.Windows.Forms.PictureBox();
            this.tile130 = new System.Windows.Forms.PictureBox();
            this.tile122 = new System.Windows.Forms.PictureBox();
            this.tile121 = new System.Windows.Forms.PictureBox();
            this.tile113 = new System.Windows.Forms.PictureBox();
            this.tile114 = new System.Windows.Forms.PictureBox();
            this.tile115 = new System.Windows.Forms.PictureBox();
            this.tile116 = new System.Windows.Forms.PictureBox();
            this.tile117 = new System.Windows.Forms.PictureBox();
            this.tile118 = new System.Windows.Forms.PictureBox();
            this.tile120 = new System.Windows.Forms.PictureBox();
            this.tile119 = new System.Windows.Forms.PictureBox();
            this.tile112 = new System.Windows.Forms.PictureBox();
            this.tile111 = new System.Windows.Forms.PictureBox();
            this.tile108 = new System.Windows.Forms.PictureBox();
            this.tile107 = new System.Windows.Forms.PictureBox();
            this.tile106 = new System.Windows.Forms.PictureBox();
            this.tile105 = new System.Windows.Forms.PictureBox();
            this.tile104 = new System.Windows.Forms.PictureBox();
            this.tile103 = new System.Windows.Forms.PictureBox();
            this.tile101 = new System.Windows.Forms.PictureBox();
            this.tile102 = new System.Windows.Forms.PictureBox();
            this.tile109 = new System.Windows.Forms.PictureBox();
            this.tile110 = new System.Windows.Forms.PictureBox();
            this.tile93 = new System.Windows.Forms.PictureBox();
            this.tile94 = new System.Windows.Forms.PictureBox();
            this.tile95 = new System.Windows.Forms.PictureBox();
            this.tile96 = new System.Windows.Forms.PictureBox();
            this.tile97 = new System.Windows.Forms.PictureBox();
            this.tile98 = new System.Windows.Forms.PictureBox();
            this.tile99 = new System.Windows.Forms.PictureBox();
            this.tile100 = new System.Windows.Forms.PictureBox();
            this.tile92 = new System.Windows.Forms.PictureBox();
            this.tile91 = new System.Windows.Forms.PictureBox();
            this.tile83 = new System.Windows.Forms.PictureBox();
            this.tile84 = new System.Windows.Forms.PictureBox();
            this.tile85 = new System.Windows.Forms.PictureBox();
            this.tile86 = new System.Windows.Forms.PictureBox();
            this.tile87 = new System.Windows.Forms.PictureBox();
            this.tile88 = new System.Windows.Forms.PictureBox();
            this.tile89 = new System.Windows.Forms.PictureBox();
            this.tile90 = new System.Windows.Forms.PictureBox();
            this.tile82 = new System.Windows.Forms.PictureBox();
            this.tile81 = new System.Windows.Forms.PictureBox();
            this.tile73 = new System.Windows.Forms.PictureBox();
            this.tile74 = new System.Windows.Forms.PictureBox();
            this.tile75 = new System.Windows.Forms.PictureBox();
            this.tile76 = new System.Windows.Forms.PictureBox();
            this.tile77 = new System.Windows.Forms.PictureBox();
            this.tile78 = new System.Windows.Forms.PictureBox();
            this.tile80 = new System.Windows.Forms.PictureBox();
            this.tile79 = new System.Windows.Forms.PictureBox();
            this.tile72 = new System.Windows.Forms.PictureBox();
            this.tile71 = new System.Windows.Forms.PictureBox();
            this.tile68 = new System.Windows.Forms.PictureBox();
            this.tile67 = new System.Windows.Forms.PictureBox();
            this.tile66 = new System.Windows.Forms.PictureBox();
            this.tile65 = new System.Windows.Forms.PictureBox();
            this.tile64 = new System.Windows.Forms.PictureBox();
            this.tile63 = new System.Windows.Forms.PictureBox();
            this.tile61 = new System.Windows.Forms.PictureBox();
            this.tile62 = new System.Windows.Forms.PictureBox();
            this.tile69 = new System.Windows.Forms.PictureBox();
            this.tile70 = new System.Windows.Forms.PictureBox();
            this.tile53 = new System.Windows.Forms.PictureBox();
            this.tile54 = new System.Windows.Forms.PictureBox();
            this.tile55 = new System.Windows.Forms.PictureBox();
            this.tile56 = new System.Windows.Forms.PictureBox();
            this.tile57 = new System.Windows.Forms.PictureBox();
            this.tile58 = new System.Windows.Forms.PictureBox();
            this.tile59 = new System.Windows.Forms.PictureBox();
            this.tile60 = new System.Windows.Forms.PictureBox();
            this.tile52 = new System.Windows.Forms.PictureBox();
            this.tile51 = new System.Windows.Forms.PictureBox();
            this.tile43 = new System.Windows.Forms.PictureBox();
            this.tile44 = new System.Windows.Forms.PictureBox();
            this.tile45 = new System.Windows.Forms.PictureBox();
            this.tile46 = new System.Windows.Forms.PictureBox();
            this.tile47 = new System.Windows.Forms.PictureBox();
            this.tile48 = new System.Windows.Forms.PictureBox();
            this.tile49 = new System.Windows.Forms.PictureBox();
            this.tile50 = new System.Windows.Forms.PictureBox();
            this.tile42 = new System.Windows.Forms.PictureBox();
            this.tile41 = new System.Windows.Forms.PictureBox();
            this.tile33 = new System.Windows.Forms.PictureBox();
            this.tile34 = new System.Windows.Forms.PictureBox();
            this.tile35 = new System.Windows.Forms.PictureBox();
            this.tile36 = new System.Windows.Forms.PictureBox();
            this.tile37 = new System.Windows.Forms.PictureBox();
            this.tile38 = new System.Windows.Forms.PictureBox();
            this.tile40 = new System.Windows.Forms.PictureBox();
            this.tile39 = new System.Windows.Forms.PictureBox();
            this.tile32 = new System.Windows.Forms.PictureBox();
            this.tile31 = new System.Windows.Forms.PictureBox();
            this.tile28 = new System.Windows.Forms.PictureBox();
            this.tile27 = new System.Windows.Forms.PictureBox();
            this.tile26 = new System.Windows.Forms.PictureBox();
            this.tile25 = new System.Windows.Forms.PictureBox();
            this.tile24 = new System.Windows.Forms.PictureBox();
            this.tile23 = new System.Windows.Forms.PictureBox();
            this.tile21 = new System.Windows.Forms.PictureBox();
            this.tile22 = new System.Windows.Forms.PictureBox();
            this.tile29 = new System.Windows.Forms.PictureBox();
            this.tile30 = new System.Windows.Forms.PictureBox();
            this.tile13 = new System.Windows.Forms.PictureBox();
            this.tile14 = new System.Windows.Forms.PictureBox();
            this.tile15 = new System.Windows.Forms.PictureBox();
            this.tile16 = new System.Windows.Forms.PictureBox();
            this.tile17 = new System.Windows.Forms.PictureBox();
            this.tile18 = new System.Windows.Forms.PictureBox();
            this.tile19 = new System.Windows.Forms.PictureBox();
            this.tile20 = new System.Windows.Forms.PictureBox();
            this.tile12 = new System.Windows.Forms.PictureBox();
            this.tile11 = new System.Windows.Forms.PictureBox();
            this.tile3 = new System.Windows.Forms.PictureBox();
            this.tile4 = new System.Windows.Forms.PictureBox();
            this.tile5 = new System.Windows.Forms.PictureBox();
            this.tile6 = new System.Windows.Forms.PictureBox();
            this.tile7 = new System.Windows.Forms.PictureBox();
            this.tile8 = new System.Windows.Forms.PictureBox();
            this.tile9 = new System.Windows.Forms.PictureBox();
            this.tile10 = new System.Windows.Forms.PictureBox();
            this.tile2 = new System.Windows.Forms.PictureBox();
            this.tile1 = new System.Windows.Forms.PictureBox();
            this.process1 = new System.Diagnostics.Process();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.levelNameBox = new System.Windows.Forms.TextBox();
            this.labelSaveName = new System.Windows.Forms.Label();
            this.groupBoxInstructions = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.referencePlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceEnemy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceFloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceLedge)).BeginInit();
            this.groupBoxKey.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.referenceBlank)).BeginInit();
            this.editor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tile873)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile874)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile875)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile876)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile877)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile878)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile880)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile879)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile872)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile871)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile868)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile867)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile866)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile865)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile864)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile863)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile861)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile862)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile869)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile870)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile853)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile854)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile855)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile856)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile857)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile858)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile859)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile860)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile852)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile851)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile843)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile844)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile845)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile846)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile847)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile848)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile849)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile850)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile842)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile841)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile833)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile834)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile835)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile836)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile837)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile838)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile840)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile839)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile832)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile831)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile828)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile827)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile826)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile825)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile824)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile823)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile821)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile822)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile829)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile830)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile813)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile814)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile815)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile816)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile817)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile818)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile819)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile820)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile812)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile811)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile803)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile804)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile805)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile806)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile807)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile808)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile809)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile810)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile802)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile801)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile793)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile794)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile795)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile796)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile797)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile798)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile800)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile799)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile792)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile791)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile788)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile787)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile786)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile785)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile784)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile783)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile781)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile782)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile789)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile790)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile773)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile774)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile775)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile776)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile777)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile778)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile779)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile780)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile772)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile771)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile763)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile764)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile765)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile766)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile767)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile768)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile769)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile770)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile762)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile761)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile753)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile754)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile755)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile756)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile757)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile758)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile760)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile759)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile752)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile751)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile748)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile747)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile746)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile745)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile744)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile743)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile741)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile742)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile749)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile750)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile733)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile734)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile735)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile736)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile737)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile738)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile739)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile740)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile732)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile731)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile723)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile724)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile725)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile726)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile727)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile728)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile729)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile730)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile722)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile721)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile713)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile714)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile715)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile716)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile717)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile718)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile720)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile719)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile712)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile711)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile708)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile707)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile706)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile705)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile704)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile703)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile701)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile702)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile709)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile710)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile693)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile694)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile695)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile696)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile697)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile698)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile699)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile700)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile692)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile691)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile683)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile684)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile685)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile686)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile687)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile688)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile689)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile690)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile682)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile681)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile673)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile674)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile675)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile676)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile677)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile678)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile680)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile679)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile672)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile671)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile668)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile667)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile666)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile665)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile664)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile663)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile661)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile662)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile669)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile670)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile653)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile654)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile655)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile656)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile657)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile658)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile659)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile660)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile652)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile651)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile643)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile644)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile645)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile646)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile647)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile648)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile649)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile650)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile642)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile641)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile633)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile634)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile635)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile636)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile637)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile638)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile640)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile639)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile632)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile631)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile628)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile627)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile626)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile625)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile624)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile623)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile621)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile622)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile629)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile630)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile613)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile614)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile615)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile616)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile617)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile618)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile619)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile620)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile612)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile611)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile603)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile604)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile605)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile606)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile607)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile608)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile609)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile610)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile602)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile601)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile593)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile594)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile595)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile596)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile597)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile598)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile600)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile599)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile592)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile591)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile588)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile587)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile586)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile585)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile584)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile583)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile581)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile582)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile589)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile590)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile573)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile574)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile575)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile576)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile577)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile578)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile579)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile580)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile572)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile571)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile563)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile564)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile565)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile566)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile567)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile568)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile569)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile570)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile562)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile561)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile553)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile554)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile555)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile556)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile557)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile558)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile560)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile559)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile552)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile551)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile548)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile547)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile546)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile545)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile544)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile543)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile541)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile542)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile549)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile550)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile533)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile534)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile535)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile536)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile537)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile538)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile539)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile540)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile532)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile531)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile523)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile524)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile525)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile526)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile527)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile528)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile529)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile530)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile522)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile521)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile513)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile514)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile515)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile516)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile517)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile518)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile520)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile519)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile512)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile511)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile508)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile507)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile506)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile505)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile504)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile503)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile501)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile502)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile509)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile510)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile493)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile494)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile495)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile496)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile497)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile498)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile499)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile500)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile492)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile491)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile483)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile484)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile485)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile486)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile487)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile488)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile489)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile490)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile482)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile481)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile473)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile474)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile475)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile476)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile477)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile478)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile480)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile479)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile472)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile471)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile468)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile467)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile466)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile465)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile464)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile463)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile461)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile462)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile469)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile470)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile453)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile454)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile455)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile456)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile457)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile458)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile459)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile460)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile452)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile451)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile443)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile444)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile445)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile446)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile447)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile448)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile449)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile450)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile442)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile441)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile433)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile434)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile435)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile436)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile437)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile438)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile440)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile439)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile432)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile431)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile428)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile427)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile426)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile425)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile424)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile423)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile421)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile422)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile429)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile430)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile413)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile414)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile415)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile416)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile417)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile418)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile419)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile420)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile412)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile411)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile403)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile404)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile405)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile406)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile407)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile408)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile409)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile410)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile402)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile401)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile393)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile394)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile395)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile396)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile397)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile398)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile400)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile399)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile392)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile391)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile388)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile387)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile386)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile385)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile384)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile383)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile381)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile382)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile389)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile390)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile373)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile374)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile375)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile376)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile377)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile378)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile379)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile380)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile372)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile371)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile363)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile364)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile365)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile366)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile367)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile368)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile369)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile370)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile362)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile361)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile353)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile354)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile355)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile356)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile357)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile358)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile360)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile359)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile352)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile351)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile348)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile347)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile346)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile345)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile344)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile343)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile341)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile342)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile349)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile350)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile333)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile334)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile335)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile336)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile337)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile338)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile339)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile340)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile332)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile331)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile323)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile324)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile325)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile326)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile327)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile328)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile329)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile330)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile322)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile321)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile313)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile314)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile315)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile316)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile317)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile318)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile320)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile319)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile312)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile311)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile308)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile307)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile306)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile305)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile304)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile303)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile301)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile302)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile309)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile310)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile293)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile294)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile295)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile296)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile297)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile298)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile299)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile300)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile292)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile291)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile283)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile284)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile285)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile286)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile287)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile288)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile289)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile290)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile282)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile281)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile273)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile274)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile275)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile276)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile277)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile278)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile280)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile279)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile272)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile271)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile268)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile267)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile266)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile265)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile264)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile263)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile261)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile262)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile269)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile270)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile253)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile254)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile255)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile256)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile257)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile258)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile259)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile260)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile252)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile251)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile243)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile244)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile245)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile246)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile247)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile248)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile249)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile250)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile242)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile241)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile233)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile234)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile235)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile236)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile237)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile238)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile240)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile239)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile232)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile231)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile228)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile227)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile226)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile225)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile224)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile229)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile230)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile214)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile215)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile216)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile217)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile218)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile219)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile203)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile204)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile205)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile206)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile207)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile208)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile209)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile202)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile201)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile193)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile194)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile195)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile196)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile197)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile198)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile200)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile199)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile192)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile191)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile188)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile187)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile186)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile185)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile184)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile181)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile182)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile189)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile190)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile175)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile176)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile177)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile178)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile179)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile180)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile163)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile164)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile165)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile167)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile168)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile169)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile162)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile161)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile156)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile151)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile147)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile146)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile145)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile150)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBoxInstructions.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // referencePlayer
            // 
            this.referencePlayer.BackColor = System.Drawing.Color.Aqua;
            this.referencePlayer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.referencePlayer.Cursor = System.Windows.Forms.Cursors.Default;
            this.referencePlayer.Location = new System.Drawing.Point(23, 29);
            this.referencePlayer.Name = "referencePlayer";
            this.referencePlayer.Size = new System.Drawing.Size(38, 36);
            this.referencePlayer.TabIndex = 0;
            this.referencePlayer.TabStop = false;
            this.referencePlayer.Click += new System.EventHandler(this.referencePlayer_Click);
            // 
            // labelPlayer
            // 
            this.labelPlayer.AutoSize = true;
            this.labelPlayer.Location = new System.Drawing.Point(67, 41);
            this.labelPlayer.Name = "labelPlayer";
            this.labelPlayer.Size = new System.Drawing.Size(72, 13);
            this.labelPlayer.TabIndex = 4;
            this.labelPlayer.Text = "Player Spawn";
            // 
            // labelEnemy
            // 
            this.labelEnemy.AutoSize = true;
            this.labelEnemy.Location = new System.Drawing.Point(67, 81);
            this.labelEnemy.Name = "labelEnemy";
            this.labelEnemy.Size = new System.Drawing.Size(75, 13);
            this.labelEnemy.TabIndex = 4;
            this.labelEnemy.Text = "Enemy Spawn";
            // 
            // labelFloor
            // 
            this.labelFloor.AutoSize = true;
            this.labelFloor.Location = new System.Drawing.Point(67, 125);
            this.labelFloor.Name = "labelFloor";
            this.labelFloor.Size = new System.Drawing.Size(30, 13);
            this.labelFloor.TabIndex = 4;
            this.labelFloor.Text = "Floor";
            // 
            // labelLedge
            // 
            this.labelLedge.AutoSize = true;
            this.labelLedge.Location = new System.Drawing.Point(67, 167);
            this.labelLedge.Name = "labelLedge";
            this.labelLedge.Size = new System.Drawing.Size(37, 13);
            this.labelLedge.TabIndex = 4;
            this.labelLedge.Text = "Ledge";
            this.labelLedge.Click += new System.EventHandler(this.labelLedge_Click);
            // 
            // referenceEnemy
            // 
            this.referenceEnemy.BackColor = System.Drawing.Color.Red;
            this.referenceEnemy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.referenceEnemy.Cursor = System.Windows.Forms.Cursors.Default;
            this.referenceEnemy.Location = new System.Drawing.Point(23, 71);
            this.referenceEnemy.Name = "referenceEnemy";
            this.referenceEnemy.Size = new System.Drawing.Size(38, 36);
            this.referenceEnemy.TabIndex = 0;
            this.referenceEnemy.TabStop = false;
            this.referenceEnemy.Click += new System.EventHandler(this.referenceEnemy_Click);
            // 
            // referenceFloor
            // 
            this.referenceFloor.BackColor = System.Drawing.Color.Black;
            this.referenceFloor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.referenceFloor.Cursor = System.Windows.Forms.Cursors.Default;
            this.referenceFloor.Location = new System.Drawing.Point(23, 113);
            this.referenceFloor.Name = "referenceFloor";
            this.referenceFloor.Size = new System.Drawing.Size(38, 36);
            this.referenceFloor.TabIndex = 0;
            this.referenceFloor.TabStop = false;
            this.referenceFloor.Click += new System.EventHandler(this.referenceFloor_Click);
            // 
            // referenceLedge
            // 
            this.referenceLedge.BackColor = System.Drawing.Color.Yellow;
            this.referenceLedge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.referenceLedge.Cursor = System.Windows.Forms.Cursors.Default;
            this.referenceLedge.Location = new System.Drawing.Point(23, 155);
            this.referenceLedge.Name = "referenceLedge";
            this.referenceLedge.Size = new System.Drawing.Size(38, 36);
            this.referenceLedge.TabIndex = 0;
            this.referenceLedge.TabStop = false;
            this.referenceLedge.Click += new System.EventHandler(this.referenceLedge_Click);
            // 
            // groupBoxKey
            // 
            this.groupBoxKey.Controls.Add(this.referencePlayer);
            this.groupBoxKey.Controls.Add(this.labelBlank);
            this.groupBoxKey.Controls.Add(this.labelLedge);
            this.groupBoxKey.Controls.Add(this.referenceEnemy);
            this.groupBoxKey.Controls.Add(this.labelFloor);
            this.groupBoxKey.Controls.Add(this.referenceFloor);
            this.groupBoxKey.Controls.Add(this.labelEnemy);
            this.groupBoxKey.Controls.Add(this.referenceBlank);
            this.groupBoxKey.Controls.Add(this.referenceLedge);
            this.groupBoxKey.Controls.Add(this.labelPlayer);
            this.groupBoxKey.Location = new System.Drawing.Point(1568, 22);
            this.groupBoxKey.Name = "groupBoxKey";
            this.groupBoxKey.Size = new System.Drawing.Size(173, 256);
            this.groupBoxKey.TabIndex = 5;
            this.groupBoxKey.TabStop = false;
            this.groupBoxKey.Text = "Key";
            this.groupBoxKey.Enter += new System.EventHandler(this.groupBoxKey_Enter);
            // 
            // labelBlank
            // 
            this.labelBlank.AutoSize = true;
            this.labelBlank.Location = new System.Drawing.Point(67, 209);
            this.labelBlank.Name = "labelBlank";
            this.labelBlank.Size = new System.Drawing.Size(34, 13);
            this.labelBlank.TabIndex = 4;
            this.labelBlank.Text = "Blank";
            this.labelBlank.Click += new System.EventHandler(this.labelLedge_Click);
            // 
            // referenceBlank
            // 
            this.referenceBlank.BackColor = System.Drawing.Color.White;
            this.referenceBlank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.referenceBlank.Cursor = System.Windows.Forms.Cursors.Default;
            this.referenceBlank.Location = new System.Drawing.Point(23, 197);
            this.referenceBlank.Name = "referenceBlank";
            this.referenceBlank.Size = new System.Drawing.Size(38, 36);
            this.referenceBlank.TabIndex = 0;
            this.referenceBlank.TabStop = false;
            this.referenceBlank.Click += new System.EventHandler(this.referenceBlank_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(1675, 836);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(66, 26);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(1606, 836);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(66, 26);
            this.buttonClear.TabIndex = 6;
            this.buttonClear.Text = "Reset";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // editor
            // 
            this.editor.Controls.Add(this.tile873);
            this.editor.Controls.Add(this.tile874);
            this.editor.Controls.Add(this.tile875);
            this.editor.Controls.Add(this.tile876);
            this.editor.Controls.Add(this.tile877);
            this.editor.Controls.Add(this.tile878);
            this.editor.Controls.Add(this.tile880);
            this.editor.Controls.Add(this.tile879);
            this.editor.Controls.Add(this.tile872);
            this.editor.Controls.Add(this.tile871);
            this.editor.Controls.Add(this.tile868);
            this.editor.Controls.Add(this.tile867);
            this.editor.Controls.Add(this.tile866);
            this.editor.Controls.Add(this.tile865);
            this.editor.Controls.Add(this.tile864);
            this.editor.Controls.Add(this.tile863);
            this.editor.Controls.Add(this.tile861);
            this.editor.Controls.Add(this.tile862);
            this.editor.Controls.Add(this.tile869);
            this.editor.Controls.Add(this.tile870);
            this.editor.Controls.Add(this.tile853);
            this.editor.Controls.Add(this.tile854);
            this.editor.Controls.Add(this.tile855);
            this.editor.Controls.Add(this.tile856);
            this.editor.Controls.Add(this.tile857);
            this.editor.Controls.Add(this.tile858);
            this.editor.Controls.Add(this.tile859);
            this.editor.Controls.Add(this.tile860);
            this.editor.Controls.Add(this.tile852);
            this.editor.Controls.Add(this.tile851);
            this.editor.Controls.Add(this.tile843);
            this.editor.Controls.Add(this.tile844);
            this.editor.Controls.Add(this.tile845);
            this.editor.Controls.Add(this.tile846);
            this.editor.Controls.Add(this.tile847);
            this.editor.Controls.Add(this.tile848);
            this.editor.Controls.Add(this.tile849);
            this.editor.Controls.Add(this.tile850);
            this.editor.Controls.Add(this.tile842);
            this.editor.Controls.Add(this.tile841);
            this.editor.Controls.Add(this.tile833);
            this.editor.Controls.Add(this.tile834);
            this.editor.Controls.Add(this.tile835);
            this.editor.Controls.Add(this.tile836);
            this.editor.Controls.Add(this.tile837);
            this.editor.Controls.Add(this.tile838);
            this.editor.Controls.Add(this.tile840);
            this.editor.Controls.Add(this.tile839);
            this.editor.Controls.Add(this.tile832);
            this.editor.Controls.Add(this.tile831);
            this.editor.Controls.Add(this.tile828);
            this.editor.Controls.Add(this.tile827);
            this.editor.Controls.Add(this.tile826);
            this.editor.Controls.Add(this.tile825);
            this.editor.Controls.Add(this.tile824);
            this.editor.Controls.Add(this.tile823);
            this.editor.Controls.Add(this.tile821);
            this.editor.Controls.Add(this.tile822);
            this.editor.Controls.Add(this.tile829);
            this.editor.Controls.Add(this.tile830);
            this.editor.Controls.Add(this.tile813);
            this.editor.Controls.Add(this.tile814);
            this.editor.Controls.Add(this.tile815);
            this.editor.Controls.Add(this.tile816);
            this.editor.Controls.Add(this.tile817);
            this.editor.Controls.Add(this.tile818);
            this.editor.Controls.Add(this.tile819);
            this.editor.Controls.Add(this.tile820);
            this.editor.Controls.Add(this.tile812);
            this.editor.Controls.Add(this.tile811);
            this.editor.Controls.Add(this.tile803);
            this.editor.Controls.Add(this.tile804);
            this.editor.Controls.Add(this.tile805);
            this.editor.Controls.Add(this.tile806);
            this.editor.Controls.Add(this.tile807);
            this.editor.Controls.Add(this.tile808);
            this.editor.Controls.Add(this.tile809);
            this.editor.Controls.Add(this.tile810);
            this.editor.Controls.Add(this.tile802);
            this.editor.Controls.Add(this.tile801);
            this.editor.Controls.Add(this.tile793);
            this.editor.Controls.Add(this.tile794);
            this.editor.Controls.Add(this.tile795);
            this.editor.Controls.Add(this.tile796);
            this.editor.Controls.Add(this.tile797);
            this.editor.Controls.Add(this.tile798);
            this.editor.Controls.Add(this.tile800);
            this.editor.Controls.Add(this.tile799);
            this.editor.Controls.Add(this.tile792);
            this.editor.Controls.Add(this.tile791);
            this.editor.Controls.Add(this.tile788);
            this.editor.Controls.Add(this.tile787);
            this.editor.Controls.Add(this.tile786);
            this.editor.Controls.Add(this.tile785);
            this.editor.Controls.Add(this.tile784);
            this.editor.Controls.Add(this.tile783);
            this.editor.Controls.Add(this.tile781);
            this.editor.Controls.Add(this.tile782);
            this.editor.Controls.Add(this.tile789);
            this.editor.Controls.Add(this.tile790);
            this.editor.Controls.Add(this.tile773);
            this.editor.Controls.Add(this.tile774);
            this.editor.Controls.Add(this.tile775);
            this.editor.Controls.Add(this.tile776);
            this.editor.Controls.Add(this.tile777);
            this.editor.Controls.Add(this.tile778);
            this.editor.Controls.Add(this.tile779);
            this.editor.Controls.Add(this.tile780);
            this.editor.Controls.Add(this.tile772);
            this.editor.Controls.Add(this.tile771);
            this.editor.Controls.Add(this.tile763);
            this.editor.Controls.Add(this.tile764);
            this.editor.Controls.Add(this.tile765);
            this.editor.Controls.Add(this.tile766);
            this.editor.Controls.Add(this.tile767);
            this.editor.Controls.Add(this.tile768);
            this.editor.Controls.Add(this.tile769);
            this.editor.Controls.Add(this.tile770);
            this.editor.Controls.Add(this.tile762);
            this.editor.Controls.Add(this.tile761);
            this.editor.Controls.Add(this.tile753);
            this.editor.Controls.Add(this.tile754);
            this.editor.Controls.Add(this.tile755);
            this.editor.Controls.Add(this.tile756);
            this.editor.Controls.Add(this.tile757);
            this.editor.Controls.Add(this.tile758);
            this.editor.Controls.Add(this.tile760);
            this.editor.Controls.Add(this.tile759);
            this.editor.Controls.Add(this.tile752);
            this.editor.Controls.Add(this.tile751);
            this.editor.Controls.Add(this.tile748);
            this.editor.Controls.Add(this.tile747);
            this.editor.Controls.Add(this.tile746);
            this.editor.Controls.Add(this.tile745);
            this.editor.Controls.Add(this.tile744);
            this.editor.Controls.Add(this.tile743);
            this.editor.Controls.Add(this.tile741);
            this.editor.Controls.Add(this.tile742);
            this.editor.Controls.Add(this.tile749);
            this.editor.Controls.Add(this.tile750);
            this.editor.Controls.Add(this.tile733);
            this.editor.Controls.Add(this.tile734);
            this.editor.Controls.Add(this.tile735);
            this.editor.Controls.Add(this.tile736);
            this.editor.Controls.Add(this.tile737);
            this.editor.Controls.Add(this.tile738);
            this.editor.Controls.Add(this.tile739);
            this.editor.Controls.Add(this.tile740);
            this.editor.Controls.Add(this.tile732);
            this.editor.Controls.Add(this.tile731);
            this.editor.Controls.Add(this.tile723);
            this.editor.Controls.Add(this.tile724);
            this.editor.Controls.Add(this.tile725);
            this.editor.Controls.Add(this.tile726);
            this.editor.Controls.Add(this.tile727);
            this.editor.Controls.Add(this.tile728);
            this.editor.Controls.Add(this.tile729);
            this.editor.Controls.Add(this.tile730);
            this.editor.Controls.Add(this.tile722);
            this.editor.Controls.Add(this.tile721);
            this.editor.Controls.Add(this.tile713);
            this.editor.Controls.Add(this.tile714);
            this.editor.Controls.Add(this.tile715);
            this.editor.Controls.Add(this.tile716);
            this.editor.Controls.Add(this.tile717);
            this.editor.Controls.Add(this.tile718);
            this.editor.Controls.Add(this.tile720);
            this.editor.Controls.Add(this.tile719);
            this.editor.Controls.Add(this.tile712);
            this.editor.Controls.Add(this.tile711);
            this.editor.Controls.Add(this.tile708);
            this.editor.Controls.Add(this.tile707);
            this.editor.Controls.Add(this.tile706);
            this.editor.Controls.Add(this.tile705);
            this.editor.Controls.Add(this.tile704);
            this.editor.Controls.Add(this.tile703);
            this.editor.Controls.Add(this.tile701);
            this.editor.Controls.Add(this.tile702);
            this.editor.Controls.Add(this.tile709);
            this.editor.Controls.Add(this.tile710);
            this.editor.Controls.Add(this.tile693);
            this.editor.Controls.Add(this.tile694);
            this.editor.Controls.Add(this.tile695);
            this.editor.Controls.Add(this.tile696);
            this.editor.Controls.Add(this.tile697);
            this.editor.Controls.Add(this.tile698);
            this.editor.Controls.Add(this.tile699);
            this.editor.Controls.Add(this.tile700);
            this.editor.Controls.Add(this.tile692);
            this.editor.Controls.Add(this.tile691);
            this.editor.Controls.Add(this.tile683);
            this.editor.Controls.Add(this.tile684);
            this.editor.Controls.Add(this.tile685);
            this.editor.Controls.Add(this.tile686);
            this.editor.Controls.Add(this.tile687);
            this.editor.Controls.Add(this.tile688);
            this.editor.Controls.Add(this.tile689);
            this.editor.Controls.Add(this.tile690);
            this.editor.Controls.Add(this.tile682);
            this.editor.Controls.Add(this.tile681);
            this.editor.Controls.Add(this.tile673);
            this.editor.Controls.Add(this.tile674);
            this.editor.Controls.Add(this.tile675);
            this.editor.Controls.Add(this.tile676);
            this.editor.Controls.Add(this.tile677);
            this.editor.Controls.Add(this.tile678);
            this.editor.Controls.Add(this.tile680);
            this.editor.Controls.Add(this.tile679);
            this.editor.Controls.Add(this.tile672);
            this.editor.Controls.Add(this.tile671);
            this.editor.Controls.Add(this.tile668);
            this.editor.Controls.Add(this.tile667);
            this.editor.Controls.Add(this.tile666);
            this.editor.Controls.Add(this.tile665);
            this.editor.Controls.Add(this.tile664);
            this.editor.Controls.Add(this.tile663);
            this.editor.Controls.Add(this.tile661);
            this.editor.Controls.Add(this.tile662);
            this.editor.Controls.Add(this.tile669);
            this.editor.Controls.Add(this.tile670);
            this.editor.Controls.Add(this.tile653);
            this.editor.Controls.Add(this.tile654);
            this.editor.Controls.Add(this.tile655);
            this.editor.Controls.Add(this.tile656);
            this.editor.Controls.Add(this.tile657);
            this.editor.Controls.Add(this.tile658);
            this.editor.Controls.Add(this.tile659);
            this.editor.Controls.Add(this.tile660);
            this.editor.Controls.Add(this.tile652);
            this.editor.Controls.Add(this.tile651);
            this.editor.Controls.Add(this.tile643);
            this.editor.Controls.Add(this.tile644);
            this.editor.Controls.Add(this.tile645);
            this.editor.Controls.Add(this.tile646);
            this.editor.Controls.Add(this.tile647);
            this.editor.Controls.Add(this.tile648);
            this.editor.Controls.Add(this.tile649);
            this.editor.Controls.Add(this.tile650);
            this.editor.Controls.Add(this.tile642);
            this.editor.Controls.Add(this.tile641);
            this.editor.Controls.Add(this.tile633);
            this.editor.Controls.Add(this.tile634);
            this.editor.Controls.Add(this.tile635);
            this.editor.Controls.Add(this.tile636);
            this.editor.Controls.Add(this.tile637);
            this.editor.Controls.Add(this.tile638);
            this.editor.Controls.Add(this.tile640);
            this.editor.Controls.Add(this.tile639);
            this.editor.Controls.Add(this.tile632);
            this.editor.Controls.Add(this.tile631);
            this.editor.Controls.Add(this.tile628);
            this.editor.Controls.Add(this.tile627);
            this.editor.Controls.Add(this.tile626);
            this.editor.Controls.Add(this.tile625);
            this.editor.Controls.Add(this.tile624);
            this.editor.Controls.Add(this.tile623);
            this.editor.Controls.Add(this.tile621);
            this.editor.Controls.Add(this.tile622);
            this.editor.Controls.Add(this.tile629);
            this.editor.Controls.Add(this.tile630);
            this.editor.Controls.Add(this.tile613);
            this.editor.Controls.Add(this.tile614);
            this.editor.Controls.Add(this.tile615);
            this.editor.Controls.Add(this.tile616);
            this.editor.Controls.Add(this.tile617);
            this.editor.Controls.Add(this.tile618);
            this.editor.Controls.Add(this.tile619);
            this.editor.Controls.Add(this.tile620);
            this.editor.Controls.Add(this.tile612);
            this.editor.Controls.Add(this.tile611);
            this.editor.Controls.Add(this.tile603);
            this.editor.Controls.Add(this.tile604);
            this.editor.Controls.Add(this.tile605);
            this.editor.Controls.Add(this.tile606);
            this.editor.Controls.Add(this.tile607);
            this.editor.Controls.Add(this.tile608);
            this.editor.Controls.Add(this.tile609);
            this.editor.Controls.Add(this.tile610);
            this.editor.Controls.Add(this.tile602);
            this.editor.Controls.Add(this.tile601);
            this.editor.Controls.Add(this.tile593);
            this.editor.Controls.Add(this.tile594);
            this.editor.Controls.Add(this.tile595);
            this.editor.Controls.Add(this.tile596);
            this.editor.Controls.Add(this.tile597);
            this.editor.Controls.Add(this.tile598);
            this.editor.Controls.Add(this.tile600);
            this.editor.Controls.Add(this.tile599);
            this.editor.Controls.Add(this.tile592);
            this.editor.Controls.Add(this.tile591);
            this.editor.Controls.Add(this.tile588);
            this.editor.Controls.Add(this.tile587);
            this.editor.Controls.Add(this.tile586);
            this.editor.Controls.Add(this.tile585);
            this.editor.Controls.Add(this.tile584);
            this.editor.Controls.Add(this.tile583);
            this.editor.Controls.Add(this.tile581);
            this.editor.Controls.Add(this.tile582);
            this.editor.Controls.Add(this.tile589);
            this.editor.Controls.Add(this.tile590);
            this.editor.Controls.Add(this.tile573);
            this.editor.Controls.Add(this.tile574);
            this.editor.Controls.Add(this.tile575);
            this.editor.Controls.Add(this.tile576);
            this.editor.Controls.Add(this.tile577);
            this.editor.Controls.Add(this.tile578);
            this.editor.Controls.Add(this.tile579);
            this.editor.Controls.Add(this.tile580);
            this.editor.Controls.Add(this.tile572);
            this.editor.Controls.Add(this.tile571);
            this.editor.Controls.Add(this.tile563);
            this.editor.Controls.Add(this.tile564);
            this.editor.Controls.Add(this.tile565);
            this.editor.Controls.Add(this.tile566);
            this.editor.Controls.Add(this.tile567);
            this.editor.Controls.Add(this.tile568);
            this.editor.Controls.Add(this.tile569);
            this.editor.Controls.Add(this.tile570);
            this.editor.Controls.Add(this.tile562);
            this.editor.Controls.Add(this.tile561);
            this.editor.Controls.Add(this.tile553);
            this.editor.Controls.Add(this.tile554);
            this.editor.Controls.Add(this.tile555);
            this.editor.Controls.Add(this.tile556);
            this.editor.Controls.Add(this.tile557);
            this.editor.Controls.Add(this.tile558);
            this.editor.Controls.Add(this.tile560);
            this.editor.Controls.Add(this.tile559);
            this.editor.Controls.Add(this.tile552);
            this.editor.Controls.Add(this.tile551);
            this.editor.Controls.Add(this.tile548);
            this.editor.Controls.Add(this.tile547);
            this.editor.Controls.Add(this.tile546);
            this.editor.Controls.Add(this.tile545);
            this.editor.Controls.Add(this.tile544);
            this.editor.Controls.Add(this.tile543);
            this.editor.Controls.Add(this.tile541);
            this.editor.Controls.Add(this.tile542);
            this.editor.Controls.Add(this.tile549);
            this.editor.Controls.Add(this.tile550);
            this.editor.Controls.Add(this.tile533);
            this.editor.Controls.Add(this.tile534);
            this.editor.Controls.Add(this.tile535);
            this.editor.Controls.Add(this.tile536);
            this.editor.Controls.Add(this.tile537);
            this.editor.Controls.Add(this.tile538);
            this.editor.Controls.Add(this.tile539);
            this.editor.Controls.Add(this.tile540);
            this.editor.Controls.Add(this.tile532);
            this.editor.Controls.Add(this.tile531);
            this.editor.Controls.Add(this.tile523);
            this.editor.Controls.Add(this.tile524);
            this.editor.Controls.Add(this.tile525);
            this.editor.Controls.Add(this.tile526);
            this.editor.Controls.Add(this.tile527);
            this.editor.Controls.Add(this.tile528);
            this.editor.Controls.Add(this.tile529);
            this.editor.Controls.Add(this.tile530);
            this.editor.Controls.Add(this.tile522);
            this.editor.Controls.Add(this.tile521);
            this.editor.Controls.Add(this.tile513);
            this.editor.Controls.Add(this.tile514);
            this.editor.Controls.Add(this.tile515);
            this.editor.Controls.Add(this.tile516);
            this.editor.Controls.Add(this.tile517);
            this.editor.Controls.Add(this.tile518);
            this.editor.Controls.Add(this.tile520);
            this.editor.Controls.Add(this.tile519);
            this.editor.Controls.Add(this.tile512);
            this.editor.Controls.Add(this.tile511);
            this.editor.Controls.Add(this.tile508);
            this.editor.Controls.Add(this.tile507);
            this.editor.Controls.Add(this.tile506);
            this.editor.Controls.Add(this.tile505);
            this.editor.Controls.Add(this.tile504);
            this.editor.Controls.Add(this.tile503);
            this.editor.Controls.Add(this.tile501);
            this.editor.Controls.Add(this.tile502);
            this.editor.Controls.Add(this.tile509);
            this.editor.Controls.Add(this.tile510);
            this.editor.Controls.Add(this.tile493);
            this.editor.Controls.Add(this.tile494);
            this.editor.Controls.Add(this.tile495);
            this.editor.Controls.Add(this.tile496);
            this.editor.Controls.Add(this.tile497);
            this.editor.Controls.Add(this.tile498);
            this.editor.Controls.Add(this.tile499);
            this.editor.Controls.Add(this.tile500);
            this.editor.Controls.Add(this.tile492);
            this.editor.Controls.Add(this.tile491);
            this.editor.Controls.Add(this.tile483);
            this.editor.Controls.Add(this.tile484);
            this.editor.Controls.Add(this.tile485);
            this.editor.Controls.Add(this.tile486);
            this.editor.Controls.Add(this.tile487);
            this.editor.Controls.Add(this.tile488);
            this.editor.Controls.Add(this.tile489);
            this.editor.Controls.Add(this.tile490);
            this.editor.Controls.Add(this.tile482);
            this.editor.Controls.Add(this.tile481);
            this.editor.Controls.Add(this.tile473);
            this.editor.Controls.Add(this.tile474);
            this.editor.Controls.Add(this.tile475);
            this.editor.Controls.Add(this.tile476);
            this.editor.Controls.Add(this.tile477);
            this.editor.Controls.Add(this.tile478);
            this.editor.Controls.Add(this.tile480);
            this.editor.Controls.Add(this.tile479);
            this.editor.Controls.Add(this.tile472);
            this.editor.Controls.Add(this.tile471);
            this.editor.Controls.Add(this.tile468);
            this.editor.Controls.Add(this.tile467);
            this.editor.Controls.Add(this.tile466);
            this.editor.Controls.Add(this.tile465);
            this.editor.Controls.Add(this.tile464);
            this.editor.Controls.Add(this.tile463);
            this.editor.Controls.Add(this.tile461);
            this.editor.Controls.Add(this.tile462);
            this.editor.Controls.Add(this.tile469);
            this.editor.Controls.Add(this.tile470);
            this.editor.Controls.Add(this.tile453);
            this.editor.Controls.Add(this.tile454);
            this.editor.Controls.Add(this.tile455);
            this.editor.Controls.Add(this.tile456);
            this.editor.Controls.Add(this.tile457);
            this.editor.Controls.Add(this.tile458);
            this.editor.Controls.Add(this.tile459);
            this.editor.Controls.Add(this.tile460);
            this.editor.Controls.Add(this.tile452);
            this.editor.Controls.Add(this.tile451);
            this.editor.Controls.Add(this.tile443);
            this.editor.Controls.Add(this.tile444);
            this.editor.Controls.Add(this.tile445);
            this.editor.Controls.Add(this.tile446);
            this.editor.Controls.Add(this.tile447);
            this.editor.Controls.Add(this.tile448);
            this.editor.Controls.Add(this.tile449);
            this.editor.Controls.Add(this.tile450);
            this.editor.Controls.Add(this.tile442);
            this.editor.Controls.Add(this.tile441);
            this.editor.Controls.Add(this.tile433);
            this.editor.Controls.Add(this.tile434);
            this.editor.Controls.Add(this.tile435);
            this.editor.Controls.Add(this.tile436);
            this.editor.Controls.Add(this.tile437);
            this.editor.Controls.Add(this.tile438);
            this.editor.Controls.Add(this.tile440);
            this.editor.Controls.Add(this.tile439);
            this.editor.Controls.Add(this.tile432);
            this.editor.Controls.Add(this.tile431);
            this.editor.Controls.Add(this.tile428);
            this.editor.Controls.Add(this.tile427);
            this.editor.Controls.Add(this.tile426);
            this.editor.Controls.Add(this.tile425);
            this.editor.Controls.Add(this.tile424);
            this.editor.Controls.Add(this.tile423);
            this.editor.Controls.Add(this.tile421);
            this.editor.Controls.Add(this.tile422);
            this.editor.Controls.Add(this.tile429);
            this.editor.Controls.Add(this.tile430);
            this.editor.Controls.Add(this.tile413);
            this.editor.Controls.Add(this.tile414);
            this.editor.Controls.Add(this.tile415);
            this.editor.Controls.Add(this.tile416);
            this.editor.Controls.Add(this.tile417);
            this.editor.Controls.Add(this.tile418);
            this.editor.Controls.Add(this.tile419);
            this.editor.Controls.Add(this.tile420);
            this.editor.Controls.Add(this.tile412);
            this.editor.Controls.Add(this.tile411);
            this.editor.Controls.Add(this.tile403);
            this.editor.Controls.Add(this.tile404);
            this.editor.Controls.Add(this.tile405);
            this.editor.Controls.Add(this.tile406);
            this.editor.Controls.Add(this.tile407);
            this.editor.Controls.Add(this.tile408);
            this.editor.Controls.Add(this.tile409);
            this.editor.Controls.Add(this.tile410);
            this.editor.Controls.Add(this.tile402);
            this.editor.Controls.Add(this.tile401);
            this.editor.Controls.Add(this.tile393);
            this.editor.Controls.Add(this.tile394);
            this.editor.Controls.Add(this.tile395);
            this.editor.Controls.Add(this.tile396);
            this.editor.Controls.Add(this.tile397);
            this.editor.Controls.Add(this.tile398);
            this.editor.Controls.Add(this.tile400);
            this.editor.Controls.Add(this.tile399);
            this.editor.Controls.Add(this.tile392);
            this.editor.Controls.Add(this.tile391);
            this.editor.Controls.Add(this.tile388);
            this.editor.Controls.Add(this.tile387);
            this.editor.Controls.Add(this.tile386);
            this.editor.Controls.Add(this.tile385);
            this.editor.Controls.Add(this.tile384);
            this.editor.Controls.Add(this.tile383);
            this.editor.Controls.Add(this.tile381);
            this.editor.Controls.Add(this.tile382);
            this.editor.Controls.Add(this.tile389);
            this.editor.Controls.Add(this.tile390);
            this.editor.Controls.Add(this.tile373);
            this.editor.Controls.Add(this.tile374);
            this.editor.Controls.Add(this.tile375);
            this.editor.Controls.Add(this.tile376);
            this.editor.Controls.Add(this.tile377);
            this.editor.Controls.Add(this.tile378);
            this.editor.Controls.Add(this.tile379);
            this.editor.Controls.Add(this.tile380);
            this.editor.Controls.Add(this.tile372);
            this.editor.Controls.Add(this.tile371);
            this.editor.Controls.Add(this.tile363);
            this.editor.Controls.Add(this.tile364);
            this.editor.Controls.Add(this.tile365);
            this.editor.Controls.Add(this.tile366);
            this.editor.Controls.Add(this.tile367);
            this.editor.Controls.Add(this.tile368);
            this.editor.Controls.Add(this.tile369);
            this.editor.Controls.Add(this.tile370);
            this.editor.Controls.Add(this.tile362);
            this.editor.Controls.Add(this.tile361);
            this.editor.Controls.Add(this.tile353);
            this.editor.Controls.Add(this.tile354);
            this.editor.Controls.Add(this.tile355);
            this.editor.Controls.Add(this.tile356);
            this.editor.Controls.Add(this.tile357);
            this.editor.Controls.Add(this.tile358);
            this.editor.Controls.Add(this.tile360);
            this.editor.Controls.Add(this.tile359);
            this.editor.Controls.Add(this.tile352);
            this.editor.Controls.Add(this.tile351);
            this.editor.Controls.Add(this.tile348);
            this.editor.Controls.Add(this.tile347);
            this.editor.Controls.Add(this.tile346);
            this.editor.Controls.Add(this.tile345);
            this.editor.Controls.Add(this.tile344);
            this.editor.Controls.Add(this.tile343);
            this.editor.Controls.Add(this.tile341);
            this.editor.Controls.Add(this.tile342);
            this.editor.Controls.Add(this.tile349);
            this.editor.Controls.Add(this.tile350);
            this.editor.Controls.Add(this.tile333);
            this.editor.Controls.Add(this.tile334);
            this.editor.Controls.Add(this.tile335);
            this.editor.Controls.Add(this.tile336);
            this.editor.Controls.Add(this.tile337);
            this.editor.Controls.Add(this.tile338);
            this.editor.Controls.Add(this.tile339);
            this.editor.Controls.Add(this.tile340);
            this.editor.Controls.Add(this.tile332);
            this.editor.Controls.Add(this.tile331);
            this.editor.Controls.Add(this.tile323);
            this.editor.Controls.Add(this.tile324);
            this.editor.Controls.Add(this.tile325);
            this.editor.Controls.Add(this.tile326);
            this.editor.Controls.Add(this.tile327);
            this.editor.Controls.Add(this.tile328);
            this.editor.Controls.Add(this.tile329);
            this.editor.Controls.Add(this.tile330);
            this.editor.Controls.Add(this.tile322);
            this.editor.Controls.Add(this.tile321);
            this.editor.Controls.Add(this.tile313);
            this.editor.Controls.Add(this.tile314);
            this.editor.Controls.Add(this.tile315);
            this.editor.Controls.Add(this.tile316);
            this.editor.Controls.Add(this.tile317);
            this.editor.Controls.Add(this.tile318);
            this.editor.Controls.Add(this.tile320);
            this.editor.Controls.Add(this.tile319);
            this.editor.Controls.Add(this.tile312);
            this.editor.Controls.Add(this.tile311);
            this.editor.Controls.Add(this.tile308);
            this.editor.Controls.Add(this.tile307);
            this.editor.Controls.Add(this.tile306);
            this.editor.Controls.Add(this.tile305);
            this.editor.Controls.Add(this.tile304);
            this.editor.Controls.Add(this.tile303);
            this.editor.Controls.Add(this.tile301);
            this.editor.Controls.Add(this.tile302);
            this.editor.Controls.Add(this.tile309);
            this.editor.Controls.Add(this.tile310);
            this.editor.Controls.Add(this.tile293);
            this.editor.Controls.Add(this.tile294);
            this.editor.Controls.Add(this.tile295);
            this.editor.Controls.Add(this.tile296);
            this.editor.Controls.Add(this.tile297);
            this.editor.Controls.Add(this.tile298);
            this.editor.Controls.Add(this.tile299);
            this.editor.Controls.Add(this.tile300);
            this.editor.Controls.Add(this.tile292);
            this.editor.Controls.Add(this.tile291);
            this.editor.Controls.Add(this.tile283);
            this.editor.Controls.Add(this.tile284);
            this.editor.Controls.Add(this.tile285);
            this.editor.Controls.Add(this.tile286);
            this.editor.Controls.Add(this.tile287);
            this.editor.Controls.Add(this.tile288);
            this.editor.Controls.Add(this.tile289);
            this.editor.Controls.Add(this.tile290);
            this.editor.Controls.Add(this.tile282);
            this.editor.Controls.Add(this.tile281);
            this.editor.Controls.Add(this.tile273);
            this.editor.Controls.Add(this.tile274);
            this.editor.Controls.Add(this.tile275);
            this.editor.Controls.Add(this.tile276);
            this.editor.Controls.Add(this.tile277);
            this.editor.Controls.Add(this.tile278);
            this.editor.Controls.Add(this.tile280);
            this.editor.Controls.Add(this.tile279);
            this.editor.Controls.Add(this.tile272);
            this.editor.Controls.Add(this.tile271);
            this.editor.Controls.Add(this.tile268);
            this.editor.Controls.Add(this.tile267);
            this.editor.Controls.Add(this.tile266);
            this.editor.Controls.Add(this.tile265);
            this.editor.Controls.Add(this.tile264);
            this.editor.Controls.Add(this.tile263);
            this.editor.Controls.Add(this.tile261);
            this.editor.Controls.Add(this.tile262);
            this.editor.Controls.Add(this.tile269);
            this.editor.Controls.Add(this.tile270);
            this.editor.Controls.Add(this.tile253);
            this.editor.Controls.Add(this.tile254);
            this.editor.Controls.Add(this.tile255);
            this.editor.Controls.Add(this.tile256);
            this.editor.Controls.Add(this.tile257);
            this.editor.Controls.Add(this.tile258);
            this.editor.Controls.Add(this.tile259);
            this.editor.Controls.Add(this.tile260);
            this.editor.Controls.Add(this.tile252);
            this.editor.Controls.Add(this.tile251);
            this.editor.Controls.Add(this.tile243);
            this.editor.Controls.Add(this.tile244);
            this.editor.Controls.Add(this.tile245);
            this.editor.Controls.Add(this.tile246);
            this.editor.Controls.Add(this.tile247);
            this.editor.Controls.Add(this.tile248);
            this.editor.Controls.Add(this.tile249);
            this.editor.Controls.Add(this.tile250);
            this.editor.Controls.Add(this.tile242);
            this.editor.Controls.Add(this.tile241);
            this.editor.Controls.Add(this.tile233);
            this.editor.Controls.Add(this.tile234);
            this.editor.Controls.Add(this.tile235);
            this.editor.Controls.Add(this.tile236);
            this.editor.Controls.Add(this.tile237);
            this.editor.Controls.Add(this.tile238);
            this.editor.Controls.Add(this.tile240);
            this.editor.Controls.Add(this.tile239);
            this.editor.Controls.Add(this.tile232);
            this.editor.Controls.Add(this.tile231);
            this.editor.Controls.Add(this.tile228);
            this.editor.Controls.Add(this.tile227);
            this.editor.Controls.Add(this.tile226);
            this.editor.Controls.Add(this.tile225);
            this.editor.Controls.Add(this.tile224);
            this.editor.Controls.Add(this.tile223);
            this.editor.Controls.Add(this.tile221);
            this.editor.Controls.Add(this.tile222);
            this.editor.Controls.Add(this.tile229);
            this.editor.Controls.Add(this.tile230);
            this.editor.Controls.Add(this.tile213);
            this.editor.Controls.Add(this.tile214);
            this.editor.Controls.Add(this.tile215);
            this.editor.Controls.Add(this.tile216);
            this.editor.Controls.Add(this.tile217);
            this.editor.Controls.Add(this.tile218);
            this.editor.Controls.Add(this.tile219);
            this.editor.Controls.Add(this.tile220);
            this.editor.Controls.Add(this.tile212);
            this.editor.Controls.Add(this.tile211);
            this.editor.Controls.Add(this.tile203);
            this.editor.Controls.Add(this.tile204);
            this.editor.Controls.Add(this.tile205);
            this.editor.Controls.Add(this.tile206);
            this.editor.Controls.Add(this.tile207);
            this.editor.Controls.Add(this.tile208);
            this.editor.Controls.Add(this.tile209);
            this.editor.Controls.Add(this.tile210);
            this.editor.Controls.Add(this.tile202);
            this.editor.Controls.Add(this.tile201);
            this.editor.Controls.Add(this.tile193);
            this.editor.Controls.Add(this.tile194);
            this.editor.Controls.Add(this.tile195);
            this.editor.Controls.Add(this.tile196);
            this.editor.Controls.Add(this.tile197);
            this.editor.Controls.Add(this.tile198);
            this.editor.Controls.Add(this.tile200);
            this.editor.Controls.Add(this.tile199);
            this.editor.Controls.Add(this.tile192);
            this.editor.Controls.Add(this.tile191);
            this.editor.Controls.Add(this.tile188);
            this.editor.Controls.Add(this.tile187);
            this.editor.Controls.Add(this.tile186);
            this.editor.Controls.Add(this.tile185);
            this.editor.Controls.Add(this.tile184);
            this.editor.Controls.Add(this.tile183);
            this.editor.Controls.Add(this.tile181);
            this.editor.Controls.Add(this.tile182);
            this.editor.Controls.Add(this.tile189);
            this.editor.Controls.Add(this.tile190);
            this.editor.Controls.Add(this.tile173);
            this.editor.Controls.Add(this.tile174);
            this.editor.Controls.Add(this.tile175);
            this.editor.Controls.Add(this.tile176);
            this.editor.Controls.Add(this.tile177);
            this.editor.Controls.Add(this.tile178);
            this.editor.Controls.Add(this.tile179);
            this.editor.Controls.Add(this.tile180);
            this.editor.Controls.Add(this.tile172);
            this.editor.Controls.Add(this.tile171);
            this.editor.Controls.Add(this.tile163);
            this.editor.Controls.Add(this.tile164);
            this.editor.Controls.Add(this.tile165);
            this.editor.Controls.Add(this.tile166);
            this.editor.Controls.Add(this.tile167);
            this.editor.Controls.Add(this.tile168);
            this.editor.Controls.Add(this.tile169);
            this.editor.Controls.Add(this.tile170);
            this.editor.Controls.Add(this.tile162);
            this.editor.Controls.Add(this.tile161);
            this.editor.Controls.Add(this.tile153);
            this.editor.Controls.Add(this.tile154);
            this.editor.Controls.Add(this.tile155);
            this.editor.Controls.Add(this.tile156);
            this.editor.Controls.Add(this.tile157);
            this.editor.Controls.Add(this.tile158);
            this.editor.Controls.Add(this.tile160);
            this.editor.Controls.Add(this.tile159);
            this.editor.Controls.Add(this.tile152);
            this.editor.Controls.Add(this.tile151);
            this.editor.Controls.Add(this.tile148);
            this.editor.Controls.Add(this.tile147);
            this.editor.Controls.Add(this.tile146);
            this.editor.Controls.Add(this.tile145);
            this.editor.Controls.Add(this.tile144);
            this.editor.Controls.Add(this.tile143);
            this.editor.Controls.Add(this.tile141);
            this.editor.Controls.Add(this.tile142);
            this.editor.Controls.Add(this.tile149);
            this.editor.Controls.Add(this.tile150);
            this.editor.Controls.Add(this.tile133);
            this.editor.Controls.Add(this.tile134);
            this.editor.Controls.Add(this.tile135);
            this.editor.Controls.Add(this.tile136);
            this.editor.Controls.Add(this.tile137);
            this.editor.Controls.Add(this.tile138);
            this.editor.Controls.Add(this.tile139);
            this.editor.Controls.Add(this.tile140);
            this.editor.Controls.Add(this.tile132);
            this.editor.Controls.Add(this.tile131);
            this.editor.Controls.Add(this.tile123);
            this.editor.Controls.Add(this.tile124);
            this.editor.Controls.Add(this.tile125);
            this.editor.Controls.Add(this.tile126);
            this.editor.Controls.Add(this.tile127);
            this.editor.Controls.Add(this.tile128);
            this.editor.Controls.Add(this.tile129);
            this.editor.Controls.Add(this.tile130);
            this.editor.Controls.Add(this.tile122);
            this.editor.Controls.Add(this.tile121);
            this.editor.Controls.Add(this.tile113);
            this.editor.Controls.Add(this.tile114);
            this.editor.Controls.Add(this.tile115);
            this.editor.Controls.Add(this.tile116);
            this.editor.Controls.Add(this.tile117);
            this.editor.Controls.Add(this.tile118);
            this.editor.Controls.Add(this.tile120);
            this.editor.Controls.Add(this.tile119);
            this.editor.Controls.Add(this.tile112);
            this.editor.Controls.Add(this.tile111);
            this.editor.Controls.Add(this.tile108);
            this.editor.Controls.Add(this.tile107);
            this.editor.Controls.Add(this.tile106);
            this.editor.Controls.Add(this.tile105);
            this.editor.Controls.Add(this.tile104);
            this.editor.Controls.Add(this.tile103);
            this.editor.Controls.Add(this.tile101);
            this.editor.Controls.Add(this.tile102);
            this.editor.Controls.Add(this.tile109);
            this.editor.Controls.Add(this.tile110);
            this.editor.Controls.Add(this.tile93);
            this.editor.Controls.Add(this.tile94);
            this.editor.Controls.Add(this.tile95);
            this.editor.Controls.Add(this.tile96);
            this.editor.Controls.Add(this.tile97);
            this.editor.Controls.Add(this.tile98);
            this.editor.Controls.Add(this.tile99);
            this.editor.Controls.Add(this.tile100);
            this.editor.Controls.Add(this.tile92);
            this.editor.Controls.Add(this.tile91);
            this.editor.Controls.Add(this.tile83);
            this.editor.Controls.Add(this.tile84);
            this.editor.Controls.Add(this.tile85);
            this.editor.Controls.Add(this.tile86);
            this.editor.Controls.Add(this.tile87);
            this.editor.Controls.Add(this.tile88);
            this.editor.Controls.Add(this.tile89);
            this.editor.Controls.Add(this.tile90);
            this.editor.Controls.Add(this.tile82);
            this.editor.Controls.Add(this.tile81);
            this.editor.Controls.Add(this.tile73);
            this.editor.Controls.Add(this.tile74);
            this.editor.Controls.Add(this.tile75);
            this.editor.Controls.Add(this.tile76);
            this.editor.Controls.Add(this.tile77);
            this.editor.Controls.Add(this.tile78);
            this.editor.Controls.Add(this.tile80);
            this.editor.Controls.Add(this.tile79);
            this.editor.Controls.Add(this.tile72);
            this.editor.Controls.Add(this.tile71);
            this.editor.Controls.Add(this.tile68);
            this.editor.Controls.Add(this.tile67);
            this.editor.Controls.Add(this.tile66);
            this.editor.Controls.Add(this.tile65);
            this.editor.Controls.Add(this.tile64);
            this.editor.Controls.Add(this.tile63);
            this.editor.Controls.Add(this.tile61);
            this.editor.Controls.Add(this.tile62);
            this.editor.Controls.Add(this.tile69);
            this.editor.Controls.Add(this.tile70);
            this.editor.Controls.Add(this.tile53);
            this.editor.Controls.Add(this.tile54);
            this.editor.Controls.Add(this.tile55);
            this.editor.Controls.Add(this.tile56);
            this.editor.Controls.Add(this.tile57);
            this.editor.Controls.Add(this.tile58);
            this.editor.Controls.Add(this.tile59);
            this.editor.Controls.Add(this.tile60);
            this.editor.Controls.Add(this.tile52);
            this.editor.Controls.Add(this.tile51);
            this.editor.Controls.Add(this.tile43);
            this.editor.Controls.Add(this.tile44);
            this.editor.Controls.Add(this.tile45);
            this.editor.Controls.Add(this.tile46);
            this.editor.Controls.Add(this.tile47);
            this.editor.Controls.Add(this.tile48);
            this.editor.Controls.Add(this.tile49);
            this.editor.Controls.Add(this.tile50);
            this.editor.Controls.Add(this.tile42);
            this.editor.Controls.Add(this.tile41);
            this.editor.Controls.Add(this.tile33);
            this.editor.Controls.Add(this.tile34);
            this.editor.Controls.Add(this.tile35);
            this.editor.Controls.Add(this.tile36);
            this.editor.Controls.Add(this.tile37);
            this.editor.Controls.Add(this.tile38);
            this.editor.Controls.Add(this.tile40);
            this.editor.Controls.Add(this.tile39);
            this.editor.Controls.Add(this.tile32);
            this.editor.Controls.Add(this.tile31);
            this.editor.Controls.Add(this.tile28);
            this.editor.Controls.Add(this.tile27);
            this.editor.Controls.Add(this.tile26);
            this.editor.Controls.Add(this.tile25);
            this.editor.Controls.Add(this.tile24);
            this.editor.Controls.Add(this.tile23);
            this.editor.Controls.Add(this.tile21);
            this.editor.Controls.Add(this.tile22);
            this.editor.Controls.Add(this.tile29);
            this.editor.Controls.Add(this.tile30);
            this.editor.Controls.Add(this.tile13);
            this.editor.Controls.Add(this.tile14);
            this.editor.Controls.Add(this.tile15);
            this.editor.Controls.Add(this.tile16);
            this.editor.Controls.Add(this.tile17);
            this.editor.Controls.Add(this.tile18);
            this.editor.Controls.Add(this.tile19);
            this.editor.Controls.Add(this.tile20);
            this.editor.Controls.Add(this.tile12);
            this.editor.Controls.Add(this.tile11);
            this.editor.Controls.Add(this.tile3);
            this.editor.Controls.Add(this.tile4);
            this.editor.Controls.Add(this.tile5);
            this.editor.Controls.Add(this.tile6);
            this.editor.Controls.Add(this.tile7);
            this.editor.Controls.Add(this.tile8);
            this.editor.Controls.Add(this.tile9);
            this.editor.Controls.Add(this.tile10);
            this.editor.Controls.Add(this.tile2);
            this.editor.Controls.Add(this.tile1);
            this.editor.Location = new System.Drawing.Point(12, 22);
            this.editor.Name = "editor";
            this.editor.Size = new System.Drawing.Size(1530, 840);
            this.editor.TabIndex = 7;
            this.editor.TabStop = false;
            this.editor.Text = "Map Editor";
            this.editor.Enter += new System.EventHandler(this.editor_Enter);
            // 
            // tile873
            // 
            this.tile873.BackColor = System.Drawing.Color.White;
            this.tile873.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile873.Location = new System.Drawing.Point(1222, 796);
            this.tile873.Name = "tile873";
            this.tile873.Size = new System.Drawing.Size(32, 31);
            this.tile873.TabIndex = 924;
            this.tile873.TabStop = false;
            // 
            // tile874
            // 
            this.tile874.BackColor = System.Drawing.Color.White;
            this.tile874.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile874.Location = new System.Drawing.Point(1260, 796);
            this.tile874.Name = "tile874";
            this.tile874.Size = new System.Drawing.Size(32, 31);
            this.tile874.TabIndex = 923;
            this.tile874.TabStop = false;
            // 
            // tile875
            // 
            this.tile875.BackColor = System.Drawing.Color.White;
            this.tile875.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile875.Location = new System.Drawing.Point(1298, 796);
            this.tile875.Name = "tile875";
            this.tile875.Size = new System.Drawing.Size(32, 31);
            this.tile875.TabIndex = 922;
            this.tile875.TabStop = false;
            // 
            // tile876
            // 
            this.tile876.BackColor = System.Drawing.Color.White;
            this.tile876.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile876.Location = new System.Drawing.Point(1336, 796);
            this.tile876.Name = "tile876";
            this.tile876.Size = new System.Drawing.Size(32, 31);
            this.tile876.TabIndex = 921;
            this.tile876.TabStop = false;
            // 
            // tile877
            // 
            this.tile877.BackColor = System.Drawing.Color.White;
            this.tile877.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile877.Location = new System.Drawing.Point(1374, 796);
            this.tile877.Name = "tile877";
            this.tile877.Size = new System.Drawing.Size(32, 31);
            this.tile877.TabIndex = 920;
            this.tile877.TabStop = false;
            // 
            // tile878
            // 
            this.tile878.BackColor = System.Drawing.Color.White;
            this.tile878.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile878.Location = new System.Drawing.Point(1412, 796);
            this.tile878.Name = "tile878";
            this.tile878.Size = new System.Drawing.Size(32, 31);
            this.tile878.TabIndex = 919;
            this.tile878.TabStop = false;
            // 
            // tile880
            // 
            this.tile880.BackColor = System.Drawing.Color.White;
            this.tile880.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile880.Location = new System.Drawing.Point(1488, 796);
            this.tile880.Name = "tile880";
            this.tile880.Size = new System.Drawing.Size(32, 31);
            this.tile880.TabIndex = 918;
            this.tile880.TabStop = false;
            // 
            // tile879
            // 
            this.tile879.BackColor = System.Drawing.Color.White;
            this.tile879.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile879.Location = new System.Drawing.Point(1450, 796);
            this.tile879.Name = "tile879";
            this.tile879.Size = new System.Drawing.Size(32, 31);
            this.tile879.TabIndex = 917;
            this.tile879.TabStop = false;
            // 
            // tile872
            // 
            this.tile872.BackColor = System.Drawing.Color.White;
            this.tile872.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile872.Location = new System.Drawing.Point(1184, 796);
            this.tile872.Name = "tile872";
            this.tile872.Size = new System.Drawing.Size(32, 31);
            this.tile872.TabIndex = 916;
            this.tile872.TabStop = false;
            // 
            // tile871
            // 
            this.tile871.BackColor = System.Drawing.Color.White;
            this.tile871.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile871.Location = new System.Drawing.Point(1146, 796);
            this.tile871.Name = "tile871";
            this.tile871.Size = new System.Drawing.Size(32, 31);
            this.tile871.TabIndex = 915;
            this.tile871.TabStop = false;
            // 
            // tile868
            // 
            this.tile868.BackColor = System.Drawing.Color.White;
            this.tile868.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile868.Location = new System.Drawing.Point(1032, 796);
            this.tile868.Name = "tile868";
            this.tile868.Size = new System.Drawing.Size(32, 31);
            this.tile868.TabIndex = 914;
            this.tile868.TabStop = false;
            // 
            // tile867
            // 
            this.tile867.BackColor = System.Drawing.Color.White;
            this.tile867.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile867.Location = new System.Drawing.Point(994, 796);
            this.tile867.Name = "tile867";
            this.tile867.Size = new System.Drawing.Size(32, 31);
            this.tile867.TabIndex = 913;
            this.tile867.TabStop = false;
            // 
            // tile866
            // 
            this.tile866.BackColor = System.Drawing.Color.White;
            this.tile866.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile866.Location = new System.Drawing.Point(956, 796);
            this.tile866.Name = "tile866";
            this.tile866.Size = new System.Drawing.Size(32, 31);
            this.tile866.TabIndex = 912;
            this.tile866.TabStop = false;
            // 
            // tile865
            // 
            this.tile865.BackColor = System.Drawing.Color.White;
            this.tile865.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile865.Location = new System.Drawing.Point(918, 796);
            this.tile865.Name = "tile865";
            this.tile865.Size = new System.Drawing.Size(32, 31);
            this.tile865.TabIndex = 911;
            this.tile865.TabStop = false;
            // 
            // tile864
            // 
            this.tile864.BackColor = System.Drawing.Color.White;
            this.tile864.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile864.Location = new System.Drawing.Point(880, 796);
            this.tile864.Name = "tile864";
            this.tile864.Size = new System.Drawing.Size(32, 31);
            this.tile864.TabIndex = 910;
            this.tile864.TabStop = false;
            // 
            // tile863
            // 
            this.tile863.BackColor = System.Drawing.Color.White;
            this.tile863.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile863.Location = new System.Drawing.Point(842, 796);
            this.tile863.Name = "tile863";
            this.tile863.Size = new System.Drawing.Size(32, 31);
            this.tile863.TabIndex = 909;
            this.tile863.TabStop = false;
            // 
            // tile861
            // 
            this.tile861.BackColor = System.Drawing.Color.White;
            this.tile861.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile861.Location = new System.Drawing.Point(766, 796);
            this.tile861.Name = "tile861";
            this.tile861.Size = new System.Drawing.Size(32, 31);
            this.tile861.TabIndex = 908;
            this.tile861.TabStop = false;
            // 
            // tile862
            // 
            this.tile862.BackColor = System.Drawing.Color.White;
            this.tile862.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile862.Location = new System.Drawing.Point(804, 796);
            this.tile862.Name = "tile862";
            this.tile862.Size = new System.Drawing.Size(32, 31);
            this.tile862.TabIndex = 907;
            this.tile862.TabStop = false;
            // 
            // tile869
            // 
            this.tile869.BackColor = System.Drawing.Color.White;
            this.tile869.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile869.Location = new System.Drawing.Point(1070, 796);
            this.tile869.Name = "tile869";
            this.tile869.Size = new System.Drawing.Size(32, 31);
            this.tile869.TabIndex = 906;
            this.tile869.TabStop = false;
            // 
            // tile870
            // 
            this.tile870.BackColor = System.Drawing.Color.White;
            this.tile870.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile870.Location = new System.Drawing.Point(1108, 796);
            this.tile870.Name = "tile870";
            this.tile870.Size = new System.Drawing.Size(32, 31);
            this.tile870.TabIndex = 905;
            this.tile870.TabStop = false;
            // 
            // tile853
            // 
            this.tile853.BackColor = System.Drawing.Color.White;
            this.tile853.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile853.Location = new System.Drawing.Point(462, 796);
            this.tile853.Name = "tile853";
            this.tile853.Size = new System.Drawing.Size(32, 31);
            this.tile853.TabIndex = 904;
            this.tile853.TabStop = false;
            // 
            // tile854
            // 
            this.tile854.BackColor = System.Drawing.Color.White;
            this.tile854.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile854.Location = new System.Drawing.Point(500, 796);
            this.tile854.Name = "tile854";
            this.tile854.Size = new System.Drawing.Size(32, 31);
            this.tile854.TabIndex = 903;
            this.tile854.TabStop = false;
            // 
            // tile855
            // 
            this.tile855.BackColor = System.Drawing.Color.White;
            this.tile855.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile855.Location = new System.Drawing.Point(538, 796);
            this.tile855.Name = "tile855";
            this.tile855.Size = new System.Drawing.Size(32, 31);
            this.tile855.TabIndex = 902;
            this.tile855.TabStop = false;
            // 
            // tile856
            // 
            this.tile856.BackColor = System.Drawing.Color.White;
            this.tile856.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile856.Location = new System.Drawing.Point(576, 796);
            this.tile856.Name = "tile856";
            this.tile856.Size = new System.Drawing.Size(32, 31);
            this.tile856.TabIndex = 901;
            this.tile856.TabStop = false;
            // 
            // tile857
            // 
            this.tile857.BackColor = System.Drawing.Color.White;
            this.tile857.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile857.Location = new System.Drawing.Point(614, 796);
            this.tile857.Name = "tile857";
            this.tile857.Size = new System.Drawing.Size(32, 31);
            this.tile857.TabIndex = 900;
            this.tile857.TabStop = false;
            // 
            // tile858
            // 
            this.tile858.BackColor = System.Drawing.Color.White;
            this.tile858.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile858.Location = new System.Drawing.Point(652, 796);
            this.tile858.Name = "tile858";
            this.tile858.Size = new System.Drawing.Size(32, 31);
            this.tile858.TabIndex = 899;
            this.tile858.TabStop = false;
            // 
            // tile859
            // 
            this.tile859.BackColor = System.Drawing.Color.White;
            this.tile859.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile859.Location = new System.Drawing.Point(690, 796);
            this.tile859.Name = "tile859";
            this.tile859.Size = new System.Drawing.Size(32, 31);
            this.tile859.TabIndex = 898;
            this.tile859.TabStop = false;
            // 
            // tile860
            // 
            this.tile860.BackColor = System.Drawing.Color.White;
            this.tile860.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile860.Location = new System.Drawing.Point(728, 796);
            this.tile860.Name = "tile860";
            this.tile860.Size = new System.Drawing.Size(32, 31);
            this.tile860.TabIndex = 897;
            this.tile860.TabStop = false;
            // 
            // tile852
            // 
            this.tile852.BackColor = System.Drawing.Color.White;
            this.tile852.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile852.Location = new System.Drawing.Point(424, 796);
            this.tile852.Name = "tile852";
            this.tile852.Size = new System.Drawing.Size(32, 31);
            this.tile852.TabIndex = 896;
            this.tile852.TabStop = false;
            // 
            // tile851
            // 
            this.tile851.BackColor = System.Drawing.Color.White;
            this.tile851.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile851.Location = new System.Drawing.Point(386, 796);
            this.tile851.Name = "tile851";
            this.tile851.Size = new System.Drawing.Size(32, 31);
            this.tile851.TabIndex = 895;
            this.tile851.TabStop = false;
            // 
            // tile843
            // 
            this.tile843.BackColor = System.Drawing.Color.White;
            this.tile843.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile843.Location = new System.Drawing.Point(82, 796);
            this.tile843.Name = "tile843";
            this.tile843.Size = new System.Drawing.Size(32, 31);
            this.tile843.TabIndex = 894;
            this.tile843.TabStop = false;
            // 
            // tile844
            // 
            this.tile844.BackColor = System.Drawing.Color.White;
            this.tile844.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile844.Location = new System.Drawing.Point(120, 796);
            this.tile844.Name = "tile844";
            this.tile844.Size = new System.Drawing.Size(32, 31);
            this.tile844.TabIndex = 893;
            this.tile844.TabStop = false;
            // 
            // tile845
            // 
            this.tile845.BackColor = System.Drawing.Color.White;
            this.tile845.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile845.Location = new System.Drawing.Point(158, 796);
            this.tile845.Name = "tile845";
            this.tile845.Size = new System.Drawing.Size(32, 31);
            this.tile845.TabIndex = 892;
            this.tile845.TabStop = false;
            // 
            // tile846
            // 
            this.tile846.BackColor = System.Drawing.Color.White;
            this.tile846.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile846.Location = new System.Drawing.Point(196, 796);
            this.tile846.Name = "tile846";
            this.tile846.Size = new System.Drawing.Size(32, 31);
            this.tile846.TabIndex = 891;
            this.tile846.TabStop = false;
            // 
            // tile847
            // 
            this.tile847.BackColor = System.Drawing.Color.White;
            this.tile847.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile847.Location = new System.Drawing.Point(234, 796);
            this.tile847.Name = "tile847";
            this.tile847.Size = new System.Drawing.Size(32, 31);
            this.tile847.TabIndex = 890;
            this.tile847.TabStop = false;
            // 
            // tile848
            // 
            this.tile848.BackColor = System.Drawing.Color.White;
            this.tile848.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile848.Location = new System.Drawing.Point(272, 796);
            this.tile848.Name = "tile848";
            this.tile848.Size = new System.Drawing.Size(32, 31);
            this.tile848.TabIndex = 889;
            this.tile848.TabStop = false;
            // 
            // tile849
            // 
            this.tile849.BackColor = System.Drawing.Color.White;
            this.tile849.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile849.Location = new System.Drawing.Point(310, 796);
            this.tile849.Name = "tile849";
            this.tile849.Size = new System.Drawing.Size(32, 31);
            this.tile849.TabIndex = 888;
            this.tile849.TabStop = false;
            // 
            // tile850
            // 
            this.tile850.BackColor = System.Drawing.Color.White;
            this.tile850.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile850.Location = new System.Drawing.Point(348, 796);
            this.tile850.Name = "tile850";
            this.tile850.Size = new System.Drawing.Size(32, 31);
            this.tile850.TabIndex = 887;
            this.tile850.TabStop = false;
            // 
            // tile842
            // 
            this.tile842.BackColor = System.Drawing.Color.White;
            this.tile842.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile842.Location = new System.Drawing.Point(44, 796);
            this.tile842.Name = "tile842";
            this.tile842.Size = new System.Drawing.Size(32, 31);
            this.tile842.TabIndex = 886;
            this.tile842.TabStop = false;
            // 
            // tile841
            // 
            this.tile841.BackColor = System.Drawing.Color.White;
            this.tile841.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile841.Location = new System.Drawing.Point(6, 796);
            this.tile841.Name = "tile841";
            this.tile841.Size = new System.Drawing.Size(32, 31);
            this.tile841.TabIndex = 885;
            this.tile841.TabStop = false;
            // 
            // tile833
            // 
            this.tile833.BackColor = System.Drawing.Color.White;
            this.tile833.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile833.Location = new System.Drawing.Point(1222, 759);
            this.tile833.Name = "tile833";
            this.tile833.Size = new System.Drawing.Size(32, 31);
            this.tile833.TabIndex = 884;
            this.tile833.TabStop = false;
            // 
            // tile834
            // 
            this.tile834.BackColor = System.Drawing.Color.White;
            this.tile834.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile834.Location = new System.Drawing.Point(1260, 759);
            this.tile834.Name = "tile834";
            this.tile834.Size = new System.Drawing.Size(32, 31);
            this.tile834.TabIndex = 883;
            this.tile834.TabStop = false;
            // 
            // tile835
            // 
            this.tile835.BackColor = System.Drawing.Color.White;
            this.tile835.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile835.Location = new System.Drawing.Point(1298, 759);
            this.tile835.Name = "tile835";
            this.tile835.Size = new System.Drawing.Size(32, 31);
            this.tile835.TabIndex = 882;
            this.tile835.TabStop = false;
            // 
            // tile836
            // 
            this.tile836.BackColor = System.Drawing.Color.White;
            this.tile836.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile836.Location = new System.Drawing.Point(1336, 759);
            this.tile836.Name = "tile836";
            this.tile836.Size = new System.Drawing.Size(32, 31);
            this.tile836.TabIndex = 881;
            this.tile836.TabStop = false;
            // 
            // tile837
            // 
            this.tile837.BackColor = System.Drawing.Color.White;
            this.tile837.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile837.Location = new System.Drawing.Point(1374, 759);
            this.tile837.Name = "tile837";
            this.tile837.Size = new System.Drawing.Size(32, 31);
            this.tile837.TabIndex = 880;
            this.tile837.TabStop = false;
            // 
            // tile838
            // 
            this.tile838.BackColor = System.Drawing.Color.White;
            this.tile838.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile838.Location = new System.Drawing.Point(1412, 759);
            this.tile838.Name = "tile838";
            this.tile838.Size = new System.Drawing.Size(32, 31);
            this.tile838.TabIndex = 879;
            this.tile838.TabStop = false;
            // 
            // tile840
            // 
            this.tile840.BackColor = System.Drawing.Color.White;
            this.tile840.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile840.Location = new System.Drawing.Point(1488, 759);
            this.tile840.Name = "tile840";
            this.tile840.Size = new System.Drawing.Size(32, 31);
            this.tile840.TabIndex = 878;
            this.tile840.TabStop = false;
            // 
            // tile839
            // 
            this.tile839.BackColor = System.Drawing.Color.White;
            this.tile839.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile839.Location = new System.Drawing.Point(1450, 759);
            this.tile839.Name = "tile839";
            this.tile839.Size = new System.Drawing.Size(32, 31);
            this.tile839.TabIndex = 877;
            this.tile839.TabStop = false;
            // 
            // tile832
            // 
            this.tile832.BackColor = System.Drawing.Color.White;
            this.tile832.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile832.Location = new System.Drawing.Point(1184, 759);
            this.tile832.Name = "tile832";
            this.tile832.Size = new System.Drawing.Size(32, 31);
            this.tile832.TabIndex = 876;
            this.tile832.TabStop = false;
            // 
            // tile831
            // 
            this.tile831.BackColor = System.Drawing.Color.White;
            this.tile831.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile831.Location = new System.Drawing.Point(1146, 759);
            this.tile831.Name = "tile831";
            this.tile831.Size = new System.Drawing.Size(32, 31);
            this.tile831.TabIndex = 875;
            this.tile831.TabStop = false;
            // 
            // tile828
            // 
            this.tile828.BackColor = System.Drawing.Color.White;
            this.tile828.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile828.Location = new System.Drawing.Point(1032, 759);
            this.tile828.Name = "tile828";
            this.tile828.Size = new System.Drawing.Size(32, 31);
            this.tile828.TabIndex = 874;
            this.tile828.TabStop = false;
            // 
            // tile827
            // 
            this.tile827.BackColor = System.Drawing.Color.White;
            this.tile827.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile827.Location = new System.Drawing.Point(994, 759);
            this.tile827.Name = "tile827";
            this.tile827.Size = new System.Drawing.Size(32, 31);
            this.tile827.TabIndex = 873;
            this.tile827.TabStop = false;
            // 
            // tile826
            // 
            this.tile826.BackColor = System.Drawing.Color.White;
            this.tile826.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile826.Location = new System.Drawing.Point(956, 759);
            this.tile826.Name = "tile826";
            this.tile826.Size = new System.Drawing.Size(32, 31);
            this.tile826.TabIndex = 872;
            this.tile826.TabStop = false;
            // 
            // tile825
            // 
            this.tile825.BackColor = System.Drawing.Color.White;
            this.tile825.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile825.Location = new System.Drawing.Point(918, 759);
            this.tile825.Name = "tile825";
            this.tile825.Size = new System.Drawing.Size(32, 31);
            this.tile825.TabIndex = 871;
            this.tile825.TabStop = false;
            // 
            // tile824
            // 
            this.tile824.BackColor = System.Drawing.Color.White;
            this.tile824.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile824.Location = new System.Drawing.Point(880, 759);
            this.tile824.Name = "tile824";
            this.tile824.Size = new System.Drawing.Size(32, 31);
            this.tile824.TabIndex = 870;
            this.tile824.TabStop = false;
            // 
            // tile823
            // 
            this.tile823.BackColor = System.Drawing.Color.White;
            this.tile823.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile823.Location = new System.Drawing.Point(842, 759);
            this.tile823.Name = "tile823";
            this.tile823.Size = new System.Drawing.Size(32, 31);
            this.tile823.TabIndex = 869;
            this.tile823.TabStop = false;
            // 
            // tile821
            // 
            this.tile821.BackColor = System.Drawing.Color.White;
            this.tile821.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile821.Location = new System.Drawing.Point(766, 759);
            this.tile821.Name = "tile821";
            this.tile821.Size = new System.Drawing.Size(32, 31);
            this.tile821.TabIndex = 868;
            this.tile821.TabStop = false;
            // 
            // tile822
            // 
            this.tile822.BackColor = System.Drawing.Color.White;
            this.tile822.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile822.Location = new System.Drawing.Point(804, 759);
            this.tile822.Name = "tile822";
            this.tile822.Size = new System.Drawing.Size(32, 31);
            this.tile822.TabIndex = 867;
            this.tile822.TabStop = false;
            // 
            // tile829
            // 
            this.tile829.BackColor = System.Drawing.Color.White;
            this.tile829.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile829.Location = new System.Drawing.Point(1070, 759);
            this.tile829.Name = "tile829";
            this.tile829.Size = new System.Drawing.Size(32, 31);
            this.tile829.TabIndex = 866;
            this.tile829.TabStop = false;
            // 
            // tile830
            // 
            this.tile830.BackColor = System.Drawing.Color.White;
            this.tile830.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile830.Location = new System.Drawing.Point(1108, 759);
            this.tile830.Name = "tile830";
            this.tile830.Size = new System.Drawing.Size(32, 31);
            this.tile830.TabIndex = 865;
            this.tile830.TabStop = false;
            // 
            // tile813
            // 
            this.tile813.BackColor = System.Drawing.Color.White;
            this.tile813.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile813.Location = new System.Drawing.Point(462, 759);
            this.tile813.Name = "tile813";
            this.tile813.Size = new System.Drawing.Size(32, 31);
            this.tile813.TabIndex = 864;
            this.tile813.TabStop = false;
            // 
            // tile814
            // 
            this.tile814.BackColor = System.Drawing.Color.White;
            this.tile814.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile814.Location = new System.Drawing.Point(500, 759);
            this.tile814.Name = "tile814";
            this.tile814.Size = new System.Drawing.Size(32, 31);
            this.tile814.TabIndex = 863;
            this.tile814.TabStop = false;
            // 
            // tile815
            // 
            this.tile815.BackColor = System.Drawing.Color.White;
            this.tile815.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile815.Location = new System.Drawing.Point(538, 759);
            this.tile815.Name = "tile815";
            this.tile815.Size = new System.Drawing.Size(32, 31);
            this.tile815.TabIndex = 862;
            this.tile815.TabStop = false;
            // 
            // tile816
            // 
            this.tile816.BackColor = System.Drawing.Color.White;
            this.tile816.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile816.Location = new System.Drawing.Point(576, 759);
            this.tile816.Name = "tile816";
            this.tile816.Size = new System.Drawing.Size(32, 31);
            this.tile816.TabIndex = 861;
            this.tile816.TabStop = false;
            // 
            // tile817
            // 
            this.tile817.BackColor = System.Drawing.Color.White;
            this.tile817.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile817.Location = new System.Drawing.Point(614, 759);
            this.tile817.Name = "tile817";
            this.tile817.Size = new System.Drawing.Size(32, 31);
            this.tile817.TabIndex = 860;
            this.tile817.TabStop = false;
            // 
            // tile818
            // 
            this.tile818.BackColor = System.Drawing.Color.White;
            this.tile818.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile818.Location = new System.Drawing.Point(652, 759);
            this.tile818.Name = "tile818";
            this.tile818.Size = new System.Drawing.Size(32, 31);
            this.tile818.TabIndex = 859;
            this.tile818.TabStop = false;
            // 
            // tile819
            // 
            this.tile819.BackColor = System.Drawing.Color.White;
            this.tile819.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile819.Location = new System.Drawing.Point(690, 759);
            this.tile819.Name = "tile819";
            this.tile819.Size = new System.Drawing.Size(32, 31);
            this.tile819.TabIndex = 858;
            this.tile819.TabStop = false;
            // 
            // tile820
            // 
            this.tile820.BackColor = System.Drawing.Color.White;
            this.tile820.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile820.Location = new System.Drawing.Point(728, 759);
            this.tile820.Name = "tile820";
            this.tile820.Size = new System.Drawing.Size(32, 31);
            this.tile820.TabIndex = 857;
            this.tile820.TabStop = false;
            // 
            // tile812
            // 
            this.tile812.BackColor = System.Drawing.Color.White;
            this.tile812.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile812.Location = new System.Drawing.Point(424, 759);
            this.tile812.Name = "tile812";
            this.tile812.Size = new System.Drawing.Size(32, 31);
            this.tile812.TabIndex = 856;
            this.tile812.TabStop = false;
            // 
            // tile811
            // 
            this.tile811.BackColor = System.Drawing.Color.White;
            this.tile811.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile811.Location = new System.Drawing.Point(386, 759);
            this.tile811.Name = "tile811";
            this.tile811.Size = new System.Drawing.Size(32, 31);
            this.tile811.TabIndex = 855;
            this.tile811.TabStop = false;
            // 
            // tile803
            // 
            this.tile803.BackColor = System.Drawing.Color.White;
            this.tile803.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile803.Location = new System.Drawing.Point(82, 759);
            this.tile803.Name = "tile803";
            this.tile803.Size = new System.Drawing.Size(32, 31);
            this.tile803.TabIndex = 854;
            this.tile803.TabStop = false;
            // 
            // tile804
            // 
            this.tile804.BackColor = System.Drawing.Color.White;
            this.tile804.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile804.Location = new System.Drawing.Point(120, 759);
            this.tile804.Name = "tile804";
            this.tile804.Size = new System.Drawing.Size(32, 31);
            this.tile804.TabIndex = 853;
            this.tile804.TabStop = false;
            // 
            // tile805
            // 
            this.tile805.BackColor = System.Drawing.Color.White;
            this.tile805.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile805.Location = new System.Drawing.Point(158, 759);
            this.tile805.Name = "tile805";
            this.tile805.Size = new System.Drawing.Size(32, 31);
            this.tile805.TabIndex = 852;
            this.tile805.TabStop = false;
            // 
            // tile806
            // 
            this.tile806.BackColor = System.Drawing.Color.White;
            this.tile806.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile806.Location = new System.Drawing.Point(196, 759);
            this.tile806.Name = "tile806";
            this.tile806.Size = new System.Drawing.Size(32, 31);
            this.tile806.TabIndex = 851;
            this.tile806.TabStop = false;
            // 
            // tile807
            // 
            this.tile807.BackColor = System.Drawing.Color.White;
            this.tile807.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile807.Location = new System.Drawing.Point(234, 759);
            this.tile807.Name = "tile807";
            this.tile807.Size = new System.Drawing.Size(32, 31);
            this.tile807.TabIndex = 850;
            this.tile807.TabStop = false;
            // 
            // tile808
            // 
            this.tile808.BackColor = System.Drawing.Color.White;
            this.tile808.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile808.Location = new System.Drawing.Point(272, 759);
            this.tile808.Name = "tile808";
            this.tile808.Size = new System.Drawing.Size(32, 31);
            this.tile808.TabIndex = 849;
            this.tile808.TabStop = false;
            // 
            // tile809
            // 
            this.tile809.BackColor = System.Drawing.Color.White;
            this.tile809.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile809.Location = new System.Drawing.Point(310, 759);
            this.tile809.Name = "tile809";
            this.tile809.Size = new System.Drawing.Size(32, 31);
            this.tile809.TabIndex = 848;
            this.tile809.TabStop = false;
            // 
            // tile810
            // 
            this.tile810.BackColor = System.Drawing.Color.White;
            this.tile810.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile810.Location = new System.Drawing.Point(348, 759);
            this.tile810.Name = "tile810";
            this.tile810.Size = new System.Drawing.Size(32, 31);
            this.tile810.TabIndex = 847;
            this.tile810.TabStop = false;
            // 
            // tile802
            // 
            this.tile802.BackColor = System.Drawing.Color.White;
            this.tile802.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile802.Location = new System.Drawing.Point(44, 759);
            this.tile802.Name = "tile802";
            this.tile802.Size = new System.Drawing.Size(32, 31);
            this.tile802.TabIndex = 846;
            this.tile802.TabStop = false;
            // 
            // tile801
            // 
            this.tile801.BackColor = System.Drawing.Color.White;
            this.tile801.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile801.Location = new System.Drawing.Point(6, 759);
            this.tile801.Name = "tile801";
            this.tile801.Size = new System.Drawing.Size(32, 31);
            this.tile801.TabIndex = 845;
            this.tile801.TabStop = false;
            // 
            // tile793
            // 
            this.tile793.BackColor = System.Drawing.Color.White;
            this.tile793.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile793.Location = new System.Drawing.Point(1222, 722);
            this.tile793.Name = "tile793";
            this.tile793.Size = new System.Drawing.Size(32, 31);
            this.tile793.TabIndex = 844;
            this.tile793.TabStop = false;
            // 
            // tile794
            // 
            this.tile794.BackColor = System.Drawing.Color.White;
            this.tile794.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile794.Location = new System.Drawing.Point(1260, 722);
            this.tile794.Name = "tile794";
            this.tile794.Size = new System.Drawing.Size(32, 31);
            this.tile794.TabIndex = 843;
            this.tile794.TabStop = false;
            // 
            // tile795
            // 
            this.tile795.BackColor = System.Drawing.Color.White;
            this.tile795.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile795.Location = new System.Drawing.Point(1298, 722);
            this.tile795.Name = "tile795";
            this.tile795.Size = new System.Drawing.Size(32, 31);
            this.tile795.TabIndex = 842;
            this.tile795.TabStop = false;
            // 
            // tile796
            // 
            this.tile796.BackColor = System.Drawing.Color.White;
            this.tile796.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile796.Location = new System.Drawing.Point(1336, 722);
            this.tile796.Name = "tile796";
            this.tile796.Size = new System.Drawing.Size(32, 31);
            this.tile796.TabIndex = 841;
            this.tile796.TabStop = false;
            // 
            // tile797
            // 
            this.tile797.BackColor = System.Drawing.Color.White;
            this.tile797.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile797.Location = new System.Drawing.Point(1374, 722);
            this.tile797.Name = "tile797";
            this.tile797.Size = new System.Drawing.Size(32, 31);
            this.tile797.TabIndex = 840;
            this.tile797.TabStop = false;
            // 
            // tile798
            // 
            this.tile798.BackColor = System.Drawing.Color.White;
            this.tile798.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile798.Location = new System.Drawing.Point(1412, 722);
            this.tile798.Name = "tile798";
            this.tile798.Size = new System.Drawing.Size(32, 31);
            this.tile798.TabIndex = 839;
            this.tile798.TabStop = false;
            // 
            // tile800
            // 
            this.tile800.BackColor = System.Drawing.Color.White;
            this.tile800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile800.Location = new System.Drawing.Point(1488, 722);
            this.tile800.Name = "tile800";
            this.tile800.Size = new System.Drawing.Size(32, 31);
            this.tile800.TabIndex = 838;
            this.tile800.TabStop = false;
            // 
            // tile799
            // 
            this.tile799.BackColor = System.Drawing.Color.White;
            this.tile799.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile799.Location = new System.Drawing.Point(1450, 722);
            this.tile799.Name = "tile799";
            this.tile799.Size = new System.Drawing.Size(32, 31);
            this.tile799.TabIndex = 837;
            this.tile799.TabStop = false;
            // 
            // tile792
            // 
            this.tile792.BackColor = System.Drawing.Color.White;
            this.tile792.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile792.Location = new System.Drawing.Point(1184, 722);
            this.tile792.Name = "tile792";
            this.tile792.Size = new System.Drawing.Size(32, 31);
            this.tile792.TabIndex = 836;
            this.tile792.TabStop = false;
            // 
            // tile791
            // 
            this.tile791.BackColor = System.Drawing.Color.White;
            this.tile791.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile791.Location = new System.Drawing.Point(1146, 722);
            this.tile791.Name = "tile791";
            this.tile791.Size = new System.Drawing.Size(32, 31);
            this.tile791.TabIndex = 835;
            this.tile791.TabStop = false;
            // 
            // tile788
            // 
            this.tile788.BackColor = System.Drawing.Color.White;
            this.tile788.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile788.Location = new System.Drawing.Point(1032, 722);
            this.tile788.Name = "tile788";
            this.tile788.Size = new System.Drawing.Size(32, 31);
            this.tile788.TabIndex = 834;
            this.tile788.TabStop = false;
            // 
            // tile787
            // 
            this.tile787.BackColor = System.Drawing.Color.White;
            this.tile787.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile787.Location = new System.Drawing.Point(994, 722);
            this.tile787.Name = "tile787";
            this.tile787.Size = new System.Drawing.Size(32, 31);
            this.tile787.TabIndex = 833;
            this.tile787.TabStop = false;
            // 
            // tile786
            // 
            this.tile786.BackColor = System.Drawing.Color.White;
            this.tile786.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile786.Location = new System.Drawing.Point(956, 722);
            this.tile786.Name = "tile786";
            this.tile786.Size = new System.Drawing.Size(32, 31);
            this.tile786.TabIndex = 832;
            this.tile786.TabStop = false;
            // 
            // tile785
            // 
            this.tile785.BackColor = System.Drawing.Color.White;
            this.tile785.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile785.Location = new System.Drawing.Point(918, 722);
            this.tile785.Name = "tile785";
            this.tile785.Size = new System.Drawing.Size(32, 31);
            this.tile785.TabIndex = 831;
            this.tile785.TabStop = false;
            // 
            // tile784
            // 
            this.tile784.BackColor = System.Drawing.Color.White;
            this.tile784.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile784.Location = new System.Drawing.Point(880, 722);
            this.tile784.Name = "tile784";
            this.tile784.Size = new System.Drawing.Size(32, 31);
            this.tile784.TabIndex = 830;
            this.tile784.TabStop = false;
            // 
            // tile783
            // 
            this.tile783.BackColor = System.Drawing.Color.White;
            this.tile783.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile783.Location = new System.Drawing.Point(842, 722);
            this.tile783.Name = "tile783";
            this.tile783.Size = new System.Drawing.Size(32, 31);
            this.tile783.TabIndex = 829;
            this.tile783.TabStop = false;
            // 
            // tile781
            // 
            this.tile781.BackColor = System.Drawing.Color.White;
            this.tile781.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile781.Location = new System.Drawing.Point(766, 722);
            this.tile781.Name = "tile781";
            this.tile781.Size = new System.Drawing.Size(32, 31);
            this.tile781.TabIndex = 828;
            this.tile781.TabStop = false;
            // 
            // tile782
            // 
            this.tile782.BackColor = System.Drawing.Color.White;
            this.tile782.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile782.Location = new System.Drawing.Point(804, 722);
            this.tile782.Name = "tile782";
            this.tile782.Size = new System.Drawing.Size(32, 31);
            this.tile782.TabIndex = 827;
            this.tile782.TabStop = false;
            // 
            // tile789
            // 
            this.tile789.BackColor = System.Drawing.Color.White;
            this.tile789.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile789.Location = new System.Drawing.Point(1070, 722);
            this.tile789.Name = "tile789";
            this.tile789.Size = new System.Drawing.Size(32, 31);
            this.tile789.TabIndex = 826;
            this.tile789.TabStop = false;
            // 
            // tile790
            // 
            this.tile790.BackColor = System.Drawing.Color.White;
            this.tile790.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile790.Location = new System.Drawing.Point(1108, 722);
            this.tile790.Name = "tile790";
            this.tile790.Size = new System.Drawing.Size(32, 31);
            this.tile790.TabIndex = 825;
            this.tile790.TabStop = false;
            // 
            // tile773
            // 
            this.tile773.BackColor = System.Drawing.Color.White;
            this.tile773.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile773.Location = new System.Drawing.Point(462, 722);
            this.tile773.Name = "tile773";
            this.tile773.Size = new System.Drawing.Size(32, 31);
            this.tile773.TabIndex = 824;
            this.tile773.TabStop = false;
            // 
            // tile774
            // 
            this.tile774.BackColor = System.Drawing.Color.White;
            this.tile774.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile774.Location = new System.Drawing.Point(500, 722);
            this.tile774.Name = "tile774";
            this.tile774.Size = new System.Drawing.Size(32, 31);
            this.tile774.TabIndex = 823;
            this.tile774.TabStop = false;
            // 
            // tile775
            // 
            this.tile775.BackColor = System.Drawing.Color.White;
            this.tile775.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile775.Location = new System.Drawing.Point(538, 722);
            this.tile775.Name = "tile775";
            this.tile775.Size = new System.Drawing.Size(32, 31);
            this.tile775.TabIndex = 822;
            this.tile775.TabStop = false;
            // 
            // tile776
            // 
            this.tile776.BackColor = System.Drawing.Color.White;
            this.tile776.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile776.Location = new System.Drawing.Point(576, 722);
            this.tile776.Name = "tile776";
            this.tile776.Size = new System.Drawing.Size(32, 31);
            this.tile776.TabIndex = 821;
            this.tile776.TabStop = false;
            // 
            // tile777
            // 
            this.tile777.BackColor = System.Drawing.Color.White;
            this.tile777.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile777.Location = new System.Drawing.Point(614, 722);
            this.tile777.Name = "tile777";
            this.tile777.Size = new System.Drawing.Size(32, 31);
            this.tile777.TabIndex = 820;
            this.tile777.TabStop = false;
            // 
            // tile778
            // 
            this.tile778.BackColor = System.Drawing.Color.White;
            this.tile778.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile778.Location = new System.Drawing.Point(652, 722);
            this.tile778.Name = "tile778";
            this.tile778.Size = new System.Drawing.Size(32, 31);
            this.tile778.TabIndex = 819;
            this.tile778.TabStop = false;
            // 
            // tile779
            // 
            this.tile779.BackColor = System.Drawing.Color.White;
            this.tile779.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile779.Location = new System.Drawing.Point(690, 722);
            this.tile779.Name = "tile779";
            this.tile779.Size = new System.Drawing.Size(32, 31);
            this.tile779.TabIndex = 818;
            this.tile779.TabStop = false;
            // 
            // tile780
            // 
            this.tile780.BackColor = System.Drawing.Color.White;
            this.tile780.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile780.Location = new System.Drawing.Point(728, 722);
            this.tile780.Name = "tile780";
            this.tile780.Size = new System.Drawing.Size(32, 31);
            this.tile780.TabIndex = 817;
            this.tile780.TabStop = false;
            // 
            // tile772
            // 
            this.tile772.BackColor = System.Drawing.Color.White;
            this.tile772.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile772.Location = new System.Drawing.Point(424, 722);
            this.tile772.Name = "tile772";
            this.tile772.Size = new System.Drawing.Size(32, 31);
            this.tile772.TabIndex = 816;
            this.tile772.TabStop = false;
            // 
            // tile771
            // 
            this.tile771.BackColor = System.Drawing.Color.White;
            this.tile771.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile771.Location = new System.Drawing.Point(386, 722);
            this.tile771.Name = "tile771";
            this.tile771.Size = new System.Drawing.Size(32, 31);
            this.tile771.TabIndex = 815;
            this.tile771.TabStop = false;
            // 
            // tile763
            // 
            this.tile763.BackColor = System.Drawing.Color.White;
            this.tile763.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile763.Location = new System.Drawing.Point(82, 722);
            this.tile763.Name = "tile763";
            this.tile763.Size = new System.Drawing.Size(32, 31);
            this.tile763.TabIndex = 814;
            this.tile763.TabStop = false;
            // 
            // tile764
            // 
            this.tile764.BackColor = System.Drawing.Color.White;
            this.tile764.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile764.Location = new System.Drawing.Point(120, 722);
            this.tile764.Name = "tile764";
            this.tile764.Size = new System.Drawing.Size(32, 31);
            this.tile764.TabIndex = 813;
            this.tile764.TabStop = false;
            // 
            // tile765
            // 
            this.tile765.BackColor = System.Drawing.Color.White;
            this.tile765.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile765.Location = new System.Drawing.Point(158, 722);
            this.tile765.Name = "tile765";
            this.tile765.Size = new System.Drawing.Size(32, 31);
            this.tile765.TabIndex = 812;
            this.tile765.TabStop = false;
            // 
            // tile766
            // 
            this.tile766.BackColor = System.Drawing.Color.White;
            this.tile766.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile766.Location = new System.Drawing.Point(196, 722);
            this.tile766.Name = "tile766";
            this.tile766.Size = new System.Drawing.Size(32, 31);
            this.tile766.TabIndex = 811;
            this.tile766.TabStop = false;
            // 
            // tile767
            // 
            this.tile767.BackColor = System.Drawing.Color.White;
            this.tile767.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile767.Location = new System.Drawing.Point(234, 722);
            this.tile767.Name = "tile767";
            this.tile767.Size = new System.Drawing.Size(32, 31);
            this.tile767.TabIndex = 810;
            this.tile767.TabStop = false;
            // 
            // tile768
            // 
            this.tile768.BackColor = System.Drawing.Color.White;
            this.tile768.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile768.Location = new System.Drawing.Point(272, 722);
            this.tile768.Name = "tile768";
            this.tile768.Size = new System.Drawing.Size(32, 31);
            this.tile768.TabIndex = 809;
            this.tile768.TabStop = false;
            // 
            // tile769
            // 
            this.tile769.BackColor = System.Drawing.Color.White;
            this.tile769.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile769.Location = new System.Drawing.Point(310, 722);
            this.tile769.Name = "tile769";
            this.tile769.Size = new System.Drawing.Size(32, 31);
            this.tile769.TabIndex = 808;
            this.tile769.TabStop = false;
            // 
            // tile770
            // 
            this.tile770.BackColor = System.Drawing.Color.White;
            this.tile770.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile770.Location = new System.Drawing.Point(348, 722);
            this.tile770.Name = "tile770";
            this.tile770.Size = new System.Drawing.Size(32, 31);
            this.tile770.TabIndex = 807;
            this.tile770.TabStop = false;
            // 
            // tile762
            // 
            this.tile762.BackColor = System.Drawing.Color.White;
            this.tile762.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile762.Location = new System.Drawing.Point(44, 722);
            this.tile762.Name = "tile762";
            this.tile762.Size = new System.Drawing.Size(32, 31);
            this.tile762.TabIndex = 806;
            this.tile762.TabStop = false;
            // 
            // tile761
            // 
            this.tile761.BackColor = System.Drawing.Color.White;
            this.tile761.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile761.Location = new System.Drawing.Point(6, 722);
            this.tile761.Name = "tile761";
            this.tile761.Size = new System.Drawing.Size(32, 31);
            this.tile761.TabIndex = 805;
            this.tile761.TabStop = false;
            // 
            // tile753
            // 
            this.tile753.BackColor = System.Drawing.Color.White;
            this.tile753.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile753.Location = new System.Drawing.Point(1222, 685);
            this.tile753.Name = "tile753";
            this.tile753.Size = new System.Drawing.Size(32, 31);
            this.tile753.TabIndex = 804;
            this.tile753.TabStop = false;
            // 
            // tile754
            // 
            this.tile754.BackColor = System.Drawing.Color.White;
            this.tile754.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile754.Location = new System.Drawing.Point(1260, 685);
            this.tile754.Name = "tile754";
            this.tile754.Size = new System.Drawing.Size(32, 31);
            this.tile754.TabIndex = 803;
            this.tile754.TabStop = false;
            // 
            // tile755
            // 
            this.tile755.BackColor = System.Drawing.Color.White;
            this.tile755.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile755.Location = new System.Drawing.Point(1298, 685);
            this.tile755.Name = "tile755";
            this.tile755.Size = new System.Drawing.Size(32, 31);
            this.tile755.TabIndex = 802;
            this.tile755.TabStop = false;
            // 
            // tile756
            // 
            this.tile756.BackColor = System.Drawing.Color.White;
            this.tile756.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile756.Location = new System.Drawing.Point(1336, 685);
            this.tile756.Name = "tile756";
            this.tile756.Size = new System.Drawing.Size(32, 31);
            this.tile756.TabIndex = 801;
            this.tile756.TabStop = false;
            // 
            // tile757
            // 
            this.tile757.BackColor = System.Drawing.Color.White;
            this.tile757.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile757.Location = new System.Drawing.Point(1374, 685);
            this.tile757.Name = "tile757";
            this.tile757.Size = new System.Drawing.Size(32, 31);
            this.tile757.TabIndex = 800;
            this.tile757.TabStop = false;
            // 
            // tile758
            // 
            this.tile758.BackColor = System.Drawing.Color.White;
            this.tile758.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile758.Location = new System.Drawing.Point(1412, 685);
            this.tile758.Name = "tile758";
            this.tile758.Size = new System.Drawing.Size(32, 31);
            this.tile758.TabIndex = 799;
            this.tile758.TabStop = false;
            // 
            // tile760
            // 
            this.tile760.BackColor = System.Drawing.Color.White;
            this.tile760.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile760.Location = new System.Drawing.Point(1488, 685);
            this.tile760.Name = "tile760";
            this.tile760.Size = new System.Drawing.Size(32, 31);
            this.tile760.TabIndex = 798;
            this.tile760.TabStop = false;
            // 
            // tile759
            // 
            this.tile759.BackColor = System.Drawing.Color.White;
            this.tile759.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile759.Location = new System.Drawing.Point(1450, 685);
            this.tile759.Name = "tile759";
            this.tile759.Size = new System.Drawing.Size(32, 31);
            this.tile759.TabIndex = 797;
            this.tile759.TabStop = false;
            // 
            // tile752
            // 
            this.tile752.BackColor = System.Drawing.Color.White;
            this.tile752.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile752.Location = new System.Drawing.Point(1184, 685);
            this.tile752.Name = "tile752";
            this.tile752.Size = new System.Drawing.Size(32, 31);
            this.tile752.TabIndex = 796;
            this.tile752.TabStop = false;
            // 
            // tile751
            // 
            this.tile751.BackColor = System.Drawing.Color.White;
            this.tile751.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile751.Location = new System.Drawing.Point(1146, 685);
            this.tile751.Name = "tile751";
            this.tile751.Size = new System.Drawing.Size(32, 31);
            this.tile751.TabIndex = 795;
            this.tile751.TabStop = false;
            // 
            // tile748
            // 
            this.tile748.BackColor = System.Drawing.Color.White;
            this.tile748.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile748.Location = new System.Drawing.Point(1032, 685);
            this.tile748.Name = "tile748";
            this.tile748.Size = new System.Drawing.Size(32, 31);
            this.tile748.TabIndex = 794;
            this.tile748.TabStop = false;
            // 
            // tile747
            // 
            this.tile747.BackColor = System.Drawing.Color.White;
            this.tile747.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile747.Location = new System.Drawing.Point(994, 685);
            this.tile747.Name = "tile747";
            this.tile747.Size = new System.Drawing.Size(32, 31);
            this.tile747.TabIndex = 793;
            this.tile747.TabStop = false;
            // 
            // tile746
            // 
            this.tile746.BackColor = System.Drawing.Color.White;
            this.tile746.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile746.Location = new System.Drawing.Point(956, 685);
            this.tile746.Name = "tile746";
            this.tile746.Size = new System.Drawing.Size(32, 31);
            this.tile746.TabIndex = 792;
            this.tile746.TabStop = false;
            // 
            // tile745
            // 
            this.tile745.BackColor = System.Drawing.Color.White;
            this.tile745.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile745.Location = new System.Drawing.Point(918, 685);
            this.tile745.Name = "tile745";
            this.tile745.Size = new System.Drawing.Size(32, 31);
            this.tile745.TabIndex = 791;
            this.tile745.TabStop = false;
            // 
            // tile744
            // 
            this.tile744.BackColor = System.Drawing.Color.White;
            this.tile744.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile744.Location = new System.Drawing.Point(880, 685);
            this.tile744.Name = "tile744";
            this.tile744.Size = new System.Drawing.Size(32, 31);
            this.tile744.TabIndex = 790;
            this.tile744.TabStop = false;
            // 
            // tile743
            // 
            this.tile743.BackColor = System.Drawing.Color.White;
            this.tile743.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile743.Location = new System.Drawing.Point(842, 685);
            this.tile743.Name = "tile743";
            this.tile743.Size = new System.Drawing.Size(32, 31);
            this.tile743.TabIndex = 789;
            this.tile743.TabStop = false;
            // 
            // tile741
            // 
            this.tile741.BackColor = System.Drawing.Color.White;
            this.tile741.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile741.Location = new System.Drawing.Point(766, 685);
            this.tile741.Name = "tile741";
            this.tile741.Size = new System.Drawing.Size(32, 31);
            this.tile741.TabIndex = 788;
            this.tile741.TabStop = false;
            // 
            // tile742
            // 
            this.tile742.BackColor = System.Drawing.Color.White;
            this.tile742.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile742.Location = new System.Drawing.Point(804, 685);
            this.tile742.Name = "tile742";
            this.tile742.Size = new System.Drawing.Size(32, 31);
            this.tile742.TabIndex = 787;
            this.tile742.TabStop = false;
            // 
            // tile749
            // 
            this.tile749.BackColor = System.Drawing.Color.White;
            this.tile749.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile749.Location = new System.Drawing.Point(1070, 685);
            this.tile749.Name = "tile749";
            this.tile749.Size = new System.Drawing.Size(32, 31);
            this.tile749.TabIndex = 786;
            this.tile749.TabStop = false;
            // 
            // tile750
            // 
            this.tile750.BackColor = System.Drawing.Color.White;
            this.tile750.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile750.Location = new System.Drawing.Point(1108, 685);
            this.tile750.Name = "tile750";
            this.tile750.Size = new System.Drawing.Size(32, 31);
            this.tile750.TabIndex = 785;
            this.tile750.TabStop = false;
            // 
            // tile733
            // 
            this.tile733.BackColor = System.Drawing.Color.White;
            this.tile733.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile733.Location = new System.Drawing.Point(462, 685);
            this.tile733.Name = "tile733";
            this.tile733.Size = new System.Drawing.Size(32, 31);
            this.tile733.TabIndex = 784;
            this.tile733.TabStop = false;
            // 
            // tile734
            // 
            this.tile734.BackColor = System.Drawing.Color.White;
            this.tile734.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile734.Location = new System.Drawing.Point(500, 685);
            this.tile734.Name = "tile734";
            this.tile734.Size = new System.Drawing.Size(32, 31);
            this.tile734.TabIndex = 783;
            this.tile734.TabStop = false;
            // 
            // tile735
            // 
            this.tile735.BackColor = System.Drawing.Color.White;
            this.tile735.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile735.Location = new System.Drawing.Point(538, 685);
            this.tile735.Name = "tile735";
            this.tile735.Size = new System.Drawing.Size(32, 31);
            this.tile735.TabIndex = 782;
            this.tile735.TabStop = false;
            // 
            // tile736
            // 
            this.tile736.BackColor = System.Drawing.Color.White;
            this.tile736.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile736.Location = new System.Drawing.Point(576, 685);
            this.tile736.Name = "tile736";
            this.tile736.Size = new System.Drawing.Size(32, 31);
            this.tile736.TabIndex = 781;
            this.tile736.TabStop = false;
            // 
            // tile737
            // 
            this.tile737.BackColor = System.Drawing.Color.White;
            this.tile737.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile737.Location = new System.Drawing.Point(614, 685);
            this.tile737.Name = "tile737";
            this.tile737.Size = new System.Drawing.Size(32, 31);
            this.tile737.TabIndex = 780;
            this.tile737.TabStop = false;
            // 
            // tile738
            // 
            this.tile738.BackColor = System.Drawing.Color.White;
            this.tile738.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile738.Location = new System.Drawing.Point(652, 685);
            this.tile738.Name = "tile738";
            this.tile738.Size = new System.Drawing.Size(32, 31);
            this.tile738.TabIndex = 779;
            this.tile738.TabStop = false;
            // 
            // tile739
            // 
            this.tile739.BackColor = System.Drawing.Color.White;
            this.tile739.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile739.Location = new System.Drawing.Point(690, 685);
            this.tile739.Name = "tile739";
            this.tile739.Size = new System.Drawing.Size(32, 31);
            this.tile739.TabIndex = 778;
            this.tile739.TabStop = false;
            // 
            // tile740
            // 
            this.tile740.BackColor = System.Drawing.Color.White;
            this.tile740.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile740.Location = new System.Drawing.Point(728, 685);
            this.tile740.Name = "tile740";
            this.tile740.Size = new System.Drawing.Size(32, 31);
            this.tile740.TabIndex = 777;
            this.tile740.TabStop = false;
            // 
            // tile732
            // 
            this.tile732.BackColor = System.Drawing.Color.White;
            this.tile732.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile732.Location = new System.Drawing.Point(424, 685);
            this.tile732.Name = "tile732";
            this.tile732.Size = new System.Drawing.Size(32, 31);
            this.tile732.TabIndex = 776;
            this.tile732.TabStop = false;
            // 
            // tile731
            // 
            this.tile731.BackColor = System.Drawing.Color.White;
            this.tile731.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile731.Location = new System.Drawing.Point(386, 685);
            this.tile731.Name = "tile731";
            this.tile731.Size = new System.Drawing.Size(32, 31);
            this.tile731.TabIndex = 775;
            this.tile731.TabStop = false;
            // 
            // tile723
            // 
            this.tile723.BackColor = System.Drawing.Color.White;
            this.tile723.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile723.Location = new System.Drawing.Point(82, 685);
            this.tile723.Name = "tile723";
            this.tile723.Size = new System.Drawing.Size(32, 31);
            this.tile723.TabIndex = 774;
            this.tile723.TabStop = false;
            // 
            // tile724
            // 
            this.tile724.BackColor = System.Drawing.Color.White;
            this.tile724.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile724.Location = new System.Drawing.Point(120, 685);
            this.tile724.Name = "tile724";
            this.tile724.Size = new System.Drawing.Size(32, 31);
            this.tile724.TabIndex = 773;
            this.tile724.TabStop = false;
            // 
            // tile725
            // 
            this.tile725.BackColor = System.Drawing.Color.White;
            this.tile725.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile725.Location = new System.Drawing.Point(158, 685);
            this.tile725.Name = "tile725";
            this.tile725.Size = new System.Drawing.Size(32, 31);
            this.tile725.TabIndex = 772;
            this.tile725.TabStop = false;
            // 
            // tile726
            // 
            this.tile726.BackColor = System.Drawing.Color.White;
            this.tile726.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile726.Location = new System.Drawing.Point(196, 685);
            this.tile726.Name = "tile726";
            this.tile726.Size = new System.Drawing.Size(32, 31);
            this.tile726.TabIndex = 771;
            this.tile726.TabStop = false;
            // 
            // tile727
            // 
            this.tile727.BackColor = System.Drawing.Color.White;
            this.tile727.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile727.Location = new System.Drawing.Point(234, 685);
            this.tile727.Name = "tile727";
            this.tile727.Size = new System.Drawing.Size(32, 31);
            this.tile727.TabIndex = 770;
            this.tile727.TabStop = false;
            // 
            // tile728
            // 
            this.tile728.BackColor = System.Drawing.Color.White;
            this.tile728.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile728.Location = new System.Drawing.Point(272, 685);
            this.tile728.Name = "tile728";
            this.tile728.Size = new System.Drawing.Size(32, 31);
            this.tile728.TabIndex = 769;
            this.tile728.TabStop = false;
            // 
            // tile729
            // 
            this.tile729.BackColor = System.Drawing.Color.White;
            this.tile729.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile729.Location = new System.Drawing.Point(310, 685);
            this.tile729.Name = "tile729";
            this.tile729.Size = new System.Drawing.Size(32, 31);
            this.tile729.TabIndex = 768;
            this.tile729.TabStop = false;
            // 
            // tile730
            // 
            this.tile730.BackColor = System.Drawing.Color.White;
            this.tile730.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile730.Location = new System.Drawing.Point(348, 685);
            this.tile730.Name = "tile730";
            this.tile730.Size = new System.Drawing.Size(32, 31);
            this.tile730.TabIndex = 767;
            this.tile730.TabStop = false;
            // 
            // tile722
            // 
            this.tile722.BackColor = System.Drawing.Color.White;
            this.tile722.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile722.Location = new System.Drawing.Point(44, 685);
            this.tile722.Name = "tile722";
            this.tile722.Size = new System.Drawing.Size(32, 31);
            this.tile722.TabIndex = 766;
            this.tile722.TabStop = false;
            // 
            // tile721
            // 
            this.tile721.BackColor = System.Drawing.Color.White;
            this.tile721.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile721.Location = new System.Drawing.Point(6, 685);
            this.tile721.Name = "tile721";
            this.tile721.Size = new System.Drawing.Size(32, 31);
            this.tile721.TabIndex = 765;
            this.tile721.TabStop = false;
            // 
            // tile713
            // 
            this.tile713.BackColor = System.Drawing.Color.White;
            this.tile713.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile713.Location = new System.Drawing.Point(1222, 648);
            this.tile713.Name = "tile713";
            this.tile713.Size = new System.Drawing.Size(32, 31);
            this.tile713.TabIndex = 764;
            this.tile713.TabStop = false;
            // 
            // tile714
            // 
            this.tile714.BackColor = System.Drawing.Color.White;
            this.tile714.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile714.Location = new System.Drawing.Point(1260, 648);
            this.tile714.Name = "tile714";
            this.tile714.Size = new System.Drawing.Size(32, 31);
            this.tile714.TabIndex = 763;
            this.tile714.TabStop = false;
            // 
            // tile715
            // 
            this.tile715.BackColor = System.Drawing.Color.White;
            this.tile715.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile715.Location = new System.Drawing.Point(1298, 648);
            this.tile715.Name = "tile715";
            this.tile715.Size = new System.Drawing.Size(32, 31);
            this.tile715.TabIndex = 762;
            this.tile715.TabStop = false;
            // 
            // tile716
            // 
            this.tile716.BackColor = System.Drawing.Color.White;
            this.tile716.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile716.Location = new System.Drawing.Point(1336, 648);
            this.tile716.Name = "tile716";
            this.tile716.Size = new System.Drawing.Size(32, 31);
            this.tile716.TabIndex = 761;
            this.tile716.TabStop = false;
            // 
            // tile717
            // 
            this.tile717.BackColor = System.Drawing.Color.White;
            this.tile717.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile717.Location = new System.Drawing.Point(1374, 648);
            this.tile717.Name = "tile717";
            this.tile717.Size = new System.Drawing.Size(32, 31);
            this.tile717.TabIndex = 760;
            this.tile717.TabStop = false;
            // 
            // tile718
            // 
            this.tile718.BackColor = System.Drawing.Color.White;
            this.tile718.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile718.Location = new System.Drawing.Point(1412, 648);
            this.tile718.Name = "tile718";
            this.tile718.Size = new System.Drawing.Size(32, 31);
            this.tile718.TabIndex = 759;
            this.tile718.TabStop = false;
            // 
            // tile720
            // 
            this.tile720.BackColor = System.Drawing.Color.White;
            this.tile720.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile720.Location = new System.Drawing.Point(1488, 648);
            this.tile720.Name = "tile720";
            this.tile720.Size = new System.Drawing.Size(32, 31);
            this.tile720.TabIndex = 758;
            this.tile720.TabStop = false;
            // 
            // tile719
            // 
            this.tile719.BackColor = System.Drawing.Color.White;
            this.tile719.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile719.Location = new System.Drawing.Point(1450, 648);
            this.tile719.Name = "tile719";
            this.tile719.Size = new System.Drawing.Size(32, 31);
            this.tile719.TabIndex = 757;
            this.tile719.TabStop = false;
            // 
            // tile712
            // 
            this.tile712.BackColor = System.Drawing.Color.White;
            this.tile712.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile712.Location = new System.Drawing.Point(1184, 648);
            this.tile712.Name = "tile712";
            this.tile712.Size = new System.Drawing.Size(32, 31);
            this.tile712.TabIndex = 756;
            this.tile712.TabStop = false;
            // 
            // tile711
            // 
            this.tile711.BackColor = System.Drawing.Color.White;
            this.tile711.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile711.Location = new System.Drawing.Point(1146, 648);
            this.tile711.Name = "tile711";
            this.tile711.Size = new System.Drawing.Size(32, 31);
            this.tile711.TabIndex = 755;
            this.tile711.TabStop = false;
            // 
            // tile708
            // 
            this.tile708.BackColor = System.Drawing.Color.White;
            this.tile708.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile708.Location = new System.Drawing.Point(1032, 648);
            this.tile708.Name = "tile708";
            this.tile708.Size = new System.Drawing.Size(32, 31);
            this.tile708.TabIndex = 754;
            this.tile708.TabStop = false;
            // 
            // tile707
            // 
            this.tile707.BackColor = System.Drawing.Color.White;
            this.tile707.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile707.Location = new System.Drawing.Point(994, 648);
            this.tile707.Name = "tile707";
            this.tile707.Size = new System.Drawing.Size(32, 31);
            this.tile707.TabIndex = 753;
            this.tile707.TabStop = false;
            // 
            // tile706
            // 
            this.tile706.BackColor = System.Drawing.Color.White;
            this.tile706.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile706.Location = new System.Drawing.Point(956, 648);
            this.tile706.Name = "tile706";
            this.tile706.Size = new System.Drawing.Size(32, 31);
            this.tile706.TabIndex = 752;
            this.tile706.TabStop = false;
            // 
            // tile705
            // 
            this.tile705.BackColor = System.Drawing.Color.White;
            this.tile705.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile705.Location = new System.Drawing.Point(918, 648);
            this.tile705.Name = "tile705";
            this.tile705.Size = new System.Drawing.Size(32, 31);
            this.tile705.TabIndex = 751;
            this.tile705.TabStop = false;
            // 
            // tile704
            // 
            this.tile704.BackColor = System.Drawing.Color.White;
            this.tile704.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile704.Location = new System.Drawing.Point(880, 648);
            this.tile704.Name = "tile704";
            this.tile704.Size = new System.Drawing.Size(32, 31);
            this.tile704.TabIndex = 750;
            this.tile704.TabStop = false;
            // 
            // tile703
            // 
            this.tile703.BackColor = System.Drawing.Color.White;
            this.tile703.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile703.Location = new System.Drawing.Point(842, 648);
            this.tile703.Name = "tile703";
            this.tile703.Size = new System.Drawing.Size(32, 31);
            this.tile703.TabIndex = 749;
            this.tile703.TabStop = false;
            // 
            // tile701
            // 
            this.tile701.BackColor = System.Drawing.Color.White;
            this.tile701.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile701.Location = new System.Drawing.Point(766, 648);
            this.tile701.Name = "tile701";
            this.tile701.Size = new System.Drawing.Size(32, 31);
            this.tile701.TabIndex = 748;
            this.tile701.TabStop = false;
            // 
            // tile702
            // 
            this.tile702.BackColor = System.Drawing.Color.White;
            this.tile702.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile702.Location = new System.Drawing.Point(804, 648);
            this.tile702.Name = "tile702";
            this.tile702.Size = new System.Drawing.Size(32, 31);
            this.tile702.TabIndex = 747;
            this.tile702.TabStop = false;
            // 
            // tile709
            // 
            this.tile709.BackColor = System.Drawing.Color.White;
            this.tile709.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile709.Location = new System.Drawing.Point(1070, 648);
            this.tile709.Name = "tile709";
            this.tile709.Size = new System.Drawing.Size(32, 31);
            this.tile709.TabIndex = 746;
            this.tile709.TabStop = false;
            // 
            // tile710
            // 
            this.tile710.BackColor = System.Drawing.Color.White;
            this.tile710.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile710.Location = new System.Drawing.Point(1108, 648);
            this.tile710.Name = "tile710";
            this.tile710.Size = new System.Drawing.Size(32, 31);
            this.tile710.TabIndex = 745;
            this.tile710.TabStop = false;
            // 
            // tile693
            // 
            this.tile693.BackColor = System.Drawing.Color.White;
            this.tile693.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile693.Location = new System.Drawing.Point(462, 648);
            this.tile693.Name = "tile693";
            this.tile693.Size = new System.Drawing.Size(32, 31);
            this.tile693.TabIndex = 744;
            this.tile693.TabStop = false;
            // 
            // tile694
            // 
            this.tile694.BackColor = System.Drawing.Color.White;
            this.tile694.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile694.Location = new System.Drawing.Point(500, 648);
            this.tile694.Name = "tile694";
            this.tile694.Size = new System.Drawing.Size(32, 31);
            this.tile694.TabIndex = 743;
            this.tile694.TabStop = false;
            // 
            // tile695
            // 
            this.tile695.BackColor = System.Drawing.Color.White;
            this.tile695.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile695.Location = new System.Drawing.Point(538, 648);
            this.tile695.Name = "tile695";
            this.tile695.Size = new System.Drawing.Size(32, 31);
            this.tile695.TabIndex = 742;
            this.tile695.TabStop = false;
            // 
            // tile696
            // 
            this.tile696.BackColor = System.Drawing.Color.White;
            this.tile696.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile696.Location = new System.Drawing.Point(576, 648);
            this.tile696.Name = "tile696";
            this.tile696.Size = new System.Drawing.Size(32, 31);
            this.tile696.TabIndex = 741;
            this.tile696.TabStop = false;
            // 
            // tile697
            // 
            this.tile697.BackColor = System.Drawing.Color.White;
            this.tile697.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile697.Location = new System.Drawing.Point(614, 648);
            this.tile697.Name = "tile697";
            this.tile697.Size = new System.Drawing.Size(32, 31);
            this.tile697.TabIndex = 740;
            this.tile697.TabStop = false;
            // 
            // tile698
            // 
            this.tile698.BackColor = System.Drawing.Color.White;
            this.tile698.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile698.Location = new System.Drawing.Point(652, 648);
            this.tile698.Name = "tile698";
            this.tile698.Size = new System.Drawing.Size(32, 31);
            this.tile698.TabIndex = 739;
            this.tile698.TabStop = false;
            // 
            // tile699
            // 
            this.tile699.BackColor = System.Drawing.Color.White;
            this.tile699.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile699.Location = new System.Drawing.Point(690, 648);
            this.tile699.Name = "tile699";
            this.tile699.Size = new System.Drawing.Size(32, 31);
            this.tile699.TabIndex = 738;
            this.tile699.TabStop = false;
            // 
            // tile700
            // 
            this.tile700.BackColor = System.Drawing.Color.White;
            this.tile700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile700.Location = new System.Drawing.Point(728, 648);
            this.tile700.Name = "tile700";
            this.tile700.Size = new System.Drawing.Size(32, 31);
            this.tile700.TabIndex = 737;
            this.tile700.TabStop = false;
            // 
            // tile692
            // 
            this.tile692.BackColor = System.Drawing.Color.White;
            this.tile692.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile692.Location = new System.Drawing.Point(424, 648);
            this.tile692.Name = "tile692";
            this.tile692.Size = new System.Drawing.Size(32, 31);
            this.tile692.TabIndex = 736;
            this.tile692.TabStop = false;
            // 
            // tile691
            // 
            this.tile691.BackColor = System.Drawing.Color.White;
            this.tile691.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile691.Location = new System.Drawing.Point(386, 648);
            this.tile691.Name = "tile691";
            this.tile691.Size = new System.Drawing.Size(32, 31);
            this.tile691.TabIndex = 735;
            this.tile691.TabStop = false;
            // 
            // tile683
            // 
            this.tile683.BackColor = System.Drawing.Color.White;
            this.tile683.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile683.Location = new System.Drawing.Point(82, 648);
            this.tile683.Name = "tile683";
            this.tile683.Size = new System.Drawing.Size(32, 31);
            this.tile683.TabIndex = 734;
            this.tile683.TabStop = false;
            // 
            // tile684
            // 
            this.tile684.BackColor = System.Drawing.Color.White;
            this.tile684.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile684.Location = new System.Drawing.Point(120, 648);
            this.tile684.Name = "tile684";
            this.tile684.Size = new System.Drawing.Size(32, 31);
            this.tile684.TabIndex = 733;
            this.tile684.TabStop = false;
            // 
            // tile685
            // 
            this.tile685.BackColor = System.Drawing.Color.White;
            this.tile685.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile685.Location = new System.Drawing.Point(158, 648);
            this.tile685.Name = "tile685";
            this.tile685.Size = new System.Drawing.Size(32, 31);
            this.tile685.TabIndex = 732;
            this.tile685.TabStop = false;
            // 
            // tile686
            // 
            this.tile686.BackColor = System.Drawing.Color.White;
            this.tile686.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile686.Location = new System.Drawing.Point(196, 648);
            this.tile686.Name = "tile686";
            this.tile686.Size = new System.Drawing.Size(32, 31);
            this.tile686.TabIndex = 731;
            this.tile686.TabStop = false;
            // 
            // tile687
            // 
            this.tile687.BackColor = System.Drawing.Color.White;
            this.tile687.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile687.Location = new System.Drawing.Point(234, 648);
            this.tile687.Name = "tile687";
            this.tile687.Size = new System.Drawing.Size(32, 31);
            this.tile687.TabIndex = 730;
            this.tile687.TabStop = false;
            // 
            // tile688
            // 
            this.tile688.BackColor = System.Drawing.Color.White;
            this.tile688.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile688.Location = new System.Drawing.Point(272, 648);
            this.tile688.Name = "tile688";
            this.tile688.Size = new System.Drawing.Size(32, 31);
            this.tile688.TabIndex = 729;
            this.tile688.TabStop = false;
            // 
            // tile689
            // 
            this.tile689.BackColor = System.Drawing.Color.White;
            this.tile689.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile689.Location = new System.Drawing.Point(310, 648);
            this.tile689.Name = "tile689";
            this.tile689.Size = new System.Drawing.Size(32, 31);
            this.tile689.TabIndex = 728;
            this.tile689.TabStop = false;
            // 
            // tile690
            // 
            this.tile690.BackColor = System.Drawing.Color.White;
            this.tile690.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile690.Location = new System.Drawing.Point(348, 648);
            this.tile690.Name = "tile690";
            this.tile690.Size = new System.Drawing.Size(32, 31);
            this.tile690.TabIndex = 727;
            this.tile690.TabStop = false;
            // 
            // tile682
            // 
            this.tile682.BackColor = System.Drawing.Color.White;
            this.tile682.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile682.Location = new System.Drawing.Point(44, 648);
            this.tile682.Name = "tile682";
            this.tile682.Size = new System.Drawing.Size(32, 31);
            this.tile682.TabIndex = 726;
            this.tile682.TabStop = false;
            // 
            // tile681
            // 
            this.tile681.BackColor = System.Drawing.Color.White;
            this.tile681.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile681.Location = new System.Drawing.Point(6, 648);
            this.tile681.Name = "tile681";
            this.tile681.Size = new System.Drawing.Size(32, 31);
            this.tile681.TabIndex = 725;
            this.tile681.TabStop = false;
            // 
            // tile673
            // 
            this.tile673.BackColor = System.Drawing.Color.White;
            this.tile673.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile673.Location = new System.Drawing.Point(1222, 611);
            this.tile673.Name = "tile673";
            this.tile673.Size = new System.Drawing.Size(32, 31);
            this.tile673.TabIndex = 724;
            this.tile673.TabStop = false;
            // 
            // tile674
            // 
            this.tile674.BackColor = System.Drawing.Color.White;
            this.tile674.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile674.Location = new System.Drawing.Point(1260, 611);
            this.tile674.Name = "tile674";
            this.tile674.Size = new System.Drawing.Size(32, 31);
            this.tile674.TabIndex = 723;
            this.tile674.TabStop = false;
            // 
            // tile675
            // 
            this.tile675.BackColor = System.Drawing.Color.White;
            this.tile675.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile675.Location = new System.Drawing.Point(1298, 611);
            this.tile675.Name = "tile675";
            this.tile675.Size = new System.Drawing.Size(32, 31);
            this.tile675.TabIndex = 722;
            this.tile675.TabStop = false;
            // 
            // tile676
            // 
            this.tile676.BackColor = System.Drawing.Color.White;
            this.tile676.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile676.Location = new System.Drawing.Point(1336, 611);
            this.tile676.Name = "tile676";
            this.tile676.Size = new System.Drawing.Size(32, 31);
            this.tile676.TabIndex = 721;
            this.tile676.TabStop = false;
            // 
            // tile677
            // 
            this.tile677.BackColor = System.Drawing.Color.White;
            this.tile677.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile677.Location = new System.Drawing.Point(1374, 611);
            this.tile677.Name = "tile677";
            this.tile677.Size = new System.Drawing.Size(32, 31);
            this.tile677.TabIndex = 720;
            this.tile677.TabStop = false;
            // 
            // tile678
            // 
            this.tile678.BackColor = System.Drawing.Color.White;
            this.tile678.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile678.Location = new System.Drawing.Point(1412, 611);
            this.tile678.Name = "tile678";
            this.tile678.Size = new System.Drawing.Size(32, 31);
            this.tile678.TabIndex = 719;
            this.tile678.TabStop = false;
            // 
            // tile680
            // 
            this.tile680.BackColor = System.Drawing.Color.White;
            this.tile680.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile680.Location = new System.Drawing.Point(1488, 611);
            this.tile680.Name = "tile680";
            this.tile680.Size = new System.Drawing.Size(32, 31);
            this.tile680.TabIndex = 718;
            this.tile680.TabStop = false;
            // 
            // tile679
            // 
            this.tile679.BackColor = System.Drawing.Color.White;
            this.tile679.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile679.Location = new System.Drawing.Point(1450, 611);
            this.tile679.Name = "tile679";
            this.tile679.Size = new System.Drawing.Size(32, 31);
            this.tile679.TabIndex = 717;
            this.tile679.TabStop = false;
            // 
            // tile672
            // 
            this.tile672.BackColor = System.Drawing.Color.White;
            this.tile672.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile672.Location = new System.Drawing.Point(1184, 611);
            this.tile672.Name = "tile672";
            this.tile672.Size = new System.Drawing.Size(32, 31);
            this.tile672.TabIndex = 716;
            this.tile672.TabStop = false;
            // 
            // tile671
            // 
            this.tile671.BackColor = System.Drawing.Color.White;
            this.tile671.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile671.Location = new System.Drawing.Point(1146, 611);
            this.tile671.Name = "tile671";
            this.tile671.Size = new System.Drawing.Size(32, 31);
            this.tile671.TabIndex = 715;
            this.tile671.TabStop = false;
            // 
            // tile668
            // 
            this.tile668.BackColor = System.Drawing.Color.White;
            this.tile668.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile668.Location = new System.Drawing.Point(1032, 611);
            this.tile668.Name = "tile668";
            this.tile668.Size = new System.Drawing.Size(32, 31);
            this.tile668.TabIndex = 714;
            this.tile668.TabStop = false;
            // 
            // tile667
            // 
            this.tile667.BackColor = System.Drawing.Color.White;
            this.tile667.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile667.Location = new System.Drawing.Point(994, 611);
            this.tile667.Name = "tile667";
            this.tile667.Size = new System.Drawing.Size(32, 31);
            this.tile667.TabIndex = 713;
            this.tile667.TabStop = false;
            // 
            // tile666
            // 
            this.tile666.BackColor = System.Drawing.Color.White;
            this.tile666.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile666.Location = new System.Drawing.Point(956, 611);
            this.tile666.Name = "tile666";
            this.tile666.Size = new System.Drawing.Size(32, 31);
            this.tile666.TabIndex = 712;
            this.tile666.TabStop = false;
            // 
            // tile665
            // 
            this.tile665.BackColor = System.Drawing.Color.White;
            this.tile665.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile665.Location = new System.Drawing.Point(918, 611);
            this.tile665.Name = "tile665";
            this.tile665.Size = new System.Drawing.Size(32, 31);
            this.tile665.TabIndex = 711;
            this.tile665.TabStop = false;
            // 
            // tile664
            // 
            this.tile664.BackColor = System.Drawing.Color.White;
            this.tile664.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile664.Location = new System.Drawing.Point(880, 611);
            this.tile664.Name = "tile664";
            this.tile664.Size = new System.Drawing.Size(32, 31);
            this.tile664.TabIndex = 710;
            this.tile664.TabStop = false;
            // 
            // tile663
            // 
            this.tile663.BackColor = System.Drawing.Color.White;
            this.tile663.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile663.Location = new System.Drawing.Point(842, 611);
            this.tile663.Name = "tile663";
            this.tile663.Size = new System.Drawing.Size(32, 31);
            this.tile663.TabIndex = 709;
            this.tile663.TabStop = false;
            // 
            // tile661
            // 
            this.tile661.BackColor = System.Drawing.Color.White;
            this.tile661.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile661.Location = new System.Drawing.Point(766, 611);
            this.tile661.Name = "tile661";
            this.tile661.Size = new System.Drawing.Size(32, 31);
            this.tile661.TabIndex = 708;
            this.tile661.TabStop = false;
            // 
            // tile662
            // 
            this.tile662.BackColor = System.Drawing.Color.White;
            this.tile662.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile662.Location = new System.Drawing.Point(804, 611);
            this.tile662.Name = "tile662";
            this.tile662.Size = new System.Drawing.Size(32, 31);
            this.tile662.TabIndex = 707;
            this.tile662.TabStop = false;
            // 
            // tile669
            // 
            this.tile669.BackColor = System.Drawing.Color.White;
            this.tile669.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile669.Location = new System.Drawing.Point(1070, 611);
            this.tile669.Name = "tile669";
            this.tile669.Size = new System.Drawing.Size(32, 31);
            this.tile669.TabIndex = 706;
            this.tile669.TabStop = false;
            // 
            // tile670
            // 
            this.tile670.BackColor = System.Drawing.Color.White;
            this.tile670.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile670.Location = new System.Drawing.Point(1108, 611);
            this.tile670.Name = "tile670";
            this.tile670.Size = new System.Drawing.Size(32, 31);
            this.tile670.TabIndex = 705;
            this.tile670.TabStop = false;
            // 
            // tile653
            // 
            this.tile653.BackColor = System.Drawing.Color.White;
            this.tile653.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile653.Location = new System.Drawing.Point(462, 611);
            this.tile653.Name = "tile653";
            this.tile653.Size = new System.Drawing.Size(32, 31);
            this.tile653.TabIndex = 704;
            this.tile653.TabStop = false;
            // 
            // tile654
            // 
            this.tile654.BackColor = System.Drawing.Color.White;
            this.tile654.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile654.Location = new System.Drawing.Point(500, 611);
            this.tile654.Name = "tile654";
            this.tile654.Size = new System.Drawing.Size(32, 31);
            this.tile654.TabIndex = 703;
            this.tile654.TabStop = false;
            // 
            // tile655
            // 
            this.tile655.BackColor = System.Drawing.Color.White;
            this.tile655.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile655.Location = new System.Drawing.Point(538, 611);
            this.tile655.Name = "tile655";
            this.tile655.Size = new System.Drawing.Size(32, 31);
            this.tile655.TabIndex = 702;
            this.tile655.TabStop = false;
            // 
            // tile656
            // 
            this.tile656.BackColor = System.Drawing.Color.White;
            this.tile656.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile656.Location = new System.Drawing.Point(576, 611);
            this.tile656.Name = "tile656";
            this.tile656.Size = new System.Drawing.Size(32, 31);
            this.tile656.TabIndex = 701;
            this.tile656.TabStop = false;
            // 
            // tile657
            // 
            this.tile657.BackColor = System.Drawing.Color.White;
            this.tile657.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile657.Location = new System.Drawing.Point(614, 611);
            this.tile657.Name = "tile657";
            this.tile657.Size = new System.Drawing.Size(32, 31);
            this.tile657.TabIndex = 700;
            this.tile657.TabStop = false;
            // 
            // tile658
            // 
            this.tile658.BackColor = System.Drawing.Color.White;
            this.tile658.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile658.Location = new System.Drawing.Point(652, 611);
            this.tile658.Name = "tile658";
            this.tile658.Size = new System.Drawing.Size(32, 31);
            this.tile658.TabIndex = 699;
            this.tile658.TabStop = false;
            // 
            // tile659
            // 
            this.tile659.BackColor = System.Drawing.Color.White;
            this.tile659.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile659.Location = new System.Drawing.Point(690, 611);
            this.tile659.Name = "tile659";
            this.tile659.Size = new System.Drawing.Size(32, 31);
            this.tile659.TabIndex = 698;
            this.tile659.TabStop = false;
            // 
            // tile660
            // 
            this.tile660.BackColor = System.Drawing.Color.White;
            this.tile660.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile660.Location = new System.Drawing.Point(728, 611);
            this.tile660.Name = "tile660";
            this.tile660.Size = new System.Drawing.Size(32, 31);
            this.tile660.TabIndex = 697;
            this.tile660.TabStop = false;
            // 
            // tile652
            // 
            this.tile652.BackColor = System.Drawing.Color.White;
            this.tile652.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile652.Location = new System.Drawing.Point(424, 611);
            this.tile652.Name = "tile652";
            this.tile652.Size = new System.Drawing.Size(32, 31);
            this.tile652.TabIndex = 696;
            this.tile652.TabStop = false;
            // 
            // tile651
            // 
            this.tile651.BackColor = System.Drawing.Color.White;
            this.tile651.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile651.Location = new System.Drawing.Point(386, 611);
            this.tile651.Name = "tile651";
            this.tile651.Size = new System.Drawing.Size(32, 31);
            this.tile651.TabIndex = 695;
            this.tile651.TabStop = false;
            // 
            // tile643
            // 
            this.tile643.BackColor = System.Drawing.Color.White;
            this.tile643.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile643.Location = new System.Drawing.Point(82, 611);
            this.tile643.Name = "tile643";
            this.tile643.Size = new System.Drawing.Size(32, 31);
            this.tile643.TabIndex = 694;
            this.tile643.TabStop = false;
            // 
            // tile644
            // 
            this.tile644.BackColor = System.Drawing.Color.White;
            this.tile644.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile644.Location = new System.Drawing.Point(120, 611);
            this.tile644.Name = "tile644";
            this.tile644.Size = new System.Drawing.Size(32, 31);
            this.tile644.TabIndex = 693;
            this.tile644.TabStop = false;
            // 
            // tile645
            // 
            this.tile645.BackColor = System.Drawing.Color.White;
            this.tile645.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile645.Location = new System.Drawing.Point(158, 611);
            this.tile645.Name = "tile645";
            this.tile645.Size = new System.Drawing.Size(32, 31);
            this.tile645.TabIndex = 692;
            this.tile645.TabStop = false;
            // 
            // tile646
            // 
            this.tile646.BackColor = System.Drawing.Color.White;
            this.tile646.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile646.Location = new System.Drawing.Point(196, 611);
            this.tile646.Name = "tile646";
            this.tile646.Size = new System.Drawing.Size(32, 31);
            this.tile646.TabIndex = 691;
            this.tile646.TabStop = false;
            // 
            // tile647
            // 
            this.tile647.BackColor = System.Drawing.Color.White;
            this.tile647.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile647.Location = new System.Drawing.Point(234, 611);
            this.tile647.Name = "tile647";
            this.tile647.Size = new System.Drawing.Size(32, 31);
            this.tile647.TabIndex = 690;
            this.tile647.TabStop = false;
            // 
            // tile648
            // 
            this.tile648.BackColor = System.Drawing.Color.White;
            this.tile648.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile648.Location = new System.Drawing.Point(272, 611);
            this.tile648.Name = "tile648";
            this.tile648.Size = new System.Drawing.Size(32, 31);
            this.tile648.TabIndex = 689;
            this.tile648.TabStop = false;
            // 
            // tile649
            // 
            this.tile649.BackColor = System.Drawing.Color.White;
            this.tile649.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile649.Location = new System.Drawing.Point(310, 611);
            this.tile649.Name = "tile649";
            this.tile649.Size = new System.Drawing.Size(32, 31);
            this.tile649.TabIndex = 688;
            this.tile649.TabStop = false;
            // 
            // tile650
            // 
            this.tile650.BackColor = System.Drawing.Color.White;
            this.tile650.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile650.Location = new System.Drawing.Point(348, 611);
            this.tile650.Name = "tile650";
            this.tile650.Size = new System.Drawing.Size(32, 31);
            this.tile650.TabIndex = 687;
            this.tile650.TabStop = false;
            // 
            // tile642
            // 
            this.tile642.BackColor = System.Drawing.Color.White;
            this.tile642.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile642.Location = new System.Drawing.Point(44, 611);
            this.tile642.Name = "tile642";
            this.tile642.Size = new System.Drawing.Size(32, 31);
            this.tile642.TabIndex = 686;
            this.tile642.TabStop = false;
            // 
            // tile641
            // 
            this.tile641.BackColor = System.Drawing.Color.White;
            this.tile641.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile641.Location = new System.Drawing.Point(6, 611);
            this.tile641.Name = "tile641";
            this.tile641.Size = new System.Drawing.Size(32, 31);
            this.tile641.TabIndex = 685;
            this.tile641.TabStop = false;
            // 
            // tile633
            // 
            this.tile633.BackColor = System.Drawing.Color.White;
            this.tile633.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile633.Location = new System.Drawing.Point(1222, 574);
            this.tile633.Name = "tile633";
            this.tile633.Size = new System.Drawing.Size(32, 31);
            this.tile633.TabIndex = 684;
            this.tile633.TabStop = false;
            // 
            // tile634
            // 
            this.tile634.BackColor = System.Drawing.Color.White;
            this.tile634.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile634.Location = new System.Drawing.Point(1260, 574);
            this.tile634.Name = "tile634";
            this.tile634.Size = new System.Drawing.Size(32, 31);
            this.tile634.TabIndex = 683;
            this.tile634.TabStop = false;
            // 
            // tile635
            // 
            this.tile635.BackColor = System.Drawing.Color.White;
            this.tile635.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile635.Location = new System.Drawing.Point(1298, 574);
            this.tile635.Name = "tile635";
            this.tile635.Size = new System.Drawing.Size(32, 31);
            this.tile635.TabIndex = 682;
            this.tile635.TabStop = false;
            // 
            // tile636
            // 
            this.tile636.BackColor = System.Drawing.Color.White;
            this.tile636.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile636.Location = new System.Drawing.Point(1336, 574);
            this.tile636.Name = "tile636";
            this.tile636.Size = new System.Drawing.Size(32, 31);
            this.tile636.TabIndex = 681;
            this.tile636.TabStop = false;
            // 
            // tile637
            // 
            this.tile637.BackColor = System.Drawing.Color.White;
            this.tile637.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile637.Location = new System.Drawing.Point(1374, 574);
            this.tile637.Name = "tile637";
            this.tile637.Size = new System.Drawing.Size(32, 31);
            this.tile637.TabIndex = 680;
            this.tile637.TabStop = false;
            // 
            // tile638
            // 
            this.tile638.BackColor = System.Drawing.Color.White;
            this.tile638.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile638.Location = new System.Drawing.Point(1412, 574);
            this.tile638.Name = "tile638";
            this.tile638.Size = new System.Drawing.Size(32, 31);
            this.tile638.TabIndex = 679;
            this.tile638.TabStop = false;
            // 
            // tile640
            // 
            this.tile640.BackColor = System.Drawing.Color.White;
            this.tile640.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile640.Location = new System.Drawing.Point(1488, 574);
            this.tile640.Name = "tile640";
            this.tile640.Size = new System.Drawing.Size(32, 31);
            this.tile640.TabIndex = 678;
            this.tile640.TabStop = false;
            // 
            // tile639
            // 
            this.tile639.BackColor = System.Drawing.Color.White;
            this.tile639.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile639.Location = new System.Drawing.Point(1450, 574);
            this.tile639.Name = "tile639";
            this.tile639.Size = new System.Drawing.Size(32, 31);
            this.tile639.TabIndex = 677;
            this.tile639.TabStop = false;
            // 
            // tile632
            // 
            this.tile632.BackColor = System.Drawing.Color.White;
            this.tile632.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile632.Location = new System.Drawing.Point(1184, 574);
            this.tile632.Name = "tile632";
            this.tile632.Size = new System.Drawing.Size(32, 31);
            this.tile632.TabIndex = 676;
            this.tile632.TabStop = false;
            // 
            // tile631
            // 
            this.tile631.BackColor = System.Drawing.Color.White;
            this.tile631.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile631.Location = new System.Drawing.Point(1146, 574);
            this.tile631.Name = "tile631";
            this.tile631.Size = new System.Drawing.Size(32, 31);
            this.tile631.TabIndex = 675;
            this.tile631.TabStop = false;
            // 
            // tile628
            // 
            this.tile628.BackColor = System.Drawing.Color.White;
            this.tile628.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile628.Location = new System.Drawing.Point(1032, 574);
            this.tile628.Name = "tile628";
            this.tile628.Size = new System.Drawing.Size(32, 31);
            this.tile628.TabIndex = 674;
            this.tile628.TabStop = false;
            // 
            // tile627
            // 
            this.tile627.BackColor = System.Drawing.Color.White;
            this.tile627.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile627.Location = new System.Drawing.Point(994, 574);
            this.tile627.Name = "tile627";
            this.tile627.Size = new System.Drawing.Size(32, 31);
            this.tile627.TabIndex = 673;
            this.tile627.TabStop = false;
            // 
            // tile626
            // 
            this.tile626.BackColor = System.Drawing.Color.White;
            this.tile626.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile626.Location = new System.Drawing.Point(956, 574);
            this.tile626.Name = "tile626";
            this.tile626.Size = new System.Drawing.Size(32, 31);
            this.tile626.TabIndex = 672;
            this.tile626.TabStop = false;
            // 
            // tile625
            // 
            this.tile625.BackColor = System.Drawing.Color.White;
            this.tile625.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile625.Location = new System.Drawing.Point(918, 574);
            this.tile625.Name = "tile625";
            this.tile625.Size = new System.Drawing.Size(32, 31);
            this.tile625.TabIndex = 671;
            this.tile625.TabStop = false;
            // 
            // tile624
            // 
            this.tile624.BackColor = System.Drawing.Color.White;
            this.tile624.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile624.Location = new System.Drawing.Point(880, 574);
            this.tile624.Name = "tile624";
            this.tile624.Size = new System.Drawing.Size(32, 31);
            this.tile624.TabIndex = 670;
            this.tile624.TabStop = false;
            // 
            // tile623
            // 
            this.tile623.BackColor = System.Drawing.Color.White;
            this.tile623.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile623.Location = new System.Drawing.Point(842, 574);
            this.tile623.Name = "tile623";
            this.tile623.Size = new System.Drawing.Size(32, 31);
            this.tile623.TabIndex = 669;
            this.tile623.TabStop = false;
            // 
            // tile621
            // 
            this.tile621.BackColor = System.Drawing.Color.White;
            this.tile621.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile621.Location = new System.Drawing.Point(766, 574);
            this.tile621.Name = "tile621";
            this.tile621.Size = new System.Drawing.Size(32, 31);
            this.tile621.TabIndex = 668;
            this.tile621.TabStop = false;
            // 
            // tile622
            // 
            this.tile622.BackColor = System.Drawing.Color.White;
            this.tile622.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile622.Location = new System.Drawing.Point(804, 574);
            this.tile622.Name = "tile622";
            this.tile622.Size = new System.Drawing.Size(32, 31);
            this.tile622.TabIndex = 667;
            this.tile622.TabStop = false;
            // 
            // tile629
            // 
            this.tile629.BackColor = System.Drawing.Color.White;
            this.tile629.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile629.Location = new System.Drawing.Point(1070, 574);
            this.tile629.Name = "tile629";
            this.tile629.Size = new System.Drawing.Size(32, 31);
            this.tile629.TabIndex = 666;
            this.tile629.TabStop = false;
            // 
            // tile630
            // 
            this.tile630.BackColor = System.Drawing.Color.White;
            this.tile630.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile630.Location = new System.Drawing.Point(1108, 574);
            this.tile630.Name = "tile630";
            this.tile630.Size = new System.Drawing.Size(32, 31);
            this.tile630.TabIndex = 665;
            this.tile630.TabStop = false;
            // 
            // tile613
            // 
            this.tile613.BackColor = System.Drawing.Color.White;
            this.tile613.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile613.Location = new System.Drawing.Point(462, 574);
            this.tile613.Name = "tile613";
            this.tile613.Size = new System.Drawing.Size(32, 31);
            this.tile613.TabIndex = 664;
            this.tile613.TabStop = false;
            // 
            // tile614
            // 
            this.tile614.BackColor = System.Drawing.Color.White;
            this.tile614.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile614.Location = new System.Drawing.Point(500, 574);
            this.tile614.Name = "tile614";
            this.tile614.Size = new System.Drawing.Size(32, 31);
            this.tile614.TabIndex = 663;
            this.tile614.TabStop = false;
            // 
            // tile615
            // 
            this.tile615.BackColor = System.Drawing.Color.White;
            this.tile615.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile615.Location = new System.Drawing.Point(538, 574);
            this.tile615.Name = "tile615";
            this.tile615.Size = new System.Drawing.Size(32, 31);
            this.tile615.TabIndex = 662;
            this.tile615.TabStop = false;
            // 
            // tile616
            // 
            this.tile616.BackColor = System.Drawing.Color.White;
            this.tile616.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile616.Location = new System.Drawing.Point(576, 574);
            this.tile616.Name = "tile616";
            this.tile616.Size = new System.Drawing.Size(32, 31);
            this.tile616.TabIndex = 661;
            this.tile616.TabStop = false;
            // 
            // tile617
            // 
            this.tile617.BackColor = System.Drawing.Color.White;
            this.tile617.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile617.Location = new System.Drawing.Point(614, 574);
            this.tile617.Name = "tile617";
            this.tile617.Size = new System.Drawing.Size(32, 31);
            this.tile617.TabIndex = 660;
            this.tile617.TabStop = false;
            // 
            // tile618
            // 
            this.tile618.BackColor = System.Drawing.Color.White;
            this.tile618.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile618.Location = new System.Drawing.Point(652, 574);
            this.tile618.Name = "tile618";
            this.tile618.Size = new System.Drawing.Size(32, 31);
            this.tile618.TabIndex = 659;
            this.tile618.TabStop = false;
            // 
            // tile619
            // 
            this.tile619.BackColor = System.Drawing.Color.White;
            this.tile619.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile619.Location = new System.Drawing.Point(690, 574);
            this.tile619.Name = "tile619";
            this.tile619.Size = new System.Drawing.Size(32, 31);
            this.tile619.TabIndex = 658;
            this.tile619.TabStop = false;
            // 
            // tile620
            // 
            this.tile620.BackColor = System.Drawing.Color.White;
            this.tile620.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile620.Location = new System.Drawing.Point(728, 574);
            this.tile620.Name = "tile620";
            this.tile620.Size = new System.Drawing.Size(32, 31);
            this.tile620.TabIndex = 657;
            this.tile620.TabStop = false;
            // 
            // tile612
            // 
            this.tile612.BackColor = System.Drawing.Color.White;
            this.tile612.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile612.Location = new System.Drawing.Point(424, 574);
            this.tile612.Name = "tile612";
            this.tile612.Size = new System.Drawing.Size(32, 31);
            this.tile612.TabIndex = 656;
            this.tile612.TabStop = false;
            // 
            // tile611
            // 
            this.tile611.BackColor = System.Drawing.Color.White;
            this.tile611.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile611.Location = new System.Drawing.Point(386, 574);
            this.tile611.Name = "tile611";
            this.tile611.Size = new System.Drawing.Size(32, 31);
            this.tile611.TabIndex = 655;
            this.tile611.TabStop = false;
            // 
            // tile603
            // 
            this.tile603.BackColor = System.Drawing.Color.White;
            this.tile603.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile603.Location = new System.Drawing.Point(82, 574);
            this.tile603.Name = "tile603";
            this.tile603.Size = new System.Drawing.Size(32, 31);
            this.tile603.TabIndex = 654;
            this.tile603.TabStop = false;
            // 
            // tile604
            // 
            this.tile604.BackColor = System.Drawing.Color.White;
            this.tile604.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile604.Location = new System.Drawing.Point(120, 574);
            this.tile604.Name = "tile604";
            this.tile604.Size = new System.Drawing.Size(32, 31);
            this.tile604.TabIndex = 653;
            this.tile604.TabStop = false;
            // 
            // tile605
            // 
            this.tile605.BackColor = System.Drawing.Color.White;
            this.tile605.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile605.Location = new System.Drawing.Point(158, 574);
            this.tile605.Name = "tile605";
            this.tile605.Size = new System.Drawing.Size(32, 31);
            this.tile605.TabIndex = 652;
            this.tile605.TabStop = false;
            // 
            // tile606
            // 
            this.tile606.BackColor = System.Drawing.Color.White;
            this.tile606.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile606.Location = new System.Drawing.Point(196, 574);
            this.tile606.Name = "tile606";
            this.tile606.Size = new System.Drawing.Size(32, 31);
            this.tile606.TabIndex = 651;
            this.tile606.TabStop = false;
            // 
            // tile607
            // 
            this.tile607.BackColor = System.Drawing.Color.White;
            this.tile607.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile607.Location = new System.Drawing.Point(234, 574);
            this.tile607.Name = "tile607";
            this.tile607.Size = new System.Drawing.Size(32, 31);
            this.tile607.TabIndex = 650;
            this.tile607.TabStop = false;
            // 
            // tile608
            // 
            this.tile608.BackColor = System.Drawing.Color.White;
            this.tile608.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile608.Location = new System.Drawing.Point(272, 574);
            this.tile608.Name = "tile608";
            this.tile608.Size = new System.Drawing.Size(32, 31);
            this.tile608.TabIndex = 649;
            this.tile608.TabStop = false;
            // 
            // tile609
            // 
            this.tile609.BackColor = System.Drawing.Color.White;
            this.tile609.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile609.Location = new System.Drawing.Point(310, 574);
            this.tile609.Name = "tile609";
            this.tile609.Size = new System.Drawing.Size(32, 31);
            this.tile609.TabIndex = 648;
            this.tile609.TabStop = false;
            // 
            // tile610
            // 
            this.tile610.BackColor = System.Drawing.Color.White;
            this.tile610.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile610.Location = new System.Drawing.Point(348, 574);
            this.tile610.Name = "tile610";
            this.tile610.Size = new System.Drawing.Size(32, 31);
            this.tile610.TabIndex = 647;
            this.tile610.TabStop = false;
            // 
            // tile602
            // 
            this.tile602.BackColor = System.Drawing.Color.White;
            this.tile602.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile602.Location = new System.Drawing.Point(44, 574);
            this.tile602.Name = "tile602";
            this.tile602.Size = new System.Drawing.Size(32, 31);
            this.tile602.TabIndex = 646;
            this.tile602.TabStop = false;
            // 
            // tile601
            // 
            this.tile601.BackColor = System.Drawing.Color.White;
            this.tile601.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile601.Location = new System.Drawing.Point(6, 574);
            this.tile601.Name = "tile601";
            this.tile601.Size = new System.Drawing.Size(32, 31);
            this.tile601.TabIndex = 645;
            this.tile601.TabStop = false;
            // 
            // tile593
            // 
            this.tile593.BackColor = System.Drawing.Color.White;
            this.tile593.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile593.Location = new System.Drawing.Point(1222, 537);
            this.tile593.Name = "tile593";
            this.tile593.Size = new System.Drawing.Size(32, 31);
            this.tile593.TabIndex = 644;
            this.tile593.TabStop = false;
            // 
            // tile594
            // 
            this.tile594.BackColor = System.Drawing.Color.White;
            this.tile594.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile594.Location = new System.Drawing.Point(1260, 537);
            this.tile594.Name = "tile594";
            this.tile594.Size = new System.Drawing.Size(32, 31);
            this.tile594.TabIndex = 643;
            this.tile594.TabStop = false;
            // 
            // tile595
            // 
            this.tile595.BackColor = System.Drawing.Color.White;
            this.tile595.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile595.Location = new System.Drawing.Point(1298, 537);
            this.tile595.Name = "tile595";
            this.tile595.Size = new System.Drawing.Size(32, 31);
            this.tile595.TabIndex = 642;
            this.tile595.TabStop = false;
            // 
            // tile596
            // 
            this.tile596.BackColor = System.Drawing.Color.White;
            this.tile596.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile596.Location = new System.Drawing.Point(1336, 537);
            this.tile596.Name = "tile596";
            this.tile596.Size = new System.Drawing.Size(32, 31);
            this.tile596.TabIndex = 641;
            this.tile596.TabStop = false;
            // 
            // tile597
            // 
            this.tile597.BackColor = System.Drawing.Color.White;
            this.tile597.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile597.Location = new System.Drawing.Point(1374, 537);
            this.tile597.Name = "tile597";
            this.tile597.Size = new System.Drawing.Size(32, 31);
            this.tile597.TabIndex = 640;
            this.tile597.TabStop = false;
            // 
            // tile598
            // 
            this.tile598.BackColor = System.Drawing.Color.White;
            this.tile598.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile598.Location = new System.Drawing.Point(1412, 537);
            this.tile598.Name = "tile598";
            this.tile598.Size = new System.Drawing.Size(32, 31);
            this.tile598.TabIndex = 639;
            this.tile598.TabStop = false;
            // 
            // tile600
            // 
            this.tile600.BackColor = System.Drawing.Color.White;
            this.tile600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile600.Location = new System.Drawing.Point(1488, 537);
            this.tile600.Name = "tile600";
            this.tile600.Size = new System.Drawing.Size(32, 31);
            this.tile600.TabIndex = 638;
            this.tile600.TabStop = false;
            // 
            // tile599
            // 
            this.tile599.BackColor = System.Drawing.Color.White;
            this.tile599.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile599.Location = new System.Drawing.Point(1450, 537);
            this.tile599.Name = "tile599";
            this.tile599.Size = new System.Drawing.Size(32, 31);
            this.tile599.TabIndex = 637;
            this.tile599.TabStop = false;
            // 
            // tile592
            // 
            this.tile592.BackColor = System.Drawing.Color.White;
            this.tile592.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile592.Location = new System.Drawing.Point(1184, 537);
            this.tile592.Name = "tile592";
            this.tile592.Size = new System.Drawing.Size(32, 31);
            this.tile592.TabIndex = 636;
            this.tile592.TabStop = false;
            // 
            // tile591
            // 
            this.tile591.BackColor = System.Drawing.Color.White;
            this.tile591.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile591.Location = new System.Drawing.Point(1146, 537);
            this.tile591.Name = "tile591";
            this.tile591.Size = new System.Drawing.Size(32, 31);
            this.tile591.TabIndex = 635;
            this.tile591.TabStop = false;
            // 
            // tile588
            // 
            this.tile588.BackColor = System.Drawing.Color.White;
            this.tile588.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile588.Location = new System.Drawing.Point(1032, 537);
            this.tile588.Name = "tile588";
            this.tile588.Size = new System.Drawing.Size(32, 31);
            this.tile588.TabIndex = 634;
            this.tile588.TabStop = false;
            // 
            // tile587
            // 
            this.tile587.BackColor = System.Drawing.Color.White;
            this.tile587.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile587.Location = new System.Drawing.Point(994, 537);
            this.tile587.Name = "tile587";
            this.tile587.Size = new System.Drawing.Size(32, 31);
            this.tile587.TabIndex = 633;
            this.tile587.TabStop = false;
            // 
            // tile586
            // 
            this.tile586.BackColor = System.Drawing.Color.White;
            this.tile586.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile586.Location = new System.Drawing.Point(956, 537);
            this.tile586.Name = "tile586";
            this.tile586.Size = new System.Drawing.Size(32, 31);
            this.tile586.TabIndex = 632;
            this.tile586.TabStop = false;
            // 
            // tile585
            // 
            this.tile585.BackColor = System.Drawing.Color.White;
            this.tile585.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile585.Location = new System.Drawing.Point(918, 537);
            this.tile585.Name = "tile585";
            this.tile585.Size = new System.Drawing.Size(32, 31);
            this.tile585.TabIndex = 631;
            this.tile585.TabStop = false;
            // 
            // tile584
            // 
            this.tile584.BackColor = System.Drawing.Color.White;
            this.tile584.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile584.Location = new System.Drawing.Point(880, 537);
            this.tile584.Name = "tile584";
            this.tile584.Size = new System.Drawing.Size(32, 31);
            this.tile584.TabIndex = 630;
            this.tile584.TabStop = false;
            // 
            // tile583
            // 
            this.tile583.BackColor = System.Drawing.Color.White;
            this.tile583.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile583.Location = new System.Drawing.Point(842, 537);
            this.tile583.Name = "tile583";
            this.tile583.Size = new System.Drawing.Size(32, 31);
            this.tile583.TabIndex = 629;
            this.tile583.TabStop = false;
            // 
            // tile581
            // 
            this.tile581.BackColor = System.Drawing.Color.White;
            this.tile581.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile581.Location = new System.Drawing.Point(766, 537);
            this.tile581.Name = "tile581";
            this.tile581.Size = new System.Drawing.Size(32, 31);
            this.tile581.TabIndex = 628;
            this.tile581.TabStop = false;
            // 
            // tile582
            // 
            this.tile582.BackColor = System.Drawing.Color.White;
            this.tile582.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile582.Location = new System.Drawing.Point(804, 537);
            this.tile582.Name = "tile582";
            this.tile582.Size = new System.Drawing.Size(32, 31);
            this.tile582.TabIndex = 627;
            this.tile582.TabStop = false;
            // 
            // tile589
            // 
            this.tile589.BackColor = System.Drawing.Color.White;
            this.tile589.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile589.Location = new System.Drawing.Point(1070, 537);
            this.tile589.Name = "tile589";
            this.tile589.Size = new System.Drawing.Size(32, 31);
            this.tile589.TabIndex = 626;
            this.tile589.TabStop = false;
            // 
            // tile590
            // 
            this.tile590.BackColor = System.Drawing.Color.White;
            this.tile590.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile590.Location = new System.Drawing.Point(1108, 537);
            this.tile590.Name = "tile590";
            this.tile590.Size = new System.Drawing.Size(32, 31);
            this.tile590.TabIndex = 625;
            this.tile590.TabStop = false;
            // 
            // tile573
            // 
            this.tile573.BackColor = System.Drawing.Color.White;
            this.tile573.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile573.Location = new System.Drawing.Point(462, 537);
            this.tile573.Name = "tile573";
            this.tile573.Size = new System.Drawing.Size(32, 31);
            this.tile573.TabIndex = 624;
            this.tile573.TabStop = false;
            // 
            // tile574
            // 
            this.tile574.BackColor = System.Drawing.Color.White;
            this.tile574.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile574.Location = new System.Drawing.Point(500, 537);
            this.tile574.Name = "tile574";
            this.tile574.Size = new System.Drawing.Size(32, 31);
            this.tile574.TabIndex = 623;
            this.tile574.TabStop = false;
            // 
            // tile575
            // 
            this.tile575.BackColor = System.Drawing.Color.White;
            this.tile575.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile575.Location = new System.Drawing.Point(538, 537);
            this.tile575.Name = "tile575";
            this.tile575.Size = new System.Drawing.Size(32, 31);
            this.tile575.TabIndex = 622;
            this.tile575.TabStop = false;
            // 
            // tile576
            // 
            this.tile576.BackColor = System.Drawing.Color.White;
            this.tile576.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile576.Location = new System.Drawing.Point(576, 537);
            this.tile576.Name = "tile576";
            this.tile576.Size = new System.Drawing.Size(32, 31);
            this.tile576.TabIndex = 621;
            this.tile576.TabStop = false;
            // 
            // tile577
            // 
            this.tile577.BackColor = System.Drawing.Color.White;
            this.tile577.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile577.Location = new System.Drawing.Point(614, 537);
            this.tile577.Name = "tile577";
            this.tile577.Size = new System.Drawing.Size(32, 31);
            this.tile577.TabIndex = 620;
            this.tile577.TabStop = false;
            // 
            // tile578
            // 
            this.tile578.BackColor = System.Drawing.Color.White;
            this.tile578.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile578.Location = new System.Drawing.Point(652, 537);
            this.tile578.Name = "tile578";
            this.tile578.Size = new System.Drawing.Size(32, 31);
            this.tile578.TabIndex = 619;
            this.tile578.TabStop = false;
            // 
            // tile579
            // 
            this.tile579.BackColor = System.Drawing.Color.White;
            this.tile579.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile579.Location = new System.Drawing.Point(690, 537);
            this.tile579.Name = "tile579";
            this.tile579.Size = new System.Drawing.Size(32, 31);
            this.tile579.TabIndex = 618;
            this.tile579.TabStop = false;
            // 
            // tile580
            // 
            this.tile580.BackColor = System.Drawing.Color.White;
            this.tile580.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile580.Location = new System.Drawing.Point(728, 537);
            this.tile580.Name = "tile580";
            this.tile580.Size = new System.Drawing.Size(32, 31);
            this.tile580.TabIndex = 617;
            this.tile580.TabStop = false;
            // 
            // tile572
            // 
            this.tile572.BackColor = System.Drawing.Color.White;
            this.tile572.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile572.Location = new System.Drawing.Point(424, 537);
            this.tile572.Name = "tile572";
            this.tile572.Size = new System.Drawing.Size(32, 31);
            this.tile572.TabIndex = 616;
            this.tile572.TabStop = false;
            // 
            // tile571
            // 
            this.tile571.BackColor = System.Drawing.Color.White;
            this.tile571.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile571.Location = new System.Drawing.Point(386, 537);
            this.tile571.Name = "tile571";
            this.tile571.Size = new System.Drawing.Size(32, 31);
            this.tile571.TabIndex = 615;
            this.tile571.TabStop = false;
            // 
            // tile563
            // 
            this.tile563.BackColor = System.Drawing.Color.White;
            this.tile563.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile563.Location = new System.Drawing.Point(82, 537);
            this.tile563.Name = "tile563";
            this.tile563.Size = new System.Drawing.Size(32, 31);
            this.tile563.TabIndex = 614;
            this.tile563.TabStop = false;
            // 
            // tile564
            // 
            this.tile564.BackColor = System.Drawing.Color.White;
            this.tile564.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile564.Location = new System.Drawing.Point(120, 537);
            this.tile564.Name = "tile564";
            this.tile564.Size = new System.Drawing.Size(32, 31);
            this.tile564.TabIndex = 613;
            this.tile564.TabStop = false;
            // 
            // tile565
            // 
            this.tile565.BackColor = System.Drawing.Color.White;
            this.tile565.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile565.Location = new System.Drawing.Point(158, 537);
            this.tile565.Name = "tile565";
            this.tile565.Size = new System.Drawing.Size(32, 31);
            this.tile565.TabIndex = 612;
            this.tile565.TabStop = false;
            // 
            // tile566
            // 
            this.tile566.BackColor = System.Drawing.Color.White;
            this.tile566.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile566.Location = new System.Drawing.Point(196, 537);
            this.tile566.Name = "tile566";
            this.tile566.Size = new System.Drawing.Size(32, 31);
            this.tile566.TabIndex = 611;
            this.tile566.TabStop = false;
            // 
            // tile567
            // 
            this.tile567.BackColor = System.Drawing.Color.White;
            this.tile567.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile567.Location = new System.Drawing.Point(234, 537);
            this.tile567.Name = "tile567";
            this.tile567.Size = new System.Drawing.Size(32, 31);
            this.tile567.TabIndex = 610;
            this.tile567.TabStop = false;
            // 
            // tile568
            // 
            this.tile568.BackColor = System.Drawing.Color.White;
            this.tile568.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile568.Location = new System.Drawing.Point(272, 537);
            this.tile568.Name = "tile568";
            this.tile568.Size = new System.Drawing.Size(32, 31);
            this.tile568.TabIndex = 609;
            this.tile568.TabStop = false;
            // 
            // tile569
            // 
            this.tile569.BackColor = System.Drawing.Color.White;
            this.tile569.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile569.Location = new System.Drawing.Point(310, 537);
            this.tile569.Name = "tile569";
            this.tile569.Size = new System.Drawing.Size(32, 31);
            this.tile569.TabIndex = 608;
            this.tile569.TabStop = false;
            // 
            // tile570
            // 
            this.tile570.BackColor = System.Drawing.Color.White;
            this.tile570.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile570.Location = new System.Drawing.Point(348, 537);
            this.tile570.Name = "tile570";
            this.tile570.Size = new System.Drawing.Size(32, 31);
            this.tile570.TabIndex = 607;
            this.tile570.TabStop = false;
            // 
            // tile562
            // 
            this.tile562.BackColor = System.Drawing.Color.White;
            this.tile562.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile562.Location = new System.Drawing.Point(44, 537);
            this.tile562.Name = "tile562";
            this.tile562.Size = new System.Drawing.Size(32, 31);
            this.tile562.TabIndex = 606;
            this.tile562.TabStop = false;
            // 
            // tile561
            // 
            this.tile561.BackColor = System.Drawing.Color.White;
            this.tile561.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile561.Location = new System.Drawing.Point(6, 537);
            this.tile561.Name = "tile561";
            this.tile561.Size = new System.Drawing.Size(32, 31);
            this.tile561.TabIndex = 605;
            this.tile561.TabStop = false;
            // 
            // tile553
            // 
            this.tile553.BackColor = System.Drawing.Color.White;
            this.tile553.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile553.Location = new System.Drawing.Point(1222, 500);
            this.tile553.Name = "tile553";
            this.tile553.Size = new System.Drawing.Size(32, 31);
            this.tile553.TabIndex = 604;
            this.tile553.TabStop = false;
            // 
            // tile554
            // 
            this.tile554.BackColor = System.Drawing.Color.White;
            this.tile554.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile554.Location = new System.Drawing.Point(1260, 500);
            this.tile554.Name = "tile554";
            this.tile554.Size = new System.Drawing.Size(32, 31);
            this.tile554.TabIndex = 603;
            this.tile554.TabStop = false;
            // 
            // tile555
            // 
            this.tile555.BackColor = System.Drawing.Color.White;
            this.tile555.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile555.Location = new System.Drawing.Point(1298, 500);
            this.tile555.Name = "tile555";
            this.tile555.Size = new System.Drawing.Size(32, 31);
            this.tile555.TabIndex = 602;
            this.tile555.TabStop = false;
            // 
            // tile556
            // 
            this.tile556.BackColor = System.Drawing.Color.White;
            this.tile556.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile556.Location = new System.Drawing.Point(1336, 500);
            this.tile556.Name = "tile556";
            this.tile556.Size = new System.Drawing.Size(32, 31);
            this.tile556.TabIndex = 601;
            this.tile556.TabStop = false;
            // 
            // tile557
            // 
            this.tile557.BackColor = System.Drawing.Color.White;
            this.tile557.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile557.Location = new System.Drawing.Point(1374, 500);
            this.tile557.Name = "tile557";
            this.tile557.Size = new System.Drawing.Size(32, 31);
            this.tile557.TabIndex = 600;
            this.tile557.TabStop = false;
            // 
            // tile558
            // 
            this.tile558.BackColor = System.Drawing.Color.White;
            this.tile558.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile558.Location = new System.Drawing.Point(1412, 500);
            this.tile558.Name = "tile558";
            this.tile558.Size = new System.Drawing.Size(32, 31);
            this.tile558.TabIndex = 599;
            this.tile558.TabStop = false;
            // 
            // tile560
            // 
            this.tile560.BackColor = System.Drawing.Color.White;
            this.tile560.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile560.Location = new System.Drawing.Point(1488, 500);
            this.tile560.Name = "tile560";
            this.tile560.Size = new System.Drawing.Size(32, 31);
            this.tile560.TabIndex = 598;
            this.tile560.TabStop = false;
            // 
            // tile559
            // 
            this.tile559.BackColor = System.Drawing.Color.White;
            this.tile559.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile559.Location = new System.Drawing.Point(1450, 500);
            this.tile559.Name = "tile559";
            this.tile559.Size = new System.Drawing.Size(32, 31);
            this.tile559.TabIndex = 597;
            this.tile559.TabStop = false;
            // 
            // tile552
            // 
            this.tile552.BackColor = System.Drawing.Color.White;
            this.tile552.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile552.Location = new System.Drawing.Point(1184, 500);
            this.tile552.Name = "tile552";
            this.tile552.Size = new System.Drawing.Size(32, 31);
            this.tile552.TabIndex = 596;
            this.tile552.TabStop = false;
            // 
            // tile551
            // 
            this.tile551.BackColor = System.Drawing.Color.White;
            this.tile551.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile551.Location = new System.Drawing.Point(1146, 500);
            this.tile551.Name = "tile551";
            this.tile551.Size = new System.Drawing.Size(32, 31);
            this.tile551.TabIndex = 595;
            this.tile551.TabStop = false;
            // 
            // tile548
            // 
            this.tile548.BackColor = System.Drawing.Color.White;
            this.tile548.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile548.Location = new System.Drawing.Point(1032, 500);
            this.tile548.Name = "tile548";
            this.tile548.Size = new System.Drawing.Size(32, 31);
            this.tile548.TabIndex = 594;
            this.tile548.TabStop = false;
            // 
            // tile547
            // 
            this.tile547.BackColor = System.Drawing.Color.White;
            this.tile547.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile547.Location = new System.Drawing.Point(994, 500);
            this.tile547.Name = "tile547";
            this.tile547.Size = new System.Drawing.Size(32, 31);
            this.tile547.TabIndex = 593;
            this.tile547.TabStop = false;
            // 
            // tile546
            // 
            this.tile546.BackColor = System.Drawing.Color.White;
            this.tile546.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile546.Location = new System.Drawing.Point(956, 500);
            this.tile546.Name = "tile546";
            this.tile546.Size = new System.Drawing.Size(32, 31);
            this.tile546.TabIndex = 592;
            this.tile546.TabStop = false;
            // 
            // tile545
            // 
            this.tile545.BackColor = System.Drawing.Color.White;
            this.tile545.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile545.Location = new System.Drawing.Point(918, 500);
            this.tile545.Name = "tile545";
            this.tile545.Size = new System.Drawing.Size(32, 31);
            this.tile545.TabIndex = 591;
            this.tile545.TabStop = false;
            // 
            // tile544
            // 
            this.tile544.BackColor = System.Drawing.Color.White;
            this.tile544.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile544.Location = new System.Drawing.Point(880, 500);
            this.tile544.Name = "tile544";
            this.tile544.Size = new System.Drawing.Size(32, 31);
            this.tile544.TabIndex = 590;
            this.tile544.TabStop = false;
            // 
            // tile543
            // 
            this.tile543.BackColor = System.Drawing.Color.White;
            this.tile543.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile543.Location = new System.Drawing.Point(842, 500);
            this.tile543.Name = "tile543";
            this.tile543.Size = new System.Drawing.Size(32, 31);
            this.tile543.TabIndex = 589;
            this.tile543.TabStop = false;
            // 
            // tile541
            // 
            this.tile541.BackColor = System.Drawing.Color.White;
            this.tile541.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile541.Location = new System.Drawing.Point(766, 500);
            this.tile541.Name = "tile541";
            this.tile541.Size = new System.Drawing.Size(32, 31);
            this.tile541.TabIndex = 588;
            this.tile541.TabStop = false;
            // 
            // tile542
            // 
            this.tile542.BackColor = System.Drawing.Color.White;
            this.tile542.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile542.Location = new System.Drawing.Point(804, 500);
            this.tile542.Name = "tile542";
            this.tile542.Size = new System.Drawing.Size(32, 31);
            this.tile542.TabIndex = 587;
            this.tile542.TabStop = false;
            // 
            // tile549
            // 
            this.tile549.BackColor = System.Drawing.Color.White;
            this.tile549.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile549.Location = new System.Drawing.Point(1070, 500);
            this.tile549.Name = "tile549";
            this.tile549.Size = new System.Drawing.Size(32, 31);
            this.tile549.TabIndex = 586;
            this.tile549.TabStop = false;
            // 
            // tile550
            // 
            this.tile550.BackColor = System.Drawing.Color.White;
            this.tile550.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile550.Location = new System.Drawing.Point(1108, 500);
            this.tile550.Name = "tile550";
            this.tile550.Size = new System.Drawing.Size(32, 31);
            this.tile550.TabIndex = 585;
            this.tile550.TabStop = false;
            // 
            // tile533
            // 
            this.tile533.BackColor = System.Drawing.Color.White;
            this.tile533.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile533.Location = new System.Drawing.Point(462, 500);
            this.tile533.Name = "tile533";
            this.tile533.Size = new System.Drawing.Size(32, 31);
            this.tile533.TabIndex = 584;
            this.tile533.TabStop = false;
            // 
            // tile534
            // 
            this.tile534.BackColor = System.Drawing.Color.White;
            this.tile534.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile534.Location = new System.Drawing.Point(500, 500);
            this.tile534.Name = "tile534";
            this.tile534.Size = new System.Drawing.Size(32, 31);
            this.tile534.TabIndex = 583;
            this.tile534.TabStop = false;
            // 
            // tile535
            // 
            this.tile535.BackColor = System.Drawing.Color.White;
            this.tile535.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile535.Location = new System.Drawing.Point(538, 500);
            this.tile535.Name = "tile535";
            this.tile535.Size = new System.Drawing.Size(32, 31);
            this.tile535.TabIndex = 582;
            this.tile535.TabStop = false;
            // 
            // tile536
            // 
            this.tile536.BackColor = System.Drawing.Color.White;
            this.tile536.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile536.Location = new System.Drawing.Point(576, 500);
            this.tile536.Name = "tile536";
            this.tile536.Size = new System.Drawing.Size(32, 31);
            this.tile536.TabIndex = 581;
            this.tile536.TabStop = false;
            // 
            // tile537
            // 
            this.tile537.BackColor = System.Drawing.Color.White;
            this.tile537.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile537.Location = new System.Drawing.Point(614, 500);
            this.tile537.Name = "tile537";
            this.tile537.Size = new System.Drawing.Size(32, 31);
            this.tile537.TabIndex = 580;
            this.tile537.TabStop = false;
            // 
            // tile538
            // 
            this.tile538.BackColor = System.Drawing.Color.White;
            this.tile538.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile538.Location = new System.Drawing.Point(652, 500);
            this.tile538.Name = "tile538";
            this.tile538.Size = new System.Drawing.Size(32, 31);
            this.tile538.TabIndex = 579;
            this.tile538.TabStop = false;
            // 
            // tile539
            // 
            this.tile539.BackColor = System.Drawing.Color.White;
            this.tile539.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile539.Location = new System.Drawing.Point(690, 500);
            this.tile539.Name = "tile539";
            this.tile539.Size = new System.Drawing.Size(32, 31);
            this.tile539.TabIndex = 578;
            this.tile539.TabStop = false;
            // 
            // tile540
            // 
            this.tile540.BackColor = System.Drawing.Color.White;
            this.tile540.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile540.Location = new System.Drawing.Point(728, 500);
            this.tile540.Name = "tile540";
            this.tile540.Size = new System.Drawing.Size(32, 31);
            this.tile540.TabIndex = 577;
            this.tile540.TabStop = false;
            // 
            // tile532
            // 
            this.tile532.BackColor = System.Drawing.Color.White;
            this.tile532.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile532.Location = new System.Drawing.Point(424, 500);
            this.tile532.Name = "tile532";
            this.tile532.Size = new System.Drawing.Size(32, 31);
            this.tile532.TabIndex = 576;
            this.tile532.TabStop = false;
            // 
            // tile531
            // 
            this.tile531.BackColor = System.Drawing.Color.White;
            this.tile531.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile531.Location = new System.Drawing.Point(386, 500);
            this.tile531.Name = "tile531";
            this.tile531.Size = new System.Drawing.Size(32, 31);
            this.tile531.TabIndex = 575;
            this.tile531.TabStop = false;
            // 
            // tile523
            // 
            this.tile523.BackColor = System.Drawing.Color.White;
            this.tile523.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile523.Location = new System.Drawing.Point(82, 500);
            this.tile523.Name = "tile523";
            this.tile523.Size = new System.Drawing.Size(32, 31);
            this.tile523.TabIndex = 574;
            this.tile523.TabStop = false;
            // 
            // tile524
            // 
            this.tile524.BackColor = System.Drawing.Color.White;
            this.tile524.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile524.Location = new System.Drawing.Point(120, 500);
            this.tile524.Name = "tile524";
            this.tile524.Size = new System.Drawing.Size(32, 31);
            this.tile524.TabIndex = 573;
            this.tile524.TabStop = false;
            // 
            // tile525
            // 
            this.tile525.BackColor = System.Drawing.Color.White;
            this.tile525.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile525.Location = new System.Drawing.Point(158, 500);
            this.tile525.Name = "tile525";
            this.tile525.Size = new System.Drawing.Size(32, 31);
            this.tile525.TabIndex = 572;
            this.tile525.TabStop = false;
            // 
            // tile526
            // 
            this.tile526.BackColor = System.Drawing.Color.White;
            this.tile526.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile526.Location = new System.Drawing.Point(196, 500);
            this.tile526.Name = "tile526";
            this.tile526.Size = new System.Drawing.Size(32, 31);
            this.tile526.TabIndex = 571;
            this.tile526.TabStop = false;
            // 
            // tile527
            // 
            this.tile527.BackColor = System.Drawing.Color.White;
            this.tile527.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile527.Location = new System.Drawing.Point(234, 500);
            this.tile527.Name = "tile527";
            this.tile527.Size = new System.Drawing.Size(32, 31);
            this.tile527.TabIndex = 570;
            this.tile527.TabStop = false;
            // 
            // tile528
            // 
            this.tile528.BackColor = System.Drawing.Color.White;
            this.tile528.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile528.Location = new System.Drawing.Point(272, 500);
            this.tile528.Name = "tile528";
            this.tile528.Size = new System.Drawing.Size(32, 31);
            this.tile528.TabIndex = 569;
            this.tile528.TabStop = false;
            // 
            // tile529
            // 
            this.tile529.BackColor = System.Drawing.Color.White;
            this.tile529.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile529.Location = new System.Drawing.Point(310, 500);
            this.tile529.Name = "tile529";
            this.tile529.Size = new System.Drawing.Size(32, 31);
            this.tile529.TabIndex = 568;
            this.tile529.TabStop = false;
            // 
            // tile530
            // 
            this.tile530.BackColor = System.Drawing.Color.White;
            this.tile530.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile530.Location = new System.Drawing.Point(348, 500);
            this.tile530.Name = "tile530";
            this.tile530.Size = new System.Drawing.Size(32, 31);
            this.tile530.TabIndex = 567;
            this.tile530.TabStop = false;
            // 
            // tile522
            // 
            this.tile522.BackColor = System.Drawing.Color.White;
            this.tile522.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile522.Location = new System.Drawing.Point(44, 500);
            this.tile522.Name = "tile522";
            this.tile522.Size = new System.Drawing.Size(32, 31);
            this.tile522.TabIndex = 566;
            this.tile522.TabStop = false;
            // 
            // tile521
            // 
            this.tile521.BackColor = System.Drawing.Color.White;
            this.tile521.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile521.Location = new System.Drawing.Point(6, 500);
            this.tile521.Name = "tile521";
            this.tile521.Size = new System.Drawing.Size(32, 31);
            this.tile521.TabIndex = 565;
            this.tile521.TabStop = false;
            // 
            // tile513
            // 
            this.tile513.BackColor = System.Drawing.Color.White;
            this.tile513.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile513.Location = new System.Drawing.Point(1222, 463);
            this.tile513.Name = "tile513";
            this.tile513.Size = new System.Drawing.Size(32, 31);
            this.tile513.TabIndex = 564;
            this.tile513.TabStop = false;
            // 
            // tile514
            // 
            this.tile514.BackColor = System.Drawing.Color.White;
            this.tile514.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile514.Location = new System.Drawing.Point(1260, 463);
            this.tile514.Name = "tile514";
            this.tile514.Size = new System.Drawing.Size(32, 31);
            this.tile514.TabIndex = 563;
            this.tile514.TabStop = false;
            // 
            // tile515
            // 
            this.tile515.BackColor = System.Drawing.Color.White;
            this.tile515.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile515.Location = new System.Drawing.Point(1298, 463);
            this.tile515.Name = "tile515";
            this.tile515.Size = new System.Drawing.Size(32, 31);
            this.tile515.TabIndex = 562;
            this.tile515.TabStop = false;
            // 
            // tile516
            // 
            this.tile516.BackColor = System.Drawing.Color.White;
            this.tile516.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile516.Location = new System.Drawing.Point(1336, 463);
            this.tile516.Name = "tile516";
            this.tile516.Size = new System.Drawing.Size(32, 31);
            this.tile516.TabIndex = 561;
            this.tile516.TabStop = false;
            // 
            // tile517
            // 
            this.tile517.BackColor = System.Drawing.Color.White;
            this.tile517.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile517.Location = new System.Drawing.Point(1374, 463);
            this.tile517.Name = "tile517";
            this.tile517.Size = new System.Drawing.Size(32, 31);
            this.tile517.TabIndex = 560;
            this.tile517.TabStop = false;
            // 
            // tile518
            // 
            this.tile518.BackColor = System.Drawing.Color.White;
            this.tile518.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile518.Location = new System.Drawing.Point(1412, 463);
            this.tile518.Name = "tile518";
            this.tile518.Size = new System.Drawing.Size(32, 31);
            this.tile518.TabIndex = 559;
            this.tile518.TabStop = false;
            // 
            // tile520
            // 
            this.tile520.BackColor = System.Drawing.Color.White;
            this.tile520.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile520.Location = new System.Drawing.Point(1488, 463);
            this.tile520.Name = "tile520";
            this.tile520.Size = new System.Drawing.Size(32, 31);
            this.tile520.TabIndex = 558;
            this.tile520.TabStop = false;
            // 
            // tile519
            // 
            this.tile519.BackColor = System.Drawing.Color.White;
            this.tile519.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile519.Location = new System.Drawing.Point(1450, 463);
            this.tile519.Name = "tile519";
            this.tile519.Size = new System.Drawing.Size(32, 31);
            this.tile519.TabIndex = 557;
            this.tile519.TabStop = false;
            // 
            // tile512
            // 
            this.tile512.BackColor = System.Drawing.Color.White;
            this.tile512.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile512.Location = new System.Drawing.Point(1184, 463);
            this.tile512.Name = "tile512";
            this.tile512.Size = new System.Drawing.Size(32, 31);
            this.tile512.TabIndex = 556;
            this.tile512.TabStop = false;
            // 
            // tile511
            // 
            this.tile511.BackColor = System.Drawing.Color.White;
            this.tile511.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile511.Location = new System.Drawing.Point(1146, 463);
            this.tile511.Name = "tile511";
            this.tile511.Size = new System.Drawing.Size(32, 31);
            this.tile511.TabIndex = 555;
            this.tile511.TabStop = false;
            // 
            // tile508
            // 
            this.tile508.BackColor = System.Drawing.Color.White;
            this.tile508.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile508.Location = new System.Drawing.Point(1032, 463);
            this.tile508.Name = "tile508";
            this.tile508.Size = new System.Drawing.Size(32, 31);
            this.tile508.TabIndex = 554;
            this.tile508.TabStop = false;
            // 
            // tile507
            // 
            this.tile507.BackColor = System.Drawing.Color.White;
            this.tile507.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile507.Location = new System.Drawing.Point(994, 463);
            this.tile507.Name = "tile507";
            this.tile507.Size = new System.Drawing.Size(32, 31);
            this.tile507.TabIndex = 553;
            this.tile507.TabStop = false;
            // 
            // tile506
            // 
            this.tile506.BackColor = System.Drawing.Color.White;
            this.tile506.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile506.Location = new System.Drawing.Point(956, 463);
            this.tile506.Name = "tile506";
            this.tile506.Size = new System.Drawing.Size(32, 31);
            this.tile506.TabIndex = 552;
            this.tile506.TabStop = false;
            // 
            // tile505
            // 
            this.tile505.BackColor = System.Drawing.Color.White;
            this.tile505.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile505.Location = new System.Drawing.Point(918, 463);
            this.tile505.Name = "tile505";
            this.tile505.Size = new System.Drawing.Size(32, 31);
            this.tile505.TabIndex = 551;
            this.tile505.TabStop = false;
            // 
            // tile504
            // 
            this.tile504.BackColor = System.Drawing.Color.White;
            this.tile504.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile504.Location = new System.Drawing.Point(880, 463);
            this.tile504.Name = "tile504";
            this.tile504.Size = new System.Drawing.Size(32, 31);
            this.tile504.TabIndex = 550;
            this.tile504.TabStop = false;
            // 
            // tile503
            // 
            this.tile503.BackColor = System.Drawing.Color.White;
            this.tile503.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile503.Location = new System.Drawing.Point(842, 463);
            this.tile503.Name = "tile503";
            this.tile503.Size = new System.Drawing.Size(32, 31);
            this.tile503.TabIndex = 549;
            this.tile503.TabStop = false;
            // 
            // tile501
            // 
            this.tile501.BackColor = System.Drawing.Color.White;
            this.tile501.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile501.Location = new System.Drawing.Point(766, 463);
            this.tile501.Name = "tile501";
            this.tile501.Size = new System.Drawing.Size(32, 31);
            this.tile501.TabIndex = 548;
            this.tile501.TabStop = false;
            // 
            // tile502
            // 
            this.tile502.BackColor = System.Drawing.Color.White;
            this.tile502.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile502.Location = new System.Drawing.Point(804, 463);
            this.tile502.Name = "tile502";
            this.tile502.Size = new System.Drawing.Size(32, 31);
            this.tile502.TabIndex = 547;
            this.tile502.TabStop = false;
            // 
            // tile509
            // 
            this.tile509.BackColor = System.Drawing.Color.White;
            this.tile509.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile509.Location = new System.Drawing.Point(1070, 463);
            this.tile509.Name = "tile509";
            this.tile509.Size = new System.Drawing.Size(32, 31);
            this.tile509.TabIndex = 546;
            this.tile509.TabStop = false;
            // 
            // tile510
            // 
            this.tile510.BackColor = System.Drawing.Color.White;
            this.tile510.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile510.Location = new System.Drawing.Point(1108, 463);
            this.tile510.Name = "tile510";
            this.tile510.Size = new System.Drawing.Size(32, 31);
            this.tile510.TabIndex = 545;
            this.tile510.TabStop = false;
            // 
            // tile493
            // 
            this.tile493.BackColor = System.Drawing.Color.White;
            this.tile493.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile493.Location = new System.Drawing.Point(462, 463);
            this.tile493.Name = "tile493";
            this.tile493.Size = new System.Drawing.Size(32, 31);
            this.tile493.TabIndex = 544;
            this.tile493.TabStop = false;
            // 
            // tile494
            // 
            this.tile494.BackColor = System.Drawing.Color.White;
            this.tile494.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile494.Location = new System.Drawing.Point(500, 463);
            this.tile494.Name = "tile494";
            this.tile494.Size = new System.Drawing.Size(32, 31);
            this.tile494.TabIndex = 543;
            this.tile494.TabStop = false;
            // 
            // tile495
            // 
            this.tile495.BackColor = System.Drawing.Color.White;
            this.tile495.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile495.Location = new System.Drawing.Point(538, 463);
            this.tile495.Name = "tile495";
            this.tile495.Size = new System.Drawing.Size(32, 31);
            this.tile495.TabIndex = 542;
            this.tile495.TabStop = false;
            // 
            // tile496
            // 
            this.tile496.BackColor = System.Drawing.Color.White;
            this.tile496.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile496.Location = new System.Drawing.Point(576, 463);
            this.tile496.Name = "tile496";
            this.tile496.Size = new System.Drawing.Size(32, 31);
            this.tile496.TabIndex = 541;
            this.tile496.TabStop = false;
            // 
            // tile497
            // 
            this.tile497.BackColor = System.Drawing.Color.White;
            this.tile497.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile497.Location = new System.Drawing.Point(614, 463);
            this.tile497.Name = "tile497";
            this.tile497.Size = new System.Drawing.Size(32, 31);
            this.tile497.TabIndex = 540;
            this.tile497.TabStop = false;
            // 
            // tile498
            // 
            this.tile498.BackColor = System.Drawing.Color.White;
            this.tile498.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile498.Location = new System.Drawing.Point(652, 463);
            this.tile498.Name = "tile498";
            this.tile498.Size = new System.Drawing.Size(32, 31);
            this.tile498.TabIndex = 539;
            this.tile498.TabStop = false;
            // 
            // tile499
            // 
            this.tile499.BackColor = System.Drawing.Color.White;
            this.tile499.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile499.Location = new System.Drawing.Point(690, 463);
            this.tile499.Name = "tile499";
            this.tile499.Size = new System.Drawing.Size(32, 31);
            this.tile499.TabIndex = 538;
            this.tile499.TabStop = false;
            // 
            // tile500
            // 
            this.tile500.BackColor = System.Drawing.Color.White;
            this.tile500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile500.Location = new System.Drawing.Point(728, 463);
            this.tile500.Name = "tile500";
            this.tile500.Size = new System.Drawing.Size(32, 31);
            this.tile500.TabIndex = 537;
            this.tile500.TabStop = false;
            // 
            // tile492
            // 
            this.tile492.BackColor = System.Drawing.Color.White;
            this.tile492.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile492.Location = new System.Drawing.Point(424, 463);
            this.tile492.Name = "tile492";
            this.tile492.Size = new System.Drawing.Size(32, 31);
            this.tile492.TabIndex = 536;
            this.tile492.TabStop = false;
            // 
            // tile491
            // 
            this.tile491.BackColor = System.Drawing.Color.White;
            this.tile491.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile491.Location = new System.Drawing.Point(386, 463);
            this.tile491.Name = "tile491";
            this.tile491.Size = new System.Drawing.Size(32, 31);
            this.tile491.TabIndex = 535;
            this.tile491.TabStop = false;
            // 
            // tile483
            // 
            this.tile483.BackColor = System.Drawing.Color.White;
            this.tile483.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile483.Location = new System.Drawing.Point(82, 463);
            this.tile483.Name = "tile483";
            this.tile483.Size = new System.Drawing.Size(32, 31);
            this.tile483.TabIndex = 534;
            this.tile483.TabStop = false;
            // 
            // tile484
            // 
            this.tile484.BackColor = System.Drawing.Color.White;
            this.tile484.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile484.Location = new System.Drawing.Point(120, 463);
            this.tile484.Name = "tile484";
            this.tile484.Size = new System.Drawing.Size(32, 31);
            this.tile484.TabIndex = 533;
            this.tile484.TabStop = false;
            // 
            // tile485
            // 
            this.tile485.BackColor = System.Drawing.Color.White;
            this.tile485.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile485.Location = new System.Drawing.Point(158, 463);
            this.tile485.Name = "tile485";
            this.tile485.Size = new System.Drawing.Size(32, 31);
            this.tile485.TabIndex = 532;
            this.tile485.TabStop = false;
            // 
            // tile486
            // 
            this.tile486.BackColor = System.Drawing.Color.White;
            this.tile486.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile486.Location = new System.Drawing.Point(196, 463);
            this.tile486.Name = "tile486";
            this.tile486.Size = new System.Drawing.Size(32, 31);
            this.tile486.TabIndex = 531;
            this.tile486.TabStop = false;
            // 
            // tile487
            // 
            this.tile487.BackColor = System.Drawing.Color.White;
            this.tile487.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile487.Location = new System.Drawing.Point(234, 463);
            this.tile487.Name = "tile487";
            this.tile487.Size = new System.Drawing.Size(32, 31);
            this.tile487.TabIndex = 530;
            this.tile487.TabStop = false;
            // 
            // tile488
            // 
            this.tile488.BackColor = System.Drawing.Color.White;
            this.tile488.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile488.Location = new System.Drawing.Point(272, 463);
            this.tile488.Name = "tile488";
            this.tile488.Size = new System.Drawing.Size(32, 31);
            this.tile488.TabIndex = 529;
            this.tile488.TabStop = false;
            // 
            // tile489
            // 
            this.tile489.BackColor = System.Drawing.Color.White;
            this.tile489.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile489.Location = new System.Drawing.Point(310, 463);
            this.tile489.Name = "tile489";
            this.tile489.Size = new System.Drawing.Size(32, 31);
            this.tile489.TabIndex = 528;
            this.tile489.TabStop = false;
            // 
            // tile490
            // 
            this.tile490.BackColor = System.Drawing.Color.White;
            this.tile490.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile490.Location = new System.Drawing.Point(348, 463);
            this.tile490.Name = "tile490";
            this.tile490.Size = new System.Drawing.Size(32, 31);
            this.tile490.TabIndex = 527;
            this.tile490.TabStop = false;
            // 
            // tile482
            // 
            this.tile482.BackColor = System.Drawing.Color.White;
            this.tile482.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile482.Location = new System.Drawing.Point(44, 463);
            this.tile482.Name = "tile482";
            this.tile482.Size = new System.Drawing.Size(32, 31);
            this.tile482.TabIndex = 526;
            this.tile482.TabStop = false;
            // 
            // tile481
            // 
            this.tile481.BackColor = System.Drawing.Color.White;
            this.tile481.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile481.Location = new System.Drawing.Point(6, 463);
            this.tile481.Name = "tile481";
            this.tile481.Size = new System.Drawing.Size(32, 31);
            this.tile481.TabIndex = 525;
            this.tile481.TabStop = false;
            // 
            // tile473
            // 
            this.tile473.BackColor = System.Drawing.Color.White;
            this.tile473.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile473.Location = new System.Drawing.Point(1222, 426);
            this.tile473.Name = "tile473";
            this.tile473.Size = new System.Drawing.Size(32, 31);
            this.tile473.TabIndex = 524;
            this.tile473.TabStop = false;
            // 
            // tile474
            // 
            this.tile474.BackColor = System.Drawing.Color.White;
            this.tile474.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile474.Location = new System.Drawing.Point(1260, 426);
            this.tile474.Name = "tile474";
            this.tile474.Size = new System.Drawing.Size(32, 31);
            this.tile474.TabIndex = 523;
            this.tile474.TabStop = false;
            // 
            // tile475
            // 
            this.tile475.BackColor = System.Drawing.Color.White;
            this.tile475.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile475.Location = new System.Drawing.Point(1298, 426);
            this.tile475.Name = "tile475";
            this.tile475.Size = new System.Drawing.Size(32, 31);
            this.tile475.TabIndex = 522;
            this.tile475.TabStop = false;
            // 
            // tile476
            // 
            this.tile476.BackColor = System.Drawing.Color.White;
            this.tile476.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile476.Location = new System.Drawing.Point(1336, 426);
            this.tile476.Name = "tile476";
            this.tile476.Size = new System.Drawing.Size(32, 31);
            this.tile476.TabIndex = 521;
            this.tile476.TabStop = false;
            // 
            // tile477
            // 
            this.tile477.BackColor = System.Drawing.Color.White;
            this.tile477.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile477.Location = new System.Drawing.Point(1374, 426);
            this.tile477.Name = "tile477";
            this.tile477.Size = new System.Drawing.Size(32, 31);
            this.tile477.TabIndex = 520;
            this.tile477.TabStop = false;
            // 
            // tile478
            // 
            this.tile478.BackColor = System.Drawing.Color.White;
            this.tile478.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile478.Location = new System.Drawing.Point(1412, 426);
            this.tile478.Name = "tile478";
            this.tile478.Size = new System.Drawing.Size(32, 31);
            this.tile478.TabIndex = 519;
            this.tile478.TabStop = false;
            // 
            // tile480
            // 
            this.tile480.BackColor = System.Drawing.Color.White;
            this.tile480.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile480.Location = new System.Drawing.Point(1488, 426);
            this.tile480.Name = "tile480";
            this.tile480.Size = new System.Drawing.Size(32, 31);
            this.tile480.TabIndex = 518;
            this.tile480.TabStop = false;
            // 
            // tile479
            // 
            this.tile479.BackColor = System.Drawing.Color.White;
            this.tile479.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile479.Location = new System.Drawing.Point(1450, 426);
            this.tile479.Name = "tile479";
            this.tile479.Size = new System.Drawing.Size(32, 31);
            this.tile479.TabIndex = 517;
            this.tile479.TabStop = false;
            // 
            // tile472
            // 
            this.tile472.BackColor = System.Drawing.Color.White;
            this.tile472.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile472.Location = new System.Drawing.Point(1184, 426);
            this.tile472.Name = "tile472";
            this.tile472.Size = new System.Drawing.Size(32, 31);
            this.tile472.TabIndex = 516;
            this.tile472.TabStop = false;
            // 
            // tile471
            // 
            this.tile471.BackColor = System.Drawing.Color.White;
            this.tile471.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile471.Location = new System.Drawing.Point(1146, 426);
            this.tile471.Name = "tile471";
            this.tile471.Size = new System.Drawing.Size(32, 31);
            this.tile471.TabIndex = 515;
            this.tile471.TabStop = false;
            // 
            // tile468
            // 
            this.tile468.BackColor = System.Drawing.Color.White;
            this.tile468.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile468.Location = new System.Drawing.Point(1032, 426);
            this.tile468.Name = "tile468";
            this.tile468.Size = new System.Drawing.Size(32, 31);
            this.tile468.TabIndex = 514;
            this.tile468.TabStop = false;
            // 
            // tile467
            // 
            this.tile467.BackColor = System.Drawing.Color.White;
            this.tile467.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile467.Location = new System.Drawing.Point(994, 426);
            this.tile467.Name = "tile467";
            this.tile467.Size = new System.Drawing.Size(32, 31);
            this.tile467.TabIndex = 513;
            this.tile467.TabStop = false;
            // 
            // tile466
            // 
            this.tile466.BackColor = System.Drawing.Color.White;
            this.tile466.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile466.Location = new System.Drawing.Point(956, 426);
            this.tile466.Name = "tile466";
            this.tile466.Size = new System.Drawing.Size(32, 31);
            this.tile466.TabIndex = 512;
            this.tile466.TabStop = false;
            // 
            // tile465
            // 
            this.tile465.BackColor = System.Drawing.Color.White;
            this.tile465.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile465.Location = new System.Drawing.Point(918, 426);
            this.tile465.Name = "tile465";
            this.tile465.Size = new System.Drawing.Size(32, 31);
            this.tile465.TabIndex = 511;
            this.tile465.TabStop = false;
            // 
            // tile464
            // 
            this.tile464.BackColor = System.Drawing.Color.White;
            this.tile464.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile464.Location = new System.Drawing.Point(880, 426);
            this.tile464.Name = "tile464";
            this.tile464.Size = new System.Drawing.Size(32, 31);
            this.tile464.TabIndex = 510;
            this.tile464.TabStop = false;
            // 
            // tile463
            // 
            this.tile463.BackColor = System.Drawing.Color.White;
            this.tile463.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile463.Location = new System.Drawing.Point(842, 426);
            this.tile463.Name = "tile463";
            this.tile463.Size = new System.Drawing.Size(32, 31);
            this.tile463.TabIndex = 509;
            this.tile463.TabStop = false;
            // 
            // tile461
            // 
            this.tile461.BackColor = System.Drawing.Color.White;
            this.tile461.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile461.Location = new System.Drawing.Point(766, 426);
            this.tile461.Name = "tile461";
            this.tile461.Size = new System.Drawing.Size(32, 31);
            this.tile461.TabIndex = 508;
            this.tile461.TabStop = false;
            // 
            // tile462
            // 
            this.tile462.BackColor = System.Drawing.Color.White;
            this.tile462.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile462.Location = new System.Drawing.Point(804, 426);
            this.tile462.Name = "tile462";
            this.tile462.Size = new System.Drawing.Size(32, 31);
            this.tile462.TabIndex = 507;
            this.tile462.TabStop = false;
            // 
            // tile469
            // 
            this.tile469.BackColor = System.Drawing.Color.White;
            this.tile469.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile469.Location = new System.Drawing.Point(1070, 426);
            this.tile469.Name = "tile469";
            this.tile469.Size = new System.Drawing.Size(32, 31);
            this.tile469.TabIndex = 506;
            this.tile469.TabStop = false;
            // 
            // tile470
            // 
            this.tile470.BackColor = System.Drawing.Color.White;
            this.tile470.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile470.Location = new System.Drawing.Point(1108, 426);
            this.tile470.Name = "tile470";
            this.tile470.Size = new System.Drawing.Size(32, 31);
            this.tile470.TabIndex = 505;
            this.tile470.TabStop = false;
            // 
            // tile453
            // 
            this.tile453.BackColor = System.Drawing.Color.White;
            this.tile453.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile453.Location = new System.Drawing.Point(462, 426);
            this.tile453.Name = "tile453";
            this.tile453.Size = new System.Drawing.Size(32, 31);
            this.tile453.TabIndex = 504;
            this.tile453.TabStop = false;
            // 
            // tile454
            // 
            this.tile454.BackColor = System.Drawing.Color.White;
            this.tile454.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile454.Location = new System.Drawing.Point(500, 426);
            this.tile454.Name = "tile454";
            this.tile454.Size = new System.Drawing.Size(32, 31);
            this.tile454.TabIndex = 503;
            this.tile454.TabStop = false;
            // 
            // tile455
            // 
            this.tile455.BackColor = System.Drawing.Color.White;
            this.tile455.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile455.Location = new System.Drawing.Point(538, 426);
            this.tile455.Name = "tile455";
            this.tile455.Size = new System.Drawing.Size(32, 31);
            this.tile455.TabIndex = 502;
            this.tile455.TabStop = false;
            // 
            // tile456
            // 
            this.tile456.BackColor = System.Drawing.Color.White;
            this.tile456.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile456.Location = new System.Drawing.Point(576, 426);
            this.tile456.Name = "tile456";
            this.tile456.Size = new System.Drawing.Size(32, 31);
            this.tile456.TabIndex = 501;
            this.tile456.TabStop = false;
            // 
            // tile457
            // 
            this.tile457.BackColor = System.Drawing.Color.White;
            this.tile457.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile457.Location = new System.Drawing.Point(614, 426);
            this.tile457.Name = "tile457";
            this.tile457.Size = new System.Drawing.Size(32, 31);
            this.tile457.TabIndex = 500;
            this.tile457.TabStop = false;
            // 
            // tile458
            // 
            this.tile458.BackColor = System.Drawing.Color.White;
            this.tile458.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile458.Location = new System.Drawing.Point(652, 426);
            this.tile458.Name = "tile458";
            this.tile458.Size = new System.Drawing.Size(32, 31);
            this.tile458.TabIndex = 499;
            this.tile458.TabStop = false;
            // 
            // tile459
            // 
            this.tile459.BackColor = System.Drawing.Color.White;
            this.tile459.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile459.Location = new System.Drawing.Point(690, 426);
            this.tile459.Name = "tile459";
            this.tile459.Size = new System.Drawing.Size(32, 31);
            this.tile459.TabIndex = 498;
            this.tile459.TabStop = false;
            // 
            // tile460
            // 
            this.tile460.BackColor = System.Drawing.Color.White;
            this.tile460.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile460.Location = new System.Drawing.Point(728, 426);
            this.tile460.Name = "tile460";
            this.tile460.Size = new System.Drawing.Size(32, 31);
            this.tile460.TabIndex = 497;
            this.tile460.TabStop = false;
            // 
            // tile452
            // 
            this.tile452.BackColor = System.Drawing.Color.White;
            this.tile452.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile452.Location = new System.Drawing.Point(424, 426);
            this.tile452.Name = "tile452";
            this.tile452.Size = new System.Drawing.Size(32, 31);
            this.tile452.TabIndex = 496;
            this.tile452.TabStop = false;
            // 
            // tile451
            // 
            this.tile451.BackColor = System.Drawing.Color.White;
            this.tile451.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile451.Location = new System.Drawing.Point(386, 426);
            this.tile451.Name = "tile451";
            this.tile451.Size = new System.Drawing.Size(32, 31);
            this.tile451.TabIndex = 495;
            this.tile451.TabStop = false;
            // 
            // tile443
            // 
            this.tile443.BackColor = System.Drawing.Color.White;
            this.tile443.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile443.Location = new System.Drawing.Point(82, 426);
            this.tile443.Name = "tile443";
            this.tile443.Size = new System.Drawing.Size(32, 31);
            this.tile443.TabIndex = 494;
            this.tile443.TabStop = false;
            // 
            // tile444
            // 
            this.tile444.BackColor = System.Drawing.Color.White;
            this.tile444.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile444.Location = new System.Drawing.Point(120, 426);
            this.tile444.Name = "tile444";
            this.tile444.Size = new System.Drawing.Size(32, 31);
            this.tile444.TabIndex = 493;
            this.tile444.TabStop = false;
            // 
            // tile445
            // 
            this.tile445.BackColor = System.Drawing.Color.White;
            this.tile445.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile445.Location = new System.Drawing.Point(158, 426);
            this.tile445.Name = "tile445";
            this.tile445.Size = new System.Drawing.Size(32, 31);
            this.tile445.TabIndex = 492;
            this.tile445.TabStop = false;
            // 
            // tile446
            // 
            this.tile446.BackColor = System.Drawing.Color.White;
            this.tile446.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile446.Location = new System.Drawing.Point(196, 426);
            this.tile446.Name = "tile446";
            this.tile446.Size = new System.Drawing.Size(32, 31);
            this.tile446.TabIndex = 491;
            this.tile446.TabStop = false;
            // 
            // tile447
            // 
            this.tile447.BackColor = System.Drawing.Color.White;
            this.tile447.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile447.Location = new System.Drawing.Point(234, 426);
            this.tile447.Name = "tile447";
            this.tile447.Size = new System.Drawing.Size(32, 31);
            this.tile447.TabIndex = 490;
            this.tile447.TabStop = false;
            // 
            // tile448
            // 
            this.tile448.BackColor = System.Drawing.Color.White;
            this.tile448.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile448.Location = new System.Drawing.Point(272, 426);
            this.tile448.Name = "tile448";
            this.tile448.Size = new System.Drawing.Size(32, 31);
            this.tile448.TabIndex = 489;
            this.tile448.TabStop = false;
            // 
            // tile449
            // 
            this.tile449.BackColor = System.Drawing.Color.White;
            this.tile449.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile449.Location = new System.Drawing.Point(310, 426);
            this.tile449.Name = "tile449";
            this.tile449.Size = new System.Drawing.Size(32, 31);
            this.tile449.TabIndex = 488;
            this.tile449.TabStop = false;
            // 
            // tile450
            // 
            this.tile450.BackColor = System.Drawing.Color.White;
            this.tile450.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile450.Location = new System.Drawing.Point(348, 426);
            this.tile450.Name = "tile450";
            this.tile450.Size = new System.Drawing.Size(32, 31);
            this.tile450.TabIndex = 487;
            this.tile450.TabStop = false;
            // 
            // tile442
            // 
            this.tile442.BackColor = System.Drawing.Color.White;
            this.tile442.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile442.Location = new System.Drawing.Point(44, 426);
            this.tile442.Name = "tile442";
            this.tile442.Size = new System.Drawing.Size(32, 31);
            this.tile442.TabIndex = 486;
            this.tile442.TabStop = false;
            // 
            // tile441
            // 
            this.tile441.BackColor = System.Drawing.Color.White;
            this.tile441.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile441.Location = new System.Drawing.Point(6, 426);
            this.tile441.Name = "tile441";
            this.tile441.Size = new System.Drawing.Size(32, 31);
            this.tile441.TabIndex = 485;
            this.tile441.TabStop = false;
            // 
            // tile433
            // 
            this.tile433.BackColor = System.Drawing.Color.White;
            this.tile433.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile433.Location = new System.Drawing.Point(1222, 389);
            this.tile433.Name = "tile433";
            this.tile433.Size = new System.Drawing.Size(32, 31);
            this.tile433.TabIndex = 484;
            this.tile433.TabStop = false;
            // 
            // tile434
            // 
            this.tile434.BackColor = System.Drawing.Color.White;
            this.tile434.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile434.Location = new System.Drawing.Point(1260, 389);
            this.tile434.Name = "tile434";
            this.tile434.Size = new System.Drawing.Size(32, 31);
            this.tile434.TabIndex = 483;
            this.tile434.TabStop = false;
            // 
            // tile435
            // 
            this.tile435.BackColor = System.Drawing.Color.White;
            this.tile435.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile435.Location = new System.Drawing.Point(1298, 389);
            this.tile435.Name = "tile435";
            this.tile435.Size = new System.Drawing.Size(32, 31);
            this.tile435.TabIndex = 482;
            this.tile435.TabStop = false;
            // 
            // tile436
            // 
            this.tile436.BackColor = System.Drawing.Color.White;
            this.tile436.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile436.Location = new System.Drawing.Point(1336, 389);
            this.tile436.Name = "tile436";
            this.tile436.Size = new System.Drawing.Size(32, 31);
            this.tile436.TabIndex = 481;
            this.tile436.TabStop = false;
            // 
            // tile437
            // 
            this.tile437.BackColor = System.Drawing.Color.White;
            this.tile437.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile437.Location = new System.Drawing.Point(1374, 389);
            this.tile437.Name = "tile437";
            this.tile437.Size = new System.Drawing.Size(32, 31);
            this.tile437.TabIndex = 480;
            this.tile437.TabStop = false;
            // 
            // tile438
            // 
            this.tile438.BackColor = System.Drawing.Color.White;
            this.tile438.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile438.Location = new System.Drawing.Point(1412, 389);
            this.tile438.Name = "tile438";
            this.tile438.Size = new System.Drawing.Size(32, 31);
            this.tile438.TabIndex = 479;
            this.tile438.TabStop = false;
            // 
            // tile440
            // 
            this.tile440.BackColor = System.Drawing.Color.White;
            this.tile440.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile440.Location = new System.Drawing.Point(1488, 389);
            this.tile440.Name = "tile440";
            this.tile440.Size = new System.Drawing.Size(32, 31);
            this.tile440.TabIndex = 478;
            this.tile440.TabStop = false;
            // 
            // tile439
            // 
            this.tile439.BackColor = System.Drawing.Color.White;
            this.tile439.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile439.Location = new System.Drawing.Point(1450, 389);
            this.tile439.Name = "tile439";
            this.tile439.Size = new System.Drawing.Size(32, 31);
            this.tile439.TabIndex = 477;
            this.tile439.TabStop = false;
            // 
            // tile432
            // 
            this.tile432.BackColor = System.Drawing.Color.White;
            this.tile432.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile432.Location = new System.Drawing.Point(1184, 389);
            this.tile432.Name = "tile432";
            this.tile432.Size = new System.Drawing.Size(32, 31);
            this.tile432.TabIndex = 476;
            this.tile432.TabStop = false;
            // 
            // tile431
            // 
            this.tile431.BackColor = System.Drawing.Color.White;
            this.tile431.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile431.Location = new System.Drawing.Point(1146, 389);
            this.tile431.Name = "tile431";
            this.tile431.Size = new System.Drawing.Size(32, 31);
            this.tile431.TabIndex = 475;
            this.tile431.TabStop = false;
            // 
            // tile428
            // 
            this.tile428.BackColor = System.Drawing.Color.White;
            this.tile428.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile428.Location = new System.Drawing.Point(1032, 389);
            this.tile428.Name = "tile428";
            this.tile428.Size = new System.Drawing.Size(32, 31);
            this.tile428.TabIndex = 474;
            this.tile428.TabStop = false;
            // 
            // tile427
            // 
            this.tile427.BackColor = System.Drawing.Color.White;
            this.tile427.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile427.Location = new System.Drawing.Point(994, 389);
            this.tile427.Name = "tile427";
            this.tile427.Size = new System.Drawing.Size(32, 31);
            this.tile427.TabIndex = 473;
            this.tile427.TabStop = false;
            // 
            // tile426
            // 
            this.tile426.BackColor = System.Drawing.Color.White;
            this.tile426.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile426.Location = new System.Drawing.Point(956, 389);
            this.tile426.Name = "tile426";
            this.tile426.Size = new System.Drawing.Size(32, 31);
            this.tile426.TabIndex = 472;
            this.tile426.TabStop = false;
            // 
            // tile425
            // 
            this.tile425.BackColor = System.Drawing.Color.White;
            this.tile425.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile425.Location = new System.Drawing.Point(918, 389);
            this.tile425.Name = "tile425";
            this.tile425.Size = new System.Drawing.Size(32, 31);
            this.tile425.TabIndex = 471;
            this.tile425.TabStop = false;
            // 
            // tile424
            // 
            this.tile424.BackColor = System.Drawing.Color.White;
            this.tile424.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile424.Location = new System.Drawing.Point(880, 389);
            this.tile424.Name = "tile424";
            this.tile424.Size = new System.Drawing.Size(32, 31);
            this.tile424.TabIndex = 470;
            this.tile424.TabStop = false;
            // 
            // tile423
            // 
            this.tile423.BackColor = System.Drawing.Color.White;
            this.tile423.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile423.Location = new System.Drawing.Point(842, 389);
            this.tile423.Name = "tile423";
            this.tile423.Size = new System.Drawing.Size(32, 31);
            this.tile423.TabIndex = 469;
            this.tile423.TabStop = false;
            // 
            // tile421
            // 
            this.tile421.BackColor = System.Drawing.Color.White;
            this.tile421.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile421.Location = new System.Drawing.Point(766, 389);
            this.tile421.Name = "tile421";
            this.tile421.Size = new System.Drawing.Size(32, 31);
            this.tile421.TabIndex = 468;
            this.tile421.TabStop = false;
            // 
            // tile422
            // 
            this.tile422.BackColor = System.Drawing.Color.White;
            this.tile422.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile422.Location = new System.Drawing.Point(804, 389);
            this.tile422.Name = "tile422";
            this.tile422.Size = new System.Drawing.Size(32, 31);
            this.tile422.TabIndex = 467;
            this.tile422.TabStop = false;
            // 
            // tile429
            // 
            this.tile429.BackColor = System.Drawing.Color.White;
            this.tile429.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile429.Location = new System.Drawing.Point(1070, 389);
            this.tile429.Name = "tile429";
            this.tile429.Size = new System.Drawing.Size(32, 31);
            this.tile429.TabIndex = 466;
            this.tile429.TabStop = false;
            // 
            // tile430
            // 
            this.tile430.BackColor = System.Drawing.Color.White;
            this.tile430.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile430.Location = new System.Drawing.Point(1108, 389);
            this.tile430.Name = "tile430";
            this.tile430.Size = new System.Drawing.Size(32, 31);
            this.tile430.TabIndex = 465;
            this.tile430.TabStop = false;
            // 
            // tile413
            // 
            this.tile413.BackColor = System.Drawing.Color.White;
            this.tile413.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile413.Location = new System.Drawing.Point(462, 389);
            this.tile413.Name = "tile413";
            this.tile413.Size = new System.Drawing.Size(32, 31);
            this.tile413.TabIndex = 464;
            this.tile413.TabStop = false;
            // 
            // tile414
            // 
            this.tile414.BackColor = System.Drawing.Color.White;
            this.tile414.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile414.Location = new System.Drawing.Point(500, 389);
            this.tile414.Name = "tile414";
            this.tile414.Size = new System.Drawing.Size(32, 31);
            this.tile414.TabIndex = 463;
            this.tile414.TabStop = false;
            // 
            // tile415
            // 
            this.tile415.BackColor = System.Drawing.Color.White;
            this.tile415.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile415.Location = new System.Drawing.Point(538, 389);
            this.tile415.Name = "tile415";
            this.tile415.Size = new System.Drawing.Size(32, 31);
            this.tile415.TabIndex = 462;
            this.tile415.TabStop = false;
            // 
            // tile416
            // 
            this.tile416.BackColor = System.Drawing.Color.White;
            this.tile416.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile416.Location = new System.Drawing.Point(576, 389);
            this.tile416.Name = "tile416";
            this.tile416.Size = new System.Drawing.Size(32, 31);
            this.tile416.TabIndex = 461;
            this.tile416.TabStop = false;
            // 
            // tile417
            // 
            this.tile417.BackColor = System.Drawing.Color.White;
            this.tile417.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile417.Location = new System.Drawing.Point(614, 389);
            this.tile417.Name = "tile417";
            this.tile417.Size = new System.Drawing.Size(32, 31);
            this.tile417.TabIndex = 460;
            this.tile417.TabStop = false;
            // 
            // tile418
            // 
            this.tile418.BackColor = System.Drawing.Color.White;
            this.tile418.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile418.Location = new System.Drawing.Point(652, 389);
            this.tile418.Name = "tile418";
            this.tile418.Size = new System.Drawing.Size(32, 31);
            this.tile418.TabIndex = 459;
            this.tile418.TabStop = false;
            // 
            // tile419
            // 
            this.tile419.BackColor = System.Drawing.Color.White;
            this.tile419.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile419.Location = new System.Drawing.Point(690, 389);
            this.tile419.Name = "tile419";
            this.tile419.Size = new System.Drawing.Size(32, 31);
            this.tile419.TabIndex = 458;
            this.tile419.TabStop = false;
            // 
            // tile420
            // 
            this.tile420.BackColor = System.Drawing.Color.White;
            this.tile420.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile420.Location = new System.Drawing.Point(728, 389);
            this.tile420.Name = "tile420";
            this.tile420.Size = new System.Drawing.Size(32, 31);
            this.tile420.TabIndex = 457;
            this.tile420.TabStop = false;
            // 
            // tile412
            // 
            this.tile412.BackColor = System.Drawing.Color.White;
            this.tile412.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile412.Location = new System.Drawing.Point(424, 389);
            this.tile412.Name = "tile412";
            this.tile412.Size = new System.Drawing.Size(32, 31);
            this.tile412.TabIndex = 456;
            this.tile412.TabStop = false;
            // 
            // tile411
            // 
            this.tile411.BackColor = System.Drawing.Color.White;
            this.tile411.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile411.Location = new System.Drawing.Point(386, 389);
            this.tile411.Name = "tile411";
            this.tile411.Size = new System.Drawing.Size(32, 31);
            this.tile411.TabIndex = 455;
            this.tile411.TabStop = false;
            // 
            // tile403
            // 
            this.tile403.BackColor = System.Drawing.Color.White;
            this.tile403.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile403.Location = new System.Drawing.Point(82, 389);
            this.tile403.Name = "tile403";
            this.tile403.Size = new System.Drawing.Size(32, 31);
            this.tile403.TabIndex = 454;
            this.tile403.TabStop = false;
            // 
            // tile404
            // 
            this.tile404.BackColor = System.Drawing.Color.White;
            this.tile404.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile404.Location = new System.Drawing.Point(120, 389);
            this.tile404.Name = "tile404";
            this.tile404.Size = new System.Drawing.Size(32, 31);
            this.tile404.TabIndex = 453;
            this.tile404.TabStop = false;
            // 
            // tile405
            // 
            this.tile405.BackColor = System.Drawing.Color.White;
            this.tile405.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile405.Location = new System.Drawing.Point(158, 389);
            this.tile405.Name = "tile405";
            this.tile405.Size = new System.Drawing.Size(32, 31);
            this.tile405.TabIndex = 452;
            this.tile405.TabStop = false;
            // 
            // tile406
            // 
            this.tile406.BackColor = System.Drawing.Color.White;
            this.tile406.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile406.Location = new System.Drawing.Point(196, 389);
            this.tile406.Name = "tile406";
            this.tile406.Size = new System.Drawing.Size(32, 31);
            this.tile406.TabIndex = 451;
            this.tile406.TabStop = false;
            // 
            // tile407
            // 
            this.tile407.BackColor = System.Drawing.Color.White;
            this.tile407.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile407.Location = new System.Drawing.Point(234, 389);
            this.tile407.Name = "tile407";
            this.tile407.Size = new System.Drawing.Size(32, 31);
            this.tile407.TabIndex = 450;
            this.tile407.TabStop = false;
            // 
            // tile408
            // 
            this.tile408.BackColor = System.Drawing.Color.White;
            this.tile408.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile408.Location = new System.Drawing.Point(272, 389);
            this.tile408.Name = "tile408";
            this.tile408.Size = new System.Drawing.Size(32, 31);
            this.tile408.TabIndex = 449;
            this.tile408.TabStop = false;
            // 
            // tile409
            // 
            this.tile409.BackColor = System.Drawing.Color.White;
            this.tile409.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile409.Location = new System.Drawing.Point(310, 389);
            this.tile409.Name = "tile409";
            this.tile409.Size = new System.Drawing.Size(32, 31);
            this.tile409.TabIndex = 448;
            this.tile409.TabStop = false;
            // 
            // tile410
            // 
            this.tile410.BackColor = System.Drawing.Color.White;
            this.tile410.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile410.Location = new System.Drawing.Point(348, 389);
            this.tile410.Name = "tile410";
            this.tile410.Size = new System.Drawing.Size(32, 31);
            this.tile410.TabIndex = 447;
            this.tile410.TabStop = false;
            // 
            // tile402
            // 
            this.tile402.BackColor = System.Drawing.Color.White;
            this.tile402.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile402.Location = new System.Drawing.Point(44, 389);
            this.tile402.Name = "tile402";
            this.tile402.Size = new System.Drawing.Size(32, 31);
            this.tile402.TabIndex = 446;
            this.tile402.TabStop = false;
            // 
            // tile401
            // 
            this.tile401.BackColor = System.Drawing.Color.White;
            this.tile401.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile401.Location = new System.Drawing.Point(6, 389);
            this.tile401.Name = "tile401";
            this.tile401.Size = new System.Drawing.Size(32, 31);
            this.tile401.TabIndex = 445;
            this.tile401.TabStop = false;
            // 
            // tile393
            // 
            this.tile393.BackColor = System.Drawing.Color.White;
            this.tile393.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile393.Location = new System.Drawing.Point(1222, 352);
            this.tile393.Name = "tile393";
            this.tile393.Size = new System.Drawing.Size(32, 31);
            this.tile393.TabIndex = 444;
            this.tile393.TabStop = false;
            // 
            // tile394
            // 
            this.tile394.BackColor = System.Drawing.Color.White;
            this.tile394.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile394.Location = new System.Drawing.Point(1260, 352);
            this.tile394.Name = "tile394";
            this.tile394.Size = new System.Drawing.Size(32, 31);
            this.tile394.TabIndex = 443;
            this.tile394.TabStop = false;
            // 
            // tile395
            // 
            this.tile395.BackColor = System.Drawing.Color.White;
            this.tile395.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile395.Location = new System.Drawing.Point(1298, 352);
            this.tile395.Name = "tile395";
            this.tile395.Size = new System.Drawing.Size(32, 31);
            this.tile395.TabIndex = 442;
            this.tile395.TabStop = false;
            // 
            // tile396
            // 
            this.tile396.BackColor = System.Drawing.Color.White;
            this.tile396.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile396.Location = new System.Drawing.Point(1336, 352);
            this.tile396.Name = "tile396";
            this.tile396.Size = new System.Drawing.Size(32, 31);
            this.tile396.TabIndex = 441;
            this.tile396.TabStop = false;
            // 
            // tile397
            // 
            this.tile397.BackColor = System.Drawing.Color.White;
            this.tile397.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile397.Location = new System.Drawing.Point(1374, 352);
            this.tile397.Name = "tile397";
            this.tile397.Size = new System.Drawing.Size(32, 31);
            this.tile397.TabIndex = 440;
            this.tile397.TabStop = false;
            // 
            // tile398
            // 
            this.tile398.BackColor = System.Drawing.Color.White;
            this.tile398.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile398.Location = new System.Drawing.Point(1412, 352);
            this.tile398.Name = "tile398";
            this.tile398.Size = new System.Drawing.Size(32, 31);
            this.tile398.TabIndex = 439;
            this.tile398.TabStop = false;
            // 
            // tile400
            // 
            this.tile400.BackColor = System.Drawing.Color.White;
            this.tile400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile400.Location = new System.Drawing.Point(1488, 352);
            this.tile400.Name = "tile400";
            this.tile400.Size = new System.Drawing.Size(32, 31);
            this.tile400.TabIndex = 438;
            this.tile400.TabStop = false;
            // 
            // tile399
            // 
            this.tile399.BackColor = System.Drawing.Color.White;
            this.tile399.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile399.Location = new System.Drawing.Point(1450, 352);
            this.tile399.Name = "tile399";
            this.tile399.Size = new System.Drawing.Size(32, 31);
            this.tile399.TabIndex = 437;
            this.tile399.TabStop = false;
            // 
            // tile392
            // 
            this.tile392.BackColor = System.Drawing.Color.White;
            this.tile392.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile392.Location = new System.Drawing.Point(1184, 352);
            this.tile392.Name = "tile392";
            this.tile392.Size = new System.Drawing.Size(32, 31);
            this.tile392.TabIndex = 436;
            this.tile392.TabStop = false;
            // 
            // tile391
            // 
            this.tile391.BackColor = System.Drawing.Color.White;
            this.tile391.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile391.Location = new System.Drawing.Point(1146, 352);
            this.tile391.Name = "tile391";
            this.tile391.Size = new System.Drawing.Size(32, 31);
            this.tile391.TabIndex = 435;
            this.tile391.TabStop = false;
            // 
            // tile388
            // 
            this.tile388.BackColor = System.Drawing.Color.White;
            this.tile388.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile388.Location = new System.Drawing.Point(1032, 352);
            this.tile388.Name = "tile388";
            this.tile388.Size = new System.Drawing.Size(32, 31);
            this.tile388.TabIndex = 434;
            this.tile388.TabStop = false;
            // 
            // tile387
            // 
            this.tile387.BackColor = System.Drawing.Color.White;
            this.tile387.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile387.Location = new System.Drawing.Point(994, 352);
            this.tile387.Name = "tile387";
            this.tile387.Size = new System.Drawing.Size(32, 31);
            this.tile387.TabIndex = 433;
            this.tile387.TabStop = false;
            // 
            // tile386
            // 
            this.tile386.BackColor = System.Drawing.Color.White;
            this.tile386.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile386.Location = new System.Drawing.Point(956, 352);
            this.tile386.Name = "tile386";
            this.tile386.Size = new System.Drawing.Size(32, 31);
            this.tile386.TabIndex = 432;
            this.tile386.TabStop = false;
            // 
            // tile385
            // 
            this.tile385.BackColor = System.Drawing.Color.White;
            this.tile385.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile385.Location = new System.Drawing.Point(918, 352);
            this.tile385.Name = "tile385";
            this.tile385.Size = new System.Drawing.Size(32, 31);
            this.tile385.TabIndex = 431;
            this.tile385.TabStop = false;
            // 
            // tile384
            // 
            this.tile384.BackColor = System.Drawing.Color.White;
            this.tile384.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile384.Location = new System.Drawing.Point(880, 352);
            this.tile384.Name = "tile384";
            this.tile384.Size = new System.Drawing.Size(32, 31);
            this.tile384.TabIndex = 430;
            this.tile384.TabStop = false;
            // 
            // tile383
            // 
            this.tile383.BackColor = System.Drawing.Color.White;
            this.tile383.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile383.Location = new System.Drawing.Point(842, 352);
            this.tile383.Name = "tile383";
            this.tile383.Size = new System.Drawing.Size(32, 31);
            this.tile383.TabIndex = 429;
            this.tile383.TabStop = false;
            // 
            // tile381
            // 
            this.tile381.BackColor = System.Drawing.Color.White;
            this.tile381.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile381.Location = new System.Drawing.Point(766, 352);
            this.tile381.Name = "tile381";
            this.tile381.Size = new System.Drawing.Size(32, 31);
            this.tile381.TabIndex = 428;
            this.tile381.TabStop = false;
            // 
            // tile382
            // 
            this.tile382.BackColor = System.Drawing.Color.White;
            this.tile382.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile382.Location = new System.Drawing.Point(804, 352);
            this.tile382.Name = "tile382";
            this.tile382.Size = new System.Drawing.Size(32, 31);
            this.tile382.TabIndex = 427;
            this.tile382.TabStop = false;
            // 
            // tile389
            // 
            this.tile389.BackColor = System.Drawing.Color.White;
            this.tile389.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile389.Location = new System.Drawing.Point(1070, 352);
            this.tile389.Name = "tile389";
            this.tile389.Size = new System.Drawing.Size(32, 31);
            this.tile389.TabIndex = 426;
            this.tile389.TabStop = false;
            // 
            // tile390
            // 
            this.tile390.BackColor = System.Drawing.Color.White;
            this.tile390.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile390.Location = new System.Drawing.Point(1108, 352);
            this.tile390.Name = "tile390";
            this.tile390.Size = new System.Drawing.Size(32, 31);
            this.tile390.TabIndex = 425;
            this.tile390.TabStop = false;
            // 
            // tile373
            // 
            this.tile373.BackColor = System.Drawing.Color.White;
            this.tile373.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile373.Location = new System.Drawing.Point(462, 352);
            this.tile373.Name = "tile373";
            this.tile373.Size = new System.Drawing.Size(32, 31);
            this.tile373.TabIndex = 424;
            this.tile373.TabStop = false;
            // 
            // tile374
            // 
            this.tile374.BackColor = System.Drawing.Color.White;
            this.tile374.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile374.Location = new System.Drawing.Point(500, 352);
            this.tile374.Name = "tile374";
            this.tile374.Size = new System.Drawing.Size(32, 31);
            this.tile374.TabIndex = 423;
            this.tile374.TabStop = false;
            // 
            // tile375
            // 
            this.tile375.BackColor = System.Drawing.Color.White;
            this.tile375.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile375.Location = new System.Drawing.Point(538, 352);
            this.tile375.Name = "tile375";
            this.tile375.Size = new System.Drawing.Size(32, 31);
            this.tile375.TabIndex = 422;
            this.tile375.TabStop = false;
            // 
            // tile376
            // 
            this.tile376.BackColor = System.Drawing.Color.White;
            this.tile376.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile376.Location = new System.Drawing.Point(576, 352);
            this.tile376.Name = "tile376";
            this.tile376.Size = new System.Drawing.Size(32, 31);
            this.tile376.TabIndex = 421;
            this.tile376.TabStop = false;
            // 
            // tile377
            // 
            this.tile377.BackColor = System.Drawing.Color.White;
            this.tile377.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile377.Location = new System.Drawing.Point(614, 352);
            this.tile377.Name = "tile377";
            this.tile377.Size = new System.Drawing.Size(32, 31);
            this.tile377.TabIndex = 420;
            this.tile377.TabStop = false;
            // 
            // tile378
            // 
            this.tile378.BackColor = System.Drawing.Color.White;
            this.tile378.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile378.Location = new System.Drawing.Point(652, 352);
            this.tile378.Name = "tile378";
            this.tile378.Size = new System.Drawing.Size(32, 31);
            this.tile378.TabIndex = 419;
            this.tile378.TabStop = false;
            // 
            // tile379
            // 
            this.tile379.BackColor = System.Drawing.Color.White;
            this.tile379.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile379.Location = new System.Drawing.Point(690, 352);
            this.tile379.Name = "tile379";
            this.tile379.Size = new System.Drawing.Size(32, 31);
            this.tile379.TabIndex = 418;
            this.tile379.TabStop = false;
            // 
            // tile380
            // 
            this.tile380.BackColor = System.Drawing.Color.White;
            this.tile380.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile380.Location = new System.Drawing.Point(728, 352);
            this.tile380.Name = "tile380";
            this.tile380.Size = new System.Drawing.Size(32, 31);
            this.tile380.TabIndex = 417;
            this.tile380.TabStop = false;
            // 
            // tile372
            // 
            this.tile372.BackColor = System.Drawing.Color.White;
            this.tile372.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile372.Location = new System.Drawing.Point(424, 352);
            this.tile372.Name = "tile372";
            this.tile372.Size = new System.Drawing.Size(32, 31);
            this.tile372.TabIndex = 416;
            this.tile372.TabStop = false;
            // 
            // tile371
            // 
            this.tile371.BackColor = System.Drawing.Color.White;
            this.tile371.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile371.Location = new System.Drawing.Point(386, 352);
            this.tile371.Name = "tile371";
            this.tile371.Size = new System.Drawing.Size(32, 31);
            this.tile371.TabIndex = 415;
            this.tile371.TabStop = false;
            // 
            // tile363
            // 
            this.tile363.BackColor = System.Drawing.Color.White;
            this.tile363.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile363.Location = new System.Drawing.Point(82, 352);
            this.tile363.Name = "tile363";
            this.tile363.Size = new System.Drawing.Size(32, 31);
            this.tile363.TabIndex = 414;
            this.tile363.TabStop = false;
            // 
            // tile364
            // 
            this.tile364.BackColor = System.Drawing.Color.White;
            this.tile364.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile364.Location = new System.Drawing.Point(120, 352);
            this.tile364.Name = "tile364";
            this.tile364.Size = new System.Drawing.Size(32, 31);
            this.tile364.TabIndex = 413;
            this.tile364.TabStop = false;
            // 
            // tile365
            // 
            this.tile365.BackColor = System.Drawing.Color.White;
            this.tile365.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile365.Location = new System.Drawing.Point(158, 352);
            this.tile365.Name = "tile365";
            this.tile365.Size = new System.Drawing.Size(32, 31);
            this.tile365.TabIndex = 412;
            this.tile365.TabStop = false;
            // 
            // tile366
            // 
            this.tile366.BackColor = System.Drawing.Color.White;
            this.tile366.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile366.Location = new System.Drawing.Point(196, 352);
            this.tile366.Name = "tile366";
            this.tile366.Size = new System.Drawing.Size(32, 31);
            this.tile366.TabIndex = 411;
            this.tile366.TabStop = false;
            // 
            // tile367
            // 
            this.tile367.BackColor = System.Drawing.Color.White;
            this.tile367.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile367.Location = new System.Drawing.Point(234, 352);
            this.tile367.Name = "tile367";
            this.tile367.Size = new System.Drawing.Size(32, 31);
            this.tile367.TabIndex = 410;
            this.tile367.TabStop = false;
            // 
            // tile368
            // 
            this.tile368.BackColor = System.Drawing.Color.White;
            this.tile368.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile368.Location = new System.Drawing.Point(272, 352);
            this.tile368.Name = "tile368";
            this.tile368.Size = new System.Drawing.Size(32, 31);
            this.tile368.TabIndex = 409;
            this.tile368.TabStop = false;
            // 
            // tile369
            // 
            this.tile369.BackColor = System.Drawing.Color.White;
            this.tile369.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile369.Location = new System.Drawing.Point(310, 352);
            this.tile369.Name = "tile369";
            this.tile369.Size = new System.Drawing.Size(32, 31);
            this.tile369.TabIndex = 408;
            this.tile369.TabStop = false;
            // 
            // tile370
            // 
            this.tile370.BackColor = System.Drawing.Color.White;
            this.tile370.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile370.Location = new System.Drawing.Point(348, 352);
            this.tile370.Name = "tile370";
            this.tile370.Size = new System.Drawing.Size(32, 31);
            this.tile370.TabIndex = 407;
            this.tile370.TabStop = false;
            // 
            // tile362
            // 
            this.tile362.BackColor = System.Drawing.Color.White;
            this.tile362.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile362.Location = new System.Drawing.Point(44, 352);
            this.tile362.Name = "tile362";
            this.tile362.Size = new System.Drawing.Size(32, 31);
            this.tile362.TabIndex = 406;
            this.tile362.TabStop = false;
            // 
            // tile361
            // 
            this.tile361.BackColor = System.Drawing.Color.White;
            this.tile361.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile361.Location = new System.Drawing.Point(6, 352);
            this.tile361.Name = "tile361";
            this.tile361.Size = new System.Drawing.Size(32, 31);
            this.tile361.TabIndex = 405;
            this.tile361.TabStop = false;
            // 
            // tile353
            // 
            this.tile353.BackColor = System.Drawing.Color.White;
            this.tile353.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile353.Location = new System.Drawing.Point(1222, 315);
            this.tile353.Name = "tile353";
            this.tile353.Size = new System.Drawing.Size(32, 31);
            this.tile353.TabIndex = 404;
            this.tile353.TabStop = false;
            // 
            // tile354
            // 
            this.tile354.BackColor = System.Drawing.Color.White;
            this.tile354.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile354.Location = new System.Drawing.Point(1260, 315);
            this.tile354.Name = "tile354";
            this.tile354.Size = new System.Drawing.Size(32, 31);
            this.tile354.TabIndex = 403;
            this.tile354.TabStop = false;
            // 
            // tile355
            // 
            this.tile355.BackColor = System.Drawing.Color.White;
            this.tile355.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile355.Location = new System.Drawing.Point(1298, 315);
            this.tile355.Name = "tile355";
            this.tile355.Size = new System.Drawing.Size(32, 31);
            this.tile355.TabIndex = 402;
            this.tile355.TabStop = false;
            // 
            // tile356
            // 
            this.tile356.BackColor = System.Drawing.Color.White;
            this.tile356.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile356.Location = new System.Drawing.Point(1336, 315);
            this.tile356.Name = "tile356";
            this.tile356.Size = new System.Drawing.Size(32, 31);
            this.tile356.TabIndex = 401;
            this.tile356.TabStop = false;
            // 
            // tile357
            // 
            this.tile357.BackColor = System.Drawing.Color.White;
            this.tile357.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile357.Location = new System.Drawing.Point(1374, 315);
            this.tile357.Name = "tile357";
            this.tile357.Size = new System.Drawing.Size(32, 31);
            this.tile357.TabIndex = 400;
            this.tile357.TabStop = false;
            // 
            // tile358
            // 
            this.tile358.BackColor = System.Drawing.Color.White;
            this.tile358.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile358.Location = new System.Drawing.Point(1412, 315);
            this.tile358.Name = "tile358";
            this.tile358.Size = new System.Drawing.Size(32, 31);
            this.tile358.TabIndex = 399;
            this.tile358.TabStop = false;
            // 
            // tile360
            // 
            this.tile360.BackColor = System.Drawing.Color.White;
            this.tile360.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile360.Location = new System.Drawing.Point(1488, 315);
            this.tile360.Name = "tile360";
            this.tile360.Size = new System.Drawing.Size(32, 31);
            this.tile360.TabIndex = 398;
            this.tile360.TabStop = false;
            // 
            // tile359
            // 
            this.tile359.BackColor = System.Drawing.Color.White;
            this.tile359.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile359.Location = new System.Drawing.Point(1450, 315);
            this.tile359.Name = "tile359";
            this.tile359.Size = new System.Drawing.Size(32, 31);
            this.tile359.TabIndex = 397;
            this.tile359.TabStop = false;
            // 
            // tile352
            // 
            this.tile352.BackColor = System.Drawing.Color.White;
            this.tile352.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile352.Location = new System.Drawing.Point(1184, 315);
            this.tile352.Name = "tile352";
            this.tile352.Size = new System.Drawing.Size(32, 31);
            this.tile352.TabIndex = 396;
            this.tile352.TabStop = false;
            // 
            // tile351
            // 
            this.tile351.BackColor = System.Drawing.Color.White;
            this.tile351.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile351.Location = new System.Drawing.Point(1146, 315);
            this.tile351.Name = "tile351";
            this.tile351.Size = new System.Drawing.Size(32, 31);
            this.tile351.TabIndex = 395;
            this.tile351.TabStop = false;
            // 
            // tile348
            // 
            this.tile348.BackColor = System.Drawing.Color.White;
            this.tile348.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile348.Location = new System.Drawing.Point(1032, 315);
            this.tile348.Name = "tile348";
            this.tile348.Size = new System.Drawing.Size(32, 31);
            this.tile348.TabIndex = 394;
            this.tile348.TabStop = false;
            // 
            // tile347
            // 
            this.tile347.BackColor = System.Drawing.Color.White;
            this.tile347.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile347.Location = new System.Drawing.Point(994, 315);
            this.tile347.Name = "tile347";
            this.tile347.Size = new System.Drawing.Size(32, 31);
            this.tile347.TabIndex = 393;
            this.tile347.TabStop = false;
            // 
            // tile346
            // 
            this.tile346.BackColor = System.Drawing.Color.White;
            this.tile346.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile346.Location = new System.Drawing.Point(956, 315);
            this.tile346.Name = "tile346";
            this.tile346.Size = new System.Drawing.Size(32, 31);
            this.tile346.TabIndex = 392;
            this.tile346.TabStop = false;
            // 
            // tile345
            // 
            this.tile345.BackColor = System.Drawing.Color.White;
            this.tile345.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile345.Location = new System.Drawing.Point(918, 315);
            this.tile345.Name = "tile345";
            this.tile345.Size = new System.Drawing.Size(32, 31);
            this.tile345.TabIndex = 391;
            this.tile345.TabStop = false;
            // 
            // tile344
            // 
            this.tile344.BackColor = System.Drawing.Color.White;
            this.tile344.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile344.Location = new System.Drawing.Point(880, 315);
            this.tile344.Name = "tile344";
            this.tile344.Size = new System.Drawing.Size(32, 31);
            this.tile344.TabIndex = 390;
            this.tile344.TabStop = false;
            // 
            // tile343
            // 
            this.tile343.BackColor = System.Drawing.Color.White;
            this.tile343.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile343.Location = new System.Drawing.Point(842, 315);
            this.tile343.Name = "tile343";
            this.tile343.Size = new System.Drawing.Size(32, 31);
            this.tile343.TabIndex = 389;
            this.tile343.TabStop = false;
            // 
            // tile341
            // 
            this.tile341.BackColor = System.Drawing.Color.White;
            this.tile341.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile341.Location = new System.Drawing.Point(766, 315);
            this.tile341.Name = "tile341";
            this.tile341.Size = new System.Drawing.Size(32, 31);
            this.tile341.TabIndex = 388;
            this.tile341.TabStop = false;
            // 
            // tile342
            // 
            this.tile342.BackColor = System.Drawing.Color.White;
            this.tile342.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile342.Location = new System.Drawing.Point(804, 315);
            this.tile342.Name = "tile342";
            this.tile342.Size = new System.Drawing.Size(32, 31);
            this.tile342.TabIndex = 387;
            this.tile342.TabStop = false;
            // 
            // tile349
            // 
            this.tile349.BackColor = System.Drawing.Color.White;
            this.tile349.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile349.Location = new System.Drawing.Point(1070, 315);
            this.tile349.Name = "tile349";
            this.tile349.Size = new System.Drawing.Size(32, 31);
            this.tile349.TabIndex = 386;
            this.tile349.TabStop = false;
            // 
            // tile350
            // 
            this.tile350.BackColor = System.Drawing.Color.White;
            this.tile350.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile350.Location = new System.Drawing.Point(1108, 315);
            this.tile350.Name = "tile350";
            this.tile350.Size = new System.Drawing.Size(32, 31);
            this.tile350.TabIndex = 385;
            this.tile350.TabStop = false;
            // 
            // tile333
            // 
            this.tile333.BackColor = System.Drawing.Color.White;
            this.tile333.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile333.Location = new System.Drawing.Point(462, 315);
            this.tile333.Name = "tile333";
            this.tile333.Size = new System.Drawing.Size(32, 31);
            this.tile333.TabIndex = 384;
            this.tile333.TabStop = false;
            // 
            // tile334
            // 
            this.tile334.BackColor = System.Drawing.Color.White;
            this.tile334.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile334.Location = new System.Drawing.Point(500, 315);
            this.tile334.Name = "tile334";
            this.tile334.Size = new System.Drawing.Size(32, 31);
            this.tile334.TabIndex = 383;
            this.tile334.TabStop = false;
            // 
            // tile335
            // 
            this.tile335.BackColor = System.Drawing.Color.White;
            this.tile335.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile335.Location = new System.Drawing.Point(538, 315);
            this.tile335.Name = "tile335";
            this.tile335.Size = new System.Drawing.Size(32, 31);
            this.tile335.TabIndex = 382;
            this.tile335.TabStop = false;
            // 
            // tile336
            // 
            this.tile336.BackColor = System.Drawing.Color.White;
            this.tile336.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile336.Location = new System.Drawing.Point(576, 315);
            this.tile336.Name = "tile336";
            this.tile336.Size = new System.Drawing.Size(32, 31);
            this.tile336.TabIndex = 381;
            this.tile336.TabStop = false;
            // 
            // tile337
            // 
            this.tile337.BackColor = System.Drawing.Color.White;
            this.tile337.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile337.Location = new System.Drawing.Point(614, 315);
            this.tile337.Name = "tile337";
            this.tile337.Size = new System.Drawing.Size(32, 31);
            this.tile337.TabIndex = 380;
            this.tile337.TabStop = false;
            // 
            // tile338
            // 
            this.tile338.BackColor = System.Drawing.Color.White;
            this.tile338.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile338.Location = new System.Drawing.Point(652, 315);
            this.tile338.Name = "tile338";
            this.tile338.Size = new System.Drawing.Size(32, 31);
            this.tile338.TabIndex = 379;
            this.tile338.TabStop = false;
            // 
            // tile339
            // 
            this.tile339.BackColor = System.Drawing.Color.White;
            this.tile339.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile339.Location = new System.Drawing.Point(690, 315);
            this.tile339.Name = "tile339";
            this.tile339.Size = new System.Drawing.Size(32, 31);
            this.tile339.TabIndex = 378;
            this.tile339.TabStop = false;
            // 
            // tile340
            // 
            this.tile340.BackColor = System.Drawing.Color.White;
            this.tile340.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile340.Location = new System.Drawing.Point(728, 315);
            this.tile340.Name = "tile340";
            this.tile340.Size = new System.Drawing.Size(32, 31);
            this.tile340.TabIndex = 377;
            this.tile340.TabStop = false;
            // 
            // tile332
            // 
            this.tile332.BackColor = System.Drawing.Color.White;
            this.tile332.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile332.Location = new System.Drawing.Point(424, 315);
            this.tile332.Name = "tile332";
            this.tile332.Size = new System.Drawing.Size(32, 31);
            this.tile332.TabIndex = 376;
            this.tile332.TabStop = false;
            // 
            // tile331
            // 
            this.tile331.BackColor = System.Drawing.Color.White;
            this.tile331.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile331.Location = new System.Drawing.Point(386, 315);
            this.tile331.Name = "tile331";
            this.tile331.Size = new System.Drawing.Size(32, 31);
            this.tile331.TabIndex = 375;
            this.tile331.TabStop = false;
            // 
            // tile323
            // 
            this.tile323.BackColor = System.Drawing.Color.White;
            this.tile323.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile323.Location = new System.Drawing.Point(82, 315);
            this.tile323.Name = "tile323";
            this.tile323.Size = new System.Drawing.Size(32, 31);
            this.tile323.TabIndex = 374;
            this.tile323.TabStop = false;
            // 
            // tile324
            // 
            this.tile324.BackColor = System.Drawing.Color.White;
            this.tile324.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile324.Location = new System.Drawing.Point(120, 315);
            this.tile324.Name = "tile324";
            this.tile324.Size = new System.Drawing.Size(32, 31);
            this.tile324.TabIndex = 373;
            this.tile324.TabStop = false;
            // 
            // tile325
            // 
            this.tile325.BackColor = System.Drawing.Color.White;
            this.tile325.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile325.Location = new System.Drawing.Point(158, 315);
            this.tile325.Name = "tile325";
            this.tile325.Size = new System.Drawing.Size(32, 31);
            this.tile325.TabIndex = 372;
            this.tile325.TabStop = false;
            // 
            // tile326
            // 
            this.tile326.BackColor = System.Drawing.Color.White;
            this.tile326.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile326.Location = new System.Drawing.Point(196, 315);
            this.tile326.Name = "tile326";
            this.tile326.Size = new System.Drawing.Size(32, 31);
            this.tile326.TabIndex = 371;
            this.tile326.TabStop = false;
            // 
            // tile327
            // 
            this.tile327.BackColor = System.Drawing.Color.White;
            this.tile327.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile327.Location = new System.Drawing.Point(234, 315);
            this.tile327.Name = "tile327";
            this.tile327.Size = new System.Drawing.Size(32, 31);
            this.tile327.TabIndex = 370;
            this.tile327.TabStop = false;
            // 
            // tile328
            // 
            this.tile328.BackColor = System.Drawing.Color.White;
            this.tile328.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile328.Location = new System.Drawing.Point(272, 315);
            this.tile328.Name = "tile328";
            this.tile328.Size = new System.Drawing.Size(32, 31);
            this.tile328.TabIndex = 369;
            this.tile328.TabStop = false;
            // 
            // tile329
            // 
            this.tile329.BackColor = System.Drawing.Color.White;
            this.tile329.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile329.Location = new System.Drawing.Point(310, 315);
            this.tile329.Name = "tile329";
            this.tile329.Size = new System.Drawing.Size(32, 31);
            this.tile329.TabIndex = 368;
            this.tile329.TabStop = false;
            // 
            // tile330
            // 
            this.tile330.BackColor = System.Drawing.Color.White;
            this.tile330.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile330.Location = new System.Drawing.Point(348, 315);
            this.tile330.Name = "tile330";
            this.tile330.Size = new System.Drawing.Size(32, 31);
            this.tile330.TabIndex = 367;
            this.tile330.TabStop = false;
            // 
            // tile322
            // 
            this.tile322.BackColor = System.Drawing.Color.White;
            this.tile322.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile322.Location = new System.Drawing.Point(44, 315);
            this.tile322.Name = "tile322";
            this.tile322.Size = new System.Drawing.Size(32, 31);
            this.tile322.TabIndex = 366;
            this.tile322.TabStop = false;
            // 
            // tile321
            // 
            this.tile321.BackColor = System.Drawing.Color.White;
            this.tile321.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile321.Location = new System.Drawing.Point(6, 315);
            this.tile321.Name = "tile321";
            this.tile321.Size = new System.Drawing.Size(32, 31);
            this.tile321.TabIndex = 365;
            this.tile321.TabStop = false;
            // 
            // tile313
            // 
            this.tile313.BackColor = System.Drawing.Color.White;
            this.tile313.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile313.Location = new System.Drawing.Point(1222, 278);
            this.tile313.Name = "tile313";
            this.tile313.Size = new System.Drawing.Size(32, 31);
            this.tile313.TabIndex = 364;
            this.tile313.TabStop = false;
            // 
            // tile314
            // 
            this.tile314.BackColor = System.Drawing.Color.White;
            this.tile314.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile314.Location = new System.Drawing.Point(1260, 278);
            this.tile314.Name = "tile314";
            this.tile314.Size = new System.Drawing.Size(32, 31);
            this.tile314.TabIndex = 363;
            this.tile314.TabStop = false;
            // 
            // tile315
            // 
            this.tile315.BackColor = System.Drawing.Color.White;
            this.tile315.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile315.Location = new System.Drawing.Point(1298, 278);
            this.tile315.Name = "tile315";
            this.tile315.Size = new System.Drawing.Size(32, 31);
            this.tile315.TabIndex = 362;
            this.tile315.TabStop = false;
            // 
            // tile316
            // 
            this.tile316.BackColor = System.Drawing.Color.White;
            this.tile316.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile316.Location = new System.Drawing.Point(1336, 278);
            this.tile316.Name = "tile316";
            this.tile316.Size = new System.Drawing.Size(32, 31);
            this.tile316.TabIndex = 361;
            this.tile316.TabStop = false;
            // 
            // tile317
            // 
            this.tile317.BackColor = System.Drawing.Color.White;
            this.tile317.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile317.Location = new System.Drawing.Point(1374, 278);
            this.tile317.Name = "tile317";
            this.tile317.Size = new System.Drawing.Size(32, 31);
            this.tile317.TabIndex = 360;
            this.tile317.TabStop = false;
            // 
            // tile318
            // 
            this.tile318.BackColor = System.Drawing.Color.White;
            this.tile318.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile318.Location = new System.Drawing.Point(1412, 278);
            this.tile318.Name = "tile318";
            this.tile318.Size = new System.Drawing.Size(32, 31);
            this.tile318.TabIndex = 359;
            this.tile318.TabStop = false;
            // 
            // tile320
            // 
            this.tile320.BackColor = System.Drawing.Color.White;
            this.tile320.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile320.Location = new System.Drawing.Point(1488, 278);
            this.tile320.Name = "tile320";
            this.tile320.Size = new System.Drawing.Size(32, 31);
            this.tile320.TabIndex = 358;
            this.tile320.TabStop = false;
            // 
            // tile319
            // 
            this.tile319.BackColor = System.Drawing.Color.White;
            this.tile319.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile319.Location = new System.Drawing.Point(1450, 278);
            this.tile319.Name = "tile319";
            this.tile319.Size = new System.Drawing.Size(32, 31);
            this.tile319.TabIndex = 357;
            this.tile319.TabStop = false;
            // 
            // tile312
            // 
            this.tile312.BackColor = System.Drawing.Color.White;
            this.tile312.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile312.Location = new System.Drawing.Point(1184, 278);
            this.tile312.Name = "tile312";
            this.tile312.Size = new System.Drawing.Size(32, 31);
            this.tile312.TabIndex = 356;
            this.tile312.TabStop = false;
            // 
            // tile311
            // 
            this.tile311.BackColor = System.Drawing.Color.White;
            this.tile311.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile311.Location = new System.Drawing.Point(1146, 278);
            this.tile311.Name = "tile311";
            this.tile311.Size = new System.Drawing.Size(32, 31);
            this.tile311.TabIndex = 355;
            this.tile311.TabStop = false;
            // 
            // tile308
            // 
            this.tile308.BackColor = System.Drawing.Color.White;
            this.tile308.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile308.Location = new System.Drawing.Point(1032, 278);
            this.tile308.Name = "tile308";
            this.tile308.Size = new System.Drawing.Size(32, 31);
            this.tile308.TabIndex = 354;
            this.tile308.TabStop = false;
            // 
            // tile307
            // 
            this.tile307.BackColor = System.Drawing.Color.White;
            this.tile307.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile307.Location = new System.Drawing.Point(994, 278);
            this.tile307.Name = "tile307";
            this.tile307.Size = new System.Drawing.Size(32, 31);
            this.tile307.TabIndex = 353;
            this.tile307.TabStop = false;
            // 
            // tile306
            // 
            this.tile306.BackColor = System.Drawing.Color.White;
            this.tile306.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile306.Location = new System.Drawing.Point(956, 278);
            this.tile306.Name = "tile306";
            this.tile306.Size = new System.Drawing.Size(32, 31);
            this.tile306.TabIndex = 352;
            this.tile306.TabStop = false;
            // 
            // tile305
            // 
            this.tile305.BackColor = System.Drawing.Color.White;
            this.tile305.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile305.Location = new System.Drawing.Point(918, 278);
            this.tile305.Name = "tile305";
            this.tile305.Size = new System.Drawing.Size(32, 31);
            this.tile305.TabIndex = 351;
            this.tile305.TabStop = false;
            // 
            // tile304
            // 
            this.tile304.BackColor = System.Drawing.Color.White;
            this.tile304.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile304.Location = new System.Drawing.Point(880, 278);
            this.tile304.Name = "tile304";
            this.tile304.Size = new System.Drawing.Size(32, 31);
            this.tile304.TabIndex = 350;
            this.tile304.TabStop = false;
            // 
            // tile303
            // 
            this.tile303.BackColor = System.Drawing.Color.White;
            this.tile303.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile303.Location = new System.Drawing.Point(842, 278);
            this.tile303.Name = "tile303";
            this.tile303.Size = new System.Drawing.Size(32, 31);
            this.tile303.TabIndex = 349;
            this.tile303.TabStop = false;
            // 
            // tile301
            // 
            this.tile301.BackColor = System.Drawing.Color.White;
            this.tile301.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile301.Location = new System.Drawing.Point(766, 278);
            this.tile301.Name = "tile301";
            this.tile301.Size = new System.Drawing.Size(32, 31);
            this.tile301.TabIndex = 348;
            this.tile301.TabStop = false;
            // 
            // tile302
            // 
            this.tile302.BackColor = System.Drawing.Color.White;
            this.tile302.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile302.Location = new System.Drawing.Point(804, 278);
            this.tile302.Name = "tile302";
            this.tile302.Size = new System.Drawing.Size(32, 31);
            this.tile302.TabIndex = 347;
            this.tile302.TabStop = false;
            // 
            // tile309
            // 
            this.tile309.BackColor = System.Drawing.Color.White;
            this.tile309.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile309.Location = new System.Drawing.Point(1070, 278);
            this.tile309.Name = "tile309";
            this.tile309.Size = new System.Drawing.Size(32, 31);
            this.tile309.TabIndex = 346;
            this.tile309.TabStop = false;
            // 
            // tile310
            // 
            this.tile310.BackColor = System.Drawing.Color.White;
            this.tile310.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile310.Location = new System.Drawing.Point(1108, 278);
            this.tile310.Name = "tile310";
            this.tile310.Size = new System.Drawing.Size(32, 31);
            this.tile310.TabIndex = 345;
            this.tile310.TabStop = false;
            // 
            // tile293
            // 
            this.tile293.BackColor = System.Drawing.Color.White;
            this.tile293.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile293.Location = new System.Drawing.Point(462, 278);
            this.tile293.Name = "tile293";
            this.tile293.Size = new System.Drawing.Size(32, 31);
            this.tile293.TabIndex = 344;
            this.tile293.TabStop = false;
            // 
            // tile294
            // 
            this.tile294.BackColor = System.Drawing.Color.White;
            this.tile294.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile294.Location = new System.Drawing.Point(500, 278);
            this.tile294.Name = "tile294";
            this.tile294.Size = new System.Drawing.Size(32, 31);
            this.tile294.TabIndex = 343;
            this.tile294.TabStop = false;
            // 
            // tile295
            // 
            this.tile295.BackColor = System.Drawing.Color.White;
            this.tile295.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile295.Location = new System.Drawing.Point(538, 278);
            this.tile295.Name = "tile295";
            this.tile295.Size = new System.Drawing.Size(32, 31);
            this.tile295.TabIndex = 342;
            this.tile295.TabStop = false;
            // 
            // tile296
            // 
            this.tile296.BackColor = System.Drawing.Color.White;
            this.tile296.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile296.Location = new System.Drawing.Point(576, 278);
            this.tile296.Name = "tile296";
            this.tile296.Size = new System.Drawing.Size(32, 31);
            this.tile296.TabIndex = 341;
            this.tile296.TabStop = false;
            // 
            // tile297
            // 
            this.tile297.BackColor = System.Drawing.Color.White;
            this.tile297.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile297.Location = new System.Drawing.Point(614, 278);
            this.tile297.Name = "tile297";
            this.tile297.Size = new System.Drawing.Size(32, 31);
            this.tile297.TabIndex = 340;
            this.tile297.TabStop = false;
            // 
            // tile298
            // 
            this.tile298.BackColor = System.Drawing.Color.White;
            this.tile298.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile298.Location = new System.Drawing.Point(652, 278);
            this.tile298.Name = "tile298";
            this.tile298.Size = new System.Drawing.Size(32, 31);
            this.tile298.TabIndex = 339;
            this.tile298.TabStop = false;
            // 
            // tile299
            // 
            this.tile299.BackColor = System.Drawing.Color.White;
            this.tile299.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile299.Location = new System.Drawing.Point(690, 278);
            this.tile299.Name = "tile299";
            this.tile299.Size = new System.Drawing.Size(32, 31);
            this.tile299.TabIndex = 338;
            this.tile299.TabStop = false;
            // 
            // tile300
            // 
            this.tile300.BackColor = System.Drawing.Color.White;
            this.tile300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile300.Location = new System.Drawing.Point(728, 278);
            this.tile300.Name = "tile300";
            this.tile300.Size = new System.Drawing.Size(32, 31);
            this.tile300.TabIndex = 337;
            this.tile300.TabStop = false;
            // 
            // tile292
            // 
            this.tile292.BackColor = System.Drawing.Color.White;
            this.tile292.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile292.Location = new System.Drawing.Point(424, 278);
            this.tile292.Name = "tile292";
            this.tile292.Size = new System.Drawing.Size(32, 31);
            this.tile292.TabIndex = 336;
            this.tile292.TabStop = false;
            // 
            // tile291
            // 
            this.tile291.BackColor = System.Drawing.Color.White;
            this.tile291.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile291.Location = new System.Drawing.Point(386, 278);
            this.tile291.Name = "tile291";
            this.tile291.Size = new System.Drawing.Size(32, 31);
            this.tile291.TabIndex = 335;
            this.tile291.TabStop = false;
            // 
            // tile283
            // 
            this.tile283.BackColor = System.Drawing.Color.White;
            this.tile283.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile283.Location = new System.Drawing.Point(82, 278);
            this.tile283.Name = "tile283";
            this.tile283.Size = new System.Drawing.Size(32, 31);
            this.tile283.TabIndex = 334;
            this.tile283.TabStop = false;
            // 
            // tile284
            // 
            this.tile284.BackColor = System.Drawing.Color.White;
            this.tile284.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile284.Location = new System.Drawing.Point(120, 278);
            this.tile284.Name = "tile284";
            this.tile284.Size = new System.Drawing.Size(32, 31);
            this.tile284.TabIndex = 333;
            this.tile284.TabStop = false;
            // 
            // tile285
            // 
            this.tile285.BackColor = System.Drawing.Color.White;
            this.tile285.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile285.Location = new System.Drawing.Point(158, 278);
            this.tile285.Name = "tile285";
            this.tile285.Size = new System.Drawing.Size(32, 31);
            this.tile285.TabIndex = 332;
            this.tile285.TabStop = false;
            // 
            // tile286
            // 
            this.tile286.BackColor = System.Drawing.Color.White;
            this.tile286.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile286.Location = new System.Drawing.Point(196, 278);
            this.tile286.Name = "tile286";
            this.tile286.Size = new System.Drawing.Size(32, 31);
            this.tile286.TabIndex = 331;
            this.tile286.TabStop = false;
            // 
            // tile287
            // 
            this.tile287.BackColor = System.Drawing.Color.White;
            this.tile287.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile287.Location = new System.Drawing.Point(234, 278);
            this.tile287.Name = "tile287";
            this.tile287.Size = new System.Drawing.Size(32, 31);
            this.tile287.TabIndex = 330;
            this.tile287.TabStop = false;
            // 
            // tile288
            // 
            this.tile288.BackColor = System.Drawing.Color.White;
            this.tile288.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile288.Location = new System.Drawing.Point(272, 278);
            this.tile288.Name = "tile288";
            this.tile288.Size = new System.Drawing.Size(32, 31);
            this.tile288.TabIndex = 329;
            this.tile288.TabStop = false;
            // 
            // tile289
            // 
            this.tile289.BackColor = System.Drawing.Color.White;
            this.tile289.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile289.Location = new System.Drawing.Point(310, 278);
            this.tile289.Name = "tile289";
            this.tile289.Size = new System.Drawing.Size(32, 31);
            this.tile289.TabIndex = 328;
            this.tile289.TabStop = false;
            // 
            // tile290
            // 
            this.tile290.BackColor = System.Drawing.Color.White;
            this.tile290.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile290.Location = new System.Drawing.Point(348, 278);
            this.tile290.Name = "tile290";
            this.tile290.Size = new System.Drawing.Size(32, 31);
            this.tile290.TabIndex = 327;
            this.tile290.TabStop = false;
            // 
            // tile282
            // 
            this.tile282.BackColor = System.Drawing.Color.White;
            this.tile282.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile282.Location = new System.Drawing.Point(44, 278);
            this.tile282.Name = "tile282";
            this.tile282.Size = new System.Drawing.Size(32, 31);
            this.tile282.TabIndex = 326;
            this.tile282.TabStop = false;
            // 
            // tile281
            // 
            this.tile281.BackColor = System.Drawing.Color.White;
            this.tile281.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile281.Location = new System.Drawing.Point(6, 278);
            this.tile281.Name = "tile281";
            this.tile281.Size = new System.Drawing.Size(32, 31);
            this.tile281.TabIndex = 325;
            this.tile281.TabStop = false;
            // 
            // tile273
            // 
            this.tile273.BackColor = System.Drawing.Color.White;
            this.tile273.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile273.Location = new System.Drawing.Point(1222, 241);
            this.tile273.Name = "tile273";
            this.tile273.Size = new System.Drawing.Size(32, 31);
            this.tile273.TabIndex = 324;
            this.tile273.TabStop = false;
            // 
            // tile274
            // 
            this.tile274.BackColor = System.Drawing.Color.White;
            this.tile274.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile274.Location = new System.Drawing.Point(1260, 241);
            this.tile274.Name = "tile274";
            this.tile274.Size = new System.Drawing.Size(32, 31);
            this.tile274.TabIndex = 323;
            this.tile274.TabStop = false;
            // 
            // tile275
            // 
            this.tile275.BackColor = System.Drawing.Color.White;
            this.tile275.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile275.Location = new System.Drawing.Point(1298, 241);
            this.tile275.Name = "tile275";
            this.tile275.Size = new System.Drawing.Size(32, 31);
            this.tile275.TabIndex = 322;
            this.tile275.TabStop = false;
            // 
            // tile276
            // 
            this.tile276.BackColor = System.Drawing.Color.White;
            this.tile276.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile276.Location = new System.Drawing.Point(1336, 241);
            this.tile276.Name = "tile276";
            this.tile276.Size = new System.Drawing.Size(32, 31);
            this.tile276.TabIndex = 321;
            this.tile276.TabStop = false;
            // 
            // tile277
            // 
            this.tile277.BackColor = System.Drawing.Color.White;
            this.tile277.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile277.Location = new System.Drawing.Point(1374, 241);
            this.tile277.Name = "tile277";
            this.tile277.Size = new System.Drawing.Size(32, 31);
            this.tile277.TabIndex = 320;
            this.tile277.TabStop = false;
            // 
            // tile278
            // 
            this.tile278.BackColor = System.Drawing.Color.White;
            this.tile278.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile278.Location = new System.Drawing.Point(1412, 241);
            this.tile278.Name = "tile278";
            this.tile278.Size = new System.Drawing.Size(32, 31);
            this.tile278.TabIndex = 319;
            this.tile278.TabStop = false;
            // 
            // tile280
            // 
            this.tile280.BackColor = System.Drawing.Color.White;
            this.tile280.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile280.Location = new System.Drawing.Point(1488, 241);
            this.tile280.Name = "tile280";
            this.tile280.Size = new System.Drawing.Size(32, 31);
            this.tile280.TabIndex = 318;
            this.tile280.TabStop = false;
            // 
            // tile279
            // 
            this.tile279.BackColor = System.Drawing.Color.White;
            this.tile279.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile279.Location = new System.Drawing.Point(1450, 241);
            this.tile279.Name = "tile279";
            this.tile279.Size = new System.Drawing.Size(32, 31);
            this.tile279.TabIndex = 317;
            this.tile279.TabStop = false;
            // 
            // tile272
            // 
            this.tile272.BackColor = System.Drawing.Color.White;
            this.tile272.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile272.Location = new System.Drawing.Point(1184, 241);
            this.tile272.Name = "tile272";
            this.tile272.Size = new System.Drawing.Size(32, 31);
            this.tile272.TabIndex = 316;
            this.tile272.TabStop = false;
            // 
            // tile271
            // 
            this.tile271.BackColor = System.Drawing.Color.White;
            this.tile271.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile271.Location = new System.Drawing.Point(1146, 241);
            this.tile271.Name = "tile271";
            this.tile271.Size = new System.Drawing.Size(32, 31);
            this.tile271.TabIndex = 315;
            this.tile271.TabStop = false;
            // 
            // tile268
            // 
            this.tile268.BackColor = System.Drawing.Color.White;
            this.tile268.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile268.Location = new System.Drawing.Point(1032, 241);
            this.tile268.Name = "tile268";
            this.tile268.Size = new System.Drawing.Size(32, 31);
            this.tile268.TabIndex = 314;
            this.tile268.TabStop = false;
            // 
            // tile267
            // 
            this.tile267.BackColor = System.Drawing.Color.White;
            this.tile267.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile267.Location = new System.Drawing.Point(994, 241);
            this.tile267.Name = "tile267";
            this.tile267.Size = new System.Drawing.Size(32, 31);
            this.tile267.TabIndex = 313;
            this.tile267.TabStop = false;
            // 
            // tile266
            // 
            this.tile266.BackColor = System.Drawing.Color.White;
            this.tile266.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile266.Location = new System.Drawing.Point(956, 241);
            this.tile266.Name = "tile266";
            this.tile266.Size = new System.Drawing.Size(32, 31);
            this.tile266.TabIndex = 312;
            this.tile266.TabStop = false;
            // 
            // tile265
            // 
            this.tile265.BackColor = System.Drawing.Color.White;
            this.tile265.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile265.Location = new System.Drawing.Point(918, 241);
            this.tile265.Name = "tile265";
            this.tile265.Size = new System.Drawing.Size(32, 31);
            this.tile265.TabIndex = 311;
            this.tile265.TabStop = false;
            // 
            // tile264
            // 
            this.tile264.BackColor = System.Drawing.Color.White;
            this.tile264.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile264.Location = new System.Drawing.Point(880, 241);
            this.tile264.Name = "tile264";
            this.tile264.Size = new System.Drawing.Size(32, 31);
            this.tile264.TabIndex = 310;
            this.tile264.TabStop = false;
            // 
            // tile263
            // 
            this.tile263.BackColor = System.Drawing.Color.White;
            this.tile263.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile263.Location = new System.Drawing.Point(842, 241);
            this.tile263.Name = "tile263";
            this.tile263.Size = new System.Drawing.Size(32, 31);
            this.tile263.TabIndex = 309;
            this.tile263.TabStop = false;
            this.tile263.Click += new System.EventHandler(this.t_Click);
            // 
            // tile261
            // 
            this.tile261.BackColor = System.Drawing.Color.White;
            this.tile261.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile261.Location = new System.Drawing.Point(766, 241);
            this.tile261.Name = "tile261";
            this.tile261.Size = new System.Drawing.Size(32, 31);
            this.tile261.TabIndex = 308;
            this.tile261.TabStop = false;
            // 
            // tile262
            // 
            this.tile262.BackColor = System.Drawing.Color.White;
            this.tile262.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile262.Location = new System.Drawing.Point(804, 241);
            this.tile262.Name = "tile262";
            this.tile262.Size = new System.Drawing.Size(32, 31);
            this.tile262.TabIndex = 307;
            this.tile262.TabStop = false;
            // 
            // tile269
            // 
            this.tile269.BackColor = System.Drawing.Color.White;
            this.tile269.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile269.Location = new System.Drawing.Point(1070, 241);
            this.tile269.Name = "tile269";
            this.tile269.Size = new System.Drawing.Size(32, 31);
            this.tile269.TabIndex = 306;
            this.tile269.TabStop = false;
            // 
            // tile270
            // 
            this.tile270.BackColor = System.Drawing.Color.White;
            this.tile270.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile270.Location = new System.Drawing.Point(1108, 241);
            this.tile270.Name = "tile270";
            this.tile270.Size = new System.Drawing.Size(32, 31);
            this.tile270.TabIndex = 305;
            this.tile270.TabStop = false;
            // 
            // tile253
            // 
            this.tile253.BackColor = System.Drawing.Color.White;
            this.tile253.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile253.Location = new System.Drawing.Point(462, 241);
            this.tile253.Name = "tile253";
            this.tile253.Size = new System.Drawing.Size(32, 31);
            this.tile253.TabIndex = 304;
            this.tile253.TabStop = false;
            // 
            // tile254
            // 
            this.tile254.BackColor = System.Drawing.Color.White;
            this.tile254.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile254.Location = new System.Drawing.Point(500, 241);
            this.tile254.Name = "tile254";
            this.tile254.Size = new System.Drawing.Size(32, 31);
            this.tile254.TabIndex = 303;
            this.tile254.TabStop = false;
            // 
            // tile255
            // 
            this.tile255.BackColor = System.Drawing.Color.White;
            this.tile255.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile255.Location = new System.Drawing.Point(538, 241);
            this.tile255.Name = "tile255";
            this.tile255.Size = new System.Drawing.Size(32, 31);
            this.tile255.TabIndex = 302;
            this.tile255.TabStop = false;
            // 
            // tile256
            // 
            this.tile256.BackColor = System.Drawing.Color.White;
            this.tile256.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile256.Location = new System.Drawing.Point(576, 241);
            this.tile256.Name = "tile256";
            this.tile256.Size = new System.Drawing.Size(32, 31);
            this.tile256.TabIndex = 301;
            this.tile256.TabStop = false;
            // 
            // tile257
            // 
            this.tile257.BackColor = System.Drawing.Color.White;
            this.tile257.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile257.Location = new System.Drawing.Point(614, 241);
            this.tile257.Name = "tile257";
            this.tile257.Size = new System.Drawing.Size(32, 31);
            this.tile257.TabIndex = 300;
            this.tile257.TabStop = false;
            // 
            // tile258
            // 
            this.tile258.BackColor = System.Drawing.Color.White;
            this.tile258.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile258.Location = new System.Drawing.Point(652, 241);
            this.tile258.Name = "tile258";
            this.tile258.Size = new System.Drawing.Size(32, 31);
            this.tile258.TabIndex = 299;
            this.tile258.TabStop = false;
            // 
            // tile259
            // 
            this.tile259.BackColor = System.Drawing.Color.White;
            this.tile259.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile259.Location = new System.Drawing.Point(690, 241);
            this.tile259.Name = "tile259";
            this.tile259.Size = new System.Drawing.Size(32, 31);
            this.tile259.TabIndex = 298;
            this.tile259.TabStop = false;
            // 
            // tile260
            // 
            this.tile260.BackColor = System.Drawing.Color.White;
            this.tile260.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile260.Location = new System.Drawing.Point(728, 241);
            this.tile260.Name = "tile260";
            this.tile260.Size = new System.Drawing.Size(32, 31);
            this.tile260.TabIndex = 297;
            this.tile260.TabStop = false;
            // 
            // tile252
            // 
            this.tile252.BackColor = System.Drawing.Color.White;
            this.tile252.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile252.Location = new System.Drawing.Point(424, 241);
            this.tile252.Name = "tile252";
            this.tile252.Size = new System.Drawing.Size(32, 31);
            this.tile252.TabIndex = 296;
            this.tile252.TabStop = false;
            // 
            // tile251
            // 
            this.tile251.BackColor = System.Drawing.Color.White;
            this.tile251.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile251.Location = new System.Drawing.Point(386, 241);
            this.tile251.Name = "tile251";
            this.tile251.Size = new System.Drawing.Size(32, 31);
            this.tile251.TabIndex = 295;
            this.tile251.TabStop = false;
            // 
            // tile243
            // 
            this.tile243.BackColor = System.Drawing.Color.White;
            this.tile243.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile243.Location = new System.Drawing.Point(82, 241);
            this.tile243.Name = "tile243";
            this.tile243.Size = new System.Drawing.Size(32, 31);
            this.tile243.TabIndex = 294;
            this.tile243.TabStop = false;
            // 
            // tile244
            // 
            this.tile244.BackColor = System.Drawing.Color.White;
            this.tile244.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile244.Location = new System.Drawing.Point(120, 241);
            this.tile244.Name = "tile244";
            this.tile244.Size = new System.Drawing.Size(32, 31);
            this.tile244.TabIndex = 293;
            this.tile244.TabStop = false;
            // 
            // tile245
            // 
            this.tile245.BackColor = System.Drawing.Color.White;
            this.tile245.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile245.Location = new System.Drawing.Point(158, 241);
            this.tile245.Name = "tile245";
            this.tile245.Size = new System.Drawing.Size(32, 31);
            this.tile245.TabIndex = 292;
            this.tile245.TabStop = false;
            // 
            // tile246
            // 
            this.tile246.BackColor = System.Drawing.Color.White;
            this.tile246.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile246.Location = new System.Drawing.Point(196, 241);
            this.tile246.Name = "tile246";
            this.tile246.Size = new System.Drawing.Size(32, 31);
            this.tile246.TabIndex = 291;
            this.tile246.TabStop = false;
            // 
            // tile247
            // 
            this.tile247.BackColor = System.Drawing.Color.White;
            this.tile247.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile247.Location = new System.Drawing.Point(234, 241);
            this.tile247.Name = "tile247";
            this.tile247.Size = new System.Drawing.Size(32, 31);
            this.tile247.TabIndex = 290;
            this.tile247.TabStop = false;
            // 
            // tile248
            // 
            this.tile248.BackColor = System.Drawing.Color.White;
            this.tile248.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile248.Location = new System.Drawing.Point(272, 241);
            this.tile248.Name = "tile248";
            this.tile248.Size = new System.Drawing.Size(32, 31);
            this.tile248.TabIndex = 289;
            this.tile248.TabStop = false;
            // 
            // tile249
            // 
            this.tile249.BackColor = System.Drawing.Color.White;
            this.tile249.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile249.Location = new System.Drawing.Point(310, 241);
            this.tile249.Name = "tile249";
            this.tile249.Size = new System.Drawing.Size(32, 31);
            this.tile249.TabIndex = 288;
            this.tile249.TabStop = false;
            // 
            // tile250
            // 
            this.tile250.BackColor = System.Drawing.Color.White;
            this.tile250.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile250.Location = new System.Drawing.Point(348, 241);
            this.tile250.Name = "tile250";
            this.tile250.Size = new System.Drawing.Size(32, 31);
            this.tile250.TabIndex = 287;
            this.tile250.TabStop = false;
            // 
            // tile242
            // 
            this.tile242.BackColor = System.Drawing.Color.White;
            this.tile242.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile242.Location = new System.Drawing.Point(44, 241);
            this.tile242.Name = "tile242";
            this.tile242.Size = new System.Drawing.Size(32, 31);
            this.tile242.TabIndex = 286;
            this.tile242.TabStop = false;
            // 
            // tile241
            // 
            this.tile241.BackColor = System.Drawing.Color.White;
            this.tile241.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile241.Location = new System.Drawing.Point(6, 241);
            this.tile241.Name = "tile241";
            this.tile241.Size = new System.Drawing.Size(32, 31);
            this.tile241.TabIndex = 285;
            this.tile241.TabStop = false;
            // 
            // tile233
            // 
            this.tile233.BackColor = System.Drawing.Color.White;
            this.tile233.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile233.Location = new System.Drawing.Point(1222, 204);
            this.tile233.Name = "tile233";
            this.tile233.Size = new System.Drawing.Size(32, 31);
            this.tile233.TabIndex = 284;
            this.tile233.TabStop = false;
            // 
            // tile234
            // 
            this.tile234.BackColor = System.Drawing.Color.White;
            this.tile234.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile234.Location = new System.Drawing.Point(1260, 204);
            this.tile234.Name = "tile234";
            this.tile234.Size = new System.Drawing.Size(32, 31);
            this.tile234.TabIndex = 283;
            this.tile234.TabStop = false;
            // 
            // tile235
            // 
            this.tile235.BackColor = System.Drawing.Color.White;
            this.tile235.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile235.Location = new System.Drawing.Point(1298, 204);
            this.tile235.Name = "tile235";
            this.tile235.Size = new System.Drawing.Size(32, 31);
            this.tile235.TabIndex = 282;
            this.tile235.TabStop = false;
            // 
            // tile236
            // 
            this.tile236.BackColor = System.Drawing.Color.White;
            this.tile236.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile236.Location = new System.Drawing.Point(1336, 204);
            this.tile236.Name = "tile236";
            this.tile236.Size = new System.Drawing.Size(32, 31);
            this.tile236.TabIndex = 281;
            this.tile236.TabStop = false;
            // 
            // tile237
            // 
            this.tile237.BackColor = System.Drawing.Color.White;
            this.tile237.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile237.Location = new System.Drawing.Point(1374, 204);
            this.tile237.Name = "tile237";
            this.tile237.Size = new System.Drawing.Size(32, 31);
            this.tile237.TabIndex = 280;
            this.tile237.TabStop = false;
            // 
            // tile238
            // 
            this.tile238.BackColor = System.Drawing.Color.White;
            this.tile238.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile238.Location = new System.Drawing.Point(1412, 204);
            this.tile238.Name = "tile238";
            this.tile238.Size = new System.Drawing.Size(32, 31);
            this.tile238.TabIndex = 279;
            this.tile238.TabStop = false;
            // 
            // tile240
            // 
            this.tile240.BackColor = System.Drawing.Color.White;
            this.tile240.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile240.Location = new System.Drawing.Point(1488, 204);
            this.tile240.Name = "tile240";
            this.tile240.Size = new System.Drawing.Size(32, 31);
            this.tile240.TabIndex = 278;
            this.tile240.TabStop = false;
            // 
            // tile239
            // 
            this.tile239.BackColor = System.Drawing.Color.White;
            this.tile239.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile239.Location = new System.Drawing.Point(1450, 204);
            this.tile239.Name = "tile239";
            this.tile239.Size = new System.Drawing.Size(32, 31);
            this.tile239.TabIndex = 277;
            this.tile239.TabStop = false;
            // 
            // tile232
            // 
            this.tile232.BackColor = System.Drawing.Color.White;
            this.tile232.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile232.Location = new System.Drawing.Point(1184, 204);
            this.tile232.Name = "tile232";
            this.tile232.Size = new System.Drawing.Size(32, 31);
            this.tile232.TabIndex = 276;
            this.tile232.TabStop = false;
            // 
            // tile231
            // 
            this.tile231.BackColor = System.Drawing.Color.White;
            this.tile231.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile231.Location = new System.Drawing.Point(1146, 204);
            this.tile231.Name = "tile231";
            this.tile231.Size = new System.Drawing.Size(32, 31);
            this.tile231.TabIndex = 275;
            this.tile231.TabStop = false;
            // 
            // tile228
            // 
            this.tile228.BackColor = System.Drawing.Color.White;
            this.tile228.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile228.Location = new System.Drawing.Point(1032, 204);
            this.tile228.Name = "tile228";
            this.tile228.Size = new System.Drawing.Size(32, 31);
            this.tile228.TabIndex = 274;
            this.tile228.TabStop = false;
            // 
            // tile227
            // 
            this.tile227.BackColor = System.Drawing.Color.White;
            this.tile227.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile227.Location = new System.Drawing.Point(994, 204);
            this.tile227.Name = "tile227";
            this.tile227.Size = new System.Drawing.Size(32, 31);
            this.tile227.TabIndex = 273;
            this.tile227.TabStop = false;
            // 
            // tile226
            // 
            this.tile226.BackColor = System.Drawing.Color.White;
            this.tile226.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile226.Location = new System.Drawing.Point(956, 204);
            this.tile226.Name = "tile226";
            this.tile226.Size = new System.Drawing.Size(32, 31);
            this.tile226.TabIndex = 272;
            this.tile226.TabStop = false;
            // 
            // tile225
            // 
            this.tile225.BackColor = System.Drawing.Color.White;
            this.tile225.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile225.Location = new System.Drawing.Point(918, 204);
            this.tile225.Name = "tile225";
            this.tile225.Size = new System.Drawing.Size(32, 31);
            this.tile225.TabIndex = 271;
            this.tile225.TabStop = false;
            // 
            // tile224
            // 
            this.tile224.BackColor = System.Drawing.Color.White;
            this.tile224.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile224.Location = new System.Drawing.Point(880, 204);
            this.tile224.Name = "tile224";
            this.tile224.Size = new System.Drawing.Size(32, 31);
            this.tile224.TabIndex = 270;
            this.tile224.TabStop = false;
            // 
            // tile223
            // 
            this.tile223.BackColor = System.Drawing.Color.White;
            this.tile223.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile223.Location = new System.Drawing.Point(842, 204);
            this.tile223.Name = "tile223";
            this.tile223.Size = new System.Drawing.Size(32, 31);
            this.tile223.TabIndex = 269;
            this.tile223.TabStop = false;
            // 
            // tile221
            // 
            this.tile221.BackColor = System.Drawing.Color.White;
            this.tile221.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile221.Location = new System.Drawing.Point(766, 204);
            this.tile221.Name = "tile221";
            this.tile221.Size = new System.Drawing.Size(32, 31);
            this.tile221.TabIndex = 268;
            this.tile221.TabStop = false;
            // 
            // tile222
            // 
            this.tile222.BackColor = System.Drawing.Color.White;
            this.tile222.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile222.Location = new System.Drawing.Point(804, 204);
            this.tile222.Name = "tile222";
            this.tile222.Size = new System.Drawing.Size(32, 31);
            this.tile222.TabIndex = 267;
            this.tile222.TabStop = false;
            // 
            // tile229
            // 
            this.tile229.BackColor = System.Drawing.Color.White;
            this.tile229.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile229.Location = new System.Drawing.Point(1070, 204);
            this.tile229.Name = "tile229";
            this.tile229.Size = new System.Drawing.Size(32, 31);
            this.tile229.TabIndex = 266;
            this.tile229.TabStop = false;
            // 
            // tile230
            // 
            this.tile230.BackColor = System.Drawing.Color.White;
            this.tile230.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile230.Location = new System.Drawing.Point(1108, 204);
            this.tile230.Name = "tile230";
            this.tile230.Size = new System.Drawing.Size(32, 31);
            this.tile230.TabIndex = 265;
            this.tile230.TabStop = false;
            // 
            // tile213
            // 
            this.tile213.BackColor = System.Drawing.Color.White;
            this.tile213.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile213.Location = new System.Drawing.Point(462, 204);
            this.tile213.Name = "tile213";
            this.tile213.Size = new System.Drawing.Size(32, 31);
            this.tile213.TabIndex = 264;
            this.tile213.TabStop = false;
            // 
            // tile214
            // 
            this.tile214.BackColor = System.Drawing.Color.White;
            this.tile214.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile214.Location = new System.Drawing.Point(500, 204);
            this.tile214.Name = "tile214";
            this.tile214.Size = new System.Drawing.Size(32, 31);
            this.tile214.TabIndex = 263;
            this.tile214.TabStop = false;
            // 
            // tile215
            // 
            this.tile215.BackColor = System.Drawing.Color.White;
            this.tile215.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile215.Location = new System.Drawing.Point(538, 204);
            this.tile215.Name = "tile215";
            this.tile215.Size = new System.Drawing.Size(32, 31);
            this.tile215.TabIndex = 262;
            this.tile215.TabStop = false;
            // 
            // tile216
            // 
            this.tile216.BackColor = System.Drawing.Color.White;
            this.tile216.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile216.Location = new System.Drawing.Point(576, 204);
            this.tile216.Name = "tile216";
            this.tile216.Size = new System.Drawing.Size(32, 31);
            this.tile216.TabIndex = 261;
            this.tile216.TabStop = false;
            // 
            // tile217
            // 
            this.tile217.BackColor = System.Drawing.Color.White;
            this.tile217.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile217.Location = new System.Drawing.Point(614, 204);
            this.tile217.Name = "tile217";
            this.tile217.Size = new System.Drawing.Size(32, 31);
            this.tile217.TabIndex = 260;
            this.tile217.TabStop = false;
            // 
            // tile218
            // 
            this.tile218.BackColor = System.Drawing.Color.White;
            this.tile218.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile218.Location = new System.Drawing.Point(652, 204);
            this.tile218.Name = "tile218";
            this.tile218.Size = new System.Drawing.Size(32, 31);
            this.tile218.TabIndex = 259;
            this.tile218.TabStop = false;
            // 
            // tile219
            // 
            this.tile219.BackColor = System.Drawing.Color.White;
            this.tile219.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile219.Location = new System.Drawing.Point(690, 204);
            this.tile219.Name = "tile219";
            this.tile219.Size = new System.Drawing.Size(32, 31);
            this.tile219.TabIndex = 258;
            this.tile219.TabStop = false;
            // 
            // tile220
            // 
            this.tile220.BackColor = System.Drawing.Color.White;
            this.tile220.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile220.Location = new System.Drawing.Point(728, 204);
            this.tile220.Name = "tile220";
            this.tile220.Size = new System.Drawing.Size(32, 31);
            this.tile220.TabIndex = 257;
            this.tile220.TabStop = false;
            this.tile220.Click += new System.EventHandler(this.pictureBox390_Click);
            // 
            // tile212
            // 
            this.tile212.BackColor = System.Drawing.Color.White;
            this.tile212.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile212.Location = new System.Drawing.Point(424, 204);
            this.tile212.Name = "tile212";
            this.tile212.Size = new System.Drawing.Size(32, 31);
            this.tile212.TabIndex = 256;
            this.tile212.TabStop = false;
            // 
            // tile211
            // 
            this.tile211.BackColor = System.Drawing.Color.White;
            this.tile211.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile211.Location = new System.Drawing.Point(386, 204);
            this.tile211.Name = "tile211";
            this.tile211.Size = new System.Drawing.Size(32, 31);
            this.tile211.TabIndex = 255;
            this.tile211.TabStop = false;
            // 
            // tile203
            // 
            this.tile203.BackColor = System.Drawing.Color.White;
            this.tile203.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile203.Location = new System.Drawing.Point(82, 204);
            this.tile203.Name = "tile203";
            this.tile203.Size = new System.Drawing.Size(32, 31);
            this.tile203.TabIndex = 254;
            this.tile203.TabStop = false;
            // 
            // tile204
            // 
            this.tile204.BackColor = System.Drawing.Color.White;
            this.tile204.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile204.Location = new System.Drawing.Point(120, 204);
            this.tile204.Name = "tile204";
            this.tile204.Size = new System.Drawing.Size(32, 31);
            this.tile204.TabIndex = 253;
            this.tile204.TabStop = false;
            // 
            // tile205
            // 
            this.tile205.BackColor = System.Drawing.Color.White;
            this.tile205.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile205.Location = new System.Drawing.Point(158, 204);
            this.tile205.Name = "tile205";
            this.tile205.Size = new System.Drawing.Size(32, 31);
            this.tile205.TabIndex = 252;
            this.tile205.TabStop = false;
            // 
            // tile206
            // 
            this.tile206.BackColor = System.Drawing.Color.White;
            this.tile206.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile206.Location = new System.Drawing.Point(196, 204);
            this.tile206.Name = "tile206";
            this.tile206.Size = new System.Drawing.Size(32, 31);
            this.tile206.TabIndex = 251;
            this.tile206.TabStop = false;
            // 
            // tile207
            // 
            this.tile207.BackColor = System.Drawing.Color.White;
            this.tile207.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile207.Location = new System.Drawing.Point(234, 204);
            this.tile207.Name = "tile207";
            this.tile207.Size = new System.Drawing.Size(32, 31);
            this.tile207.TabIndex = 250;
            this.tile207.TabStop = false;
            // 
            // tile208
            // 
            this.tile208.BackColor = System.Drawing.Color.White;
            this.tile208.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile208.Location = new System.Drawing.Point(272, 204);
            this.tile208.Name = "tile208";
            this.tile208.Size = new System.Drawing.Size(32, 31);
            this.tile208.TabIndex = 249;
            this.tile208.TabStop = false;
            // 
            // tile209
            // 
            this.tile209.BackColor = System.Drawing.Color.White;
            this.tile209.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile209.Location = new System.Drawing.Point(310, 204);
            this.tile209.Name = "tile209";
            this.tile209.Size = new System.Drawing.Size(32, 31);
            this.tile209.TabIndex = 248;
            this.tile209.TabStop = false;
            // 
            // tile210
            // 
            this.tile210.BackColor = System.Drawing.Color.White;
            this.tile210.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile210.Location = new System.Drawing.Point(348, 204);
            this.tile210.Name = "tile210";
            this.tile210.Size = new System.Drawing.Size(32, 31);
            this.tile210.TabIndex = 247;
            this.tile210.TabStop = false;
            // 
            // tile202
            // 
            this.tile202.BackColor = System.Drawing.Color.White;
            this.tile202.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile202.Location = new System.Drawing.Point(44, 204);
            this.tile202.Name = "tile202";
            this.tile202.Size = new System.Drawing.Size(32, 31);
            this.tile202.TabIndex = 246;
            this.tile202.TabStop = false;
            // 
            // tile201
            // 
            this.tile201.BackColor = System.Drawing.Color.White;
            this.tile201.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile201.Location = new System.Drawing.Point(6, 204);
            this.tile201.Name = "tile201";
            this.tile201.Size = new System.Drawing.Size(32, 31);
            this.tile201.TabIndex = 245;
            this.tile201.TabStop = false;
            // 
            // tile193
            // 
            this.tile193.BackColor = System.Drawing.Color.White;
            this.tile193.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile193.Location = new System.Drawing.Point(1222, 167);
            this.tile193.Name = "tile193";
            this.tile193.Size = new System.Drawing.Size(32, 31);
            this.tile193.TabIndex = 244;
            this.tile193.TabStop = false;
            // 
            // tile194
            // 
            this.tile194.BackColor = System.Drawing.Color.White;
            this.tile194.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile194.Location = new System.Drawing.Point(1260, 167);
            this.tile194.Name = "tile194";
            this.tile194.Size = new System.Drawing.Size(32, 31);
            this.tile194.TabIndex = 243;
            this.tile194.TabStop = false;
            // 
            // tile195
            // 
            this.tile195.BackColor = System.Drawing.Color.White;
            this.tile195.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile195.Location = new System.Drawing.Point(1298, 167);
            this.tile195.Name = "tile195";
            this.tile195.Size = new System.Drawing.Size(32, 31);
            this.tile195.TabIndex = 242;
            this.tile195.TabStop = false;
            // 
            // tile196
            // 
            this.tile196.BackColor = System.Drawing.Color.White;
            this.tile196.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile196.Location = new System.Drawing.Point(1336, 167);
            this.tile196.Name = "tile196";
            this.tile196.Size = new System.Drawing.Size(32, 31);
            this.tile196.TabIndex = 241;
            this.tile196.TabStop = false;
            // 
            // tile197
            // 
            this.tile197.BackColor = System.Drawing.Color.White;
            this.tile197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile197.Location = new System.Drawing.Point(1374, 167);
            this.tile197.Name = "tile197";
            this.tile197.Size = new System.Drawing.Size(32, 31);
            this.tile197.TabIndex = 240;
            this.tile197.TabStop = false;
            // 
            // tile198
            // 
            this.tile198.BackColor = System.Drawing.Color.White;
            this.tile198.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile198.Location = new System.Drawing.Point(1412, 167);
            this.tile198.Name = "tile198";
            this.tile198.Size = new System.Drawing.Size(32, 31);
            this.tile198.TabIndex = 239;
            this.tile198.TabStop = false;
            // 
            // tile200
            // 
            this.tile200.BackColor = System.Drawing.Color.White;
            this.tile200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile200.Location = new System.Drawing.Point(1488, 167);
            this.tile200.Name = "tile200";
            this.tile200.Size = new System.Drawing.Size(32, 31);
            this.tile200.TabIndex = 238;
            this.tile200.TabStop = false;
            // 
            // tile199
            // 
            this.tile199.BackColor = System.Drawing.Color.White;
            this.tile199.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile199.Location = new System.Drawing.Point(1450, 167);
            this.tile199.Name = "tile199";
            this.tile199.Size = new System.Drawing.Size(32, 31);
            this.tile199.TabIndex = 237;
            this.tile199.TabStop = false;
            // 
            // tile192
            // 
            this.tile192.BackColor = System.Drawing.Color.White;
            this.tile192.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile192.Location = new System.Drawing.Point(1184, 167);
            this.tile192.Name = "tile192";
            this.tile192.Size = new System.Drawing.Size(32, 31);
            this.tile192.TabIndex = 236;
            this.tile192.TabStop = false;
            // 
            // tile191
            // 
            this.tile191.BackColor = System.Drawing.Color.White;
            this.tile191.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile191.Location = new System.Drawing.Point(1146, 167);
            this.tile191.Name = "tile191";
            this.tile191.Size = new System.Drawing.Size(32, 31);
            this.tile191.TabIndex = 235;
            this.tile191.TabStop = false;
            // 
            // tile188
            // 
            this.tile188.BackColor = System.Drawing.Color.White;
            this.tile188.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile188.Location = new System.Drawing.Point(1032, 167);
            this.tile188.Name = "tile188";
            this.tile188.Size = new System.Drawing.Size(32, 31);
            this.tile188.TabIndex = 234;
            this.tile188.TabStop = false;
            // 
            // tile187
            // 
            this.tile187.BackColor = System.Drawing.Color.White;
            this.tile187.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile187.Location = new System.Drawing.Point(994, 167);
            this.tile187.Name = "tile187";
            this.tile187.Size = new System.Drawing.Size(32, 31);
            this.tile187.TabIndex = 233;
            this.tile187.TabStop = false;
            // 
            // tile186
            // 
            this.tile186.BackColor = System.Drawing.Color.White;
            this.tile186.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile186.Location = new System.Drawing.Point(956, 167);
            this.tile186.Name = "tile186";
            this.tile186.Size = new System.Drawing.Size(32, 31);
            this.tile186.TabIndex = 232;
            this.tile186.TabStop = false;
            // 
            // tile185
            // 
            this.tile185.BackColor = System.Drawing.Color.White;
            this.tile185.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile185.Location = new System.Drawing.Point(918, 167);
            this.tile185.Name = "tile185";
            this.tile185.Size = new System.Drawing.Size(32, 31);
            this.tile185.TabIndex = 231;
            this.tile185.TabStop = false;
            // 
            // tile184
            // 
            this.tile184.BackColor = System.Drawing.Color.White;
            this.tile184.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile184.Location = new System.Drawing.Point(880, 167);
            this.tile184.Name = "tile184";
            this.tile184.Size = new System.Drawing.Size(32, 31);
            this.tile184.TabIndex = 230;
            this.tile184.TabStop = false;
            // 
            // tile183
            // 
            this.tile183.BackColor = System.Drawing.Color.White;
            this.tile183.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile183.Location = new System.Drawing.Point(842, 167);
            this.tile183.Name = "tile183";
            this.tile183.Size = new System.Drawing.Size(32, 31);
            this.tile183.TabIndex = 229;
            this.tile183.TabStop = false;
            // 
            // tile181
            // 
            this.tile181.BackColor = System.Drawing.Color.White;
            this.tile181.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile181.Location = new System.Drawing.Point(766, 167);
            this.tile181.Name = "tile181";
            this.tile181.Size = new System.Drawing.Size(32, 31);
            this.tile181.TabIndex = 228;
            this.tile181.TabStop = false;
            // 
            // tile182
            // 
            this.tile182.BackColor = System.Drawing.Color.White;
            this.tile182.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile182.Location = new System.Drawing.Point(804, 167);
            this.tile182.Name = "tile182";
            this.tile182.Size = new System.Drawing.Size(32, 31);
            this.tile182.TabIndex = 227;
            this.tile182.TabStop = false;
            // 
            // tile189
            // 
            this.tile189.BackColor = System.Drawing.Color.White;
            this.tile189.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile189.Location = new System.Drawing.Point(1070, 167);
            this.tile189.Name = "tile189";
            this.tile189.Size = new System.Drawing.Size(32, 31);
            this.tile189.TabIndex = 226;
            this.tile189.TabStop = false;
            // 
            // tile190
            // 
            this.tile190.BackColor = System.Drawing.Color.White;
            this.tile190.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile190.Location = new System.Drawing.Point(1108, 167);
            this.tile190.Name = "tile190";
            this.tile190.Size = new System.Drawing.Size(32, 31);
            this.tile190.TabIndex = 225;
            this.tile190.TabStop = false;
            // 
            // tile173
            // 
            this.tile173.BackColor = System.Drawing.Color.White;
            this.tile173.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile173.Location = new System.Drawing.Point(462, 167);
            this.tile173.Name = "tile173";
            this.tile173.Size = new System.Drawing.Size(32, 31);
            this.tile173.TabIndex = 224;
            this.tile173.TabStop = false;
            // 
            // tile174
            // 
            this.tile174.BackColor = System.Drawing.Color.White;
            this.tile174.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile174.Location = new System.Drawing.Point(500, 167);
            this.tile174.Name = "tile174";
            this.tile174.Size = new System.Drawing.Size(32, 31);
            this.tile174.TabIndex = 223;
            this.tile174.TabStop = false;
            // 
            // tile175
            // 
            this.tile175.BackColor = System.Drawing.Color.White;
            this.tile175.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile175.Location = new System.Drawing.Point(538, 167);
            this.tile175.Name = "tile175";
            this.tile175.Size = new System.Drawing.Size(32, 31);
            this.tile175.TabIndex = 222;
            this.tile175.TabStop = false;
            // 
            // tile176
            // 
            this.tile176.BackColor = System.Drawing.Color.White;
            this.tile176.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile176.Location = new System.Drawing.Point(576, 167);
            this.tile176.Name = "tile176";
            this.tile176.Size = new System.Drawing.Size(32, 31);
            this.tile176.TabIndex = 221;
            this.tile176.TabStop = false;
            // 
            // tile177
            // 
            this.tile177.BackColor = System.Drawing.Color.White;
            this.tile177.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile177.Location = new System.Drawing.Point(614, 167);
            this.tile177.Name = "tile177";
            this.tile177.Size = new System.Drawing.Size(32, 31);
            this.tile177.TabIndex = 220;
            this.tile177.TabStop = false;
            // 
            // tile178
            // 
            this.tile178.BackColor = System.Drawing.Color.White;
            this.tile178.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile178.Location = new System.Drawing.Point(652, 167);
            this.tile178.Name = "tile178";
            this.tile178.Size = new System.Drawing.Size(32, 31);
            this.tile178.TabIndex = 219;
            this.tile178.TabStop = false;
            // 
            // tile179
            // 
            this.tile179.BackColor = System.Drawing.Color.White;
            this.tile179.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile179.Location = new System.Drawing.Point(690, 167);
            this.tile179.Name = "tile179";
            this.tile179.Size = new System.Drawing.Size(32, 31);
            this.tile179.TabIndex = 218;
            this.tile179.TabStop = false;
            // 
            // tile180
            // 
            this.tile180.BackColor = System.Drawing.Color.White;
            this.tile180.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile180.Location = new System.Drawing.Point(728, 167);
            this.tile180.Name = "tile180";
            this.tile180.Size = new System.Drawing.Size(32, 31);
            this.tile180.TabIndex = 217;
            this.tile180.TabStop = false;
            // 
            // tile172
            // 
            this.tile172.BackColor = System.Drawing.Color.White;
            this.tile172.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile172.Location = new System.Drawing.Point(424, 167);
            this.tile172.Name = "tile172";
            this.tile172.Size = new System.Drawing.Size(32, 31);
            this.tile172.TabIndex = 216;
            this.tile172.TabStop = false;
            // 
            // tile171
            // 
            this.tile171.BackColor = System.Drawing.Color.White;
            this.tile171.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile171.Location = new System.Drawing.Point(386, 167);
            this.tile171.Name = "tile171";
            this.tile171.Size = new System.Drawing.Size(32, 31);
            this.tile171.TabIndex = 215;
            this.tile171.TabStop = false;
            // 
            // tile163
            // 
            this.tile163.BackColor = System.Drawing.Color.White;
            this.tile163.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile163.Location = new System.Drawing.Point(82, 167);
            this.tile163.Name = "tile163";
            this.tile163.Size = new System.Drawing.Size(32, 31);
            this.tile163.TabIndex = 214;
            this.tile163.TabStop = false;
            // 
            // tile164
            // 
            this.tile164.BackColor = System.Drawing.Color.White;
            this.tile164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile164.Location = new System.Drawing.Point(120, 167);
            this.tile164.Name = "tile164";
            this.tile164.Size = new System.Drawing.Size(32, 31);
            this.tile164.TabIndex = 213;
            this.tile164.TabStop = false;
            // 
            // tile165
            // 
            this.tile165.BackColor = System.Drawing.Color.White;
            this.tile165.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile165.Location = new System.Drawing.Point(158, 167);
            this.tile165.Name = "tile165";
            this.tile165.Size = new System.Drawing.Size(32, 31);
            this.tile165.TabIndex = 212;
            this.tile165.TabStop = false;
            // 
            // tile166
            // 
            this.tile166.BackColor = System.Drawing.Color.White;
            this.tile166.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile166.Location = new System.Drawing.Point(196, 167);
            this.tile166.Name = "tile166";
            this.tile166.Size = new System.Drawing.Size(32, 31);
            this.tile166.TabIndex = 211;
            this.tile166.TabStop = false;
            // 
            // tile167
            // 
            this.tile167.BackColor = System.Drawing.Color.White;
            this.tile167.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile167.Location = new System.Drawing.Point(234, 167);
            this.tile167.Name = "tile167";
            this.tile167.Size = new System.Drawing.Size(32, 31);
            this.tile167.TabIndex = 210;
            this.tile167.TabStop = false;
            // 
            // tile168
            // 
            this.tile168.BackColor = System.Drawing.Color.White;
            this.tile168.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile168.Location = new System.Drawing.Point(272, 167);
            this.tile168.Name = "tile168";
            this.tile168.Size = new System.Drawing.Size(32, 31);
            this.tile168.TabIndex = 209;
            this.tile168.TabStop = false;
            // 
            // tile169
            // 
            this.tile169.BackColor = System.Drawing.Color.White;
            this.tile169.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile169.Location = new System.Drawing.Point(310, 167);
            this.tile169.Name = "tile169";
            this.tile169.Size = new System.Drawing.Size(32, 31);
            this.tile169.TabIndex = 208;
            this.tile169.TabStop = false;
            // 
            // tile170
            // 
            this.tile170.BackColor = System.Drawing.Color.White;
            this.tile170.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile170.Location = new System.Drawing.Point(348, 167);
            this.tile170.Name = "tile170";
            this.tile170.Size = new System.Drawing.Size(32, 31);
            this.tile170.TabIndex = 207;
            this.tile170.TabStop = false;
            // 
            // tile162
            // 
            this.tile162.BackColor = System.Drawing.Color.White;
            this.tile162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile162.Location = new System.Drawing.Point(44, 167);
            this.tile162.Name = "tile162";
            this.tile162.Size = new System.Drawing.Size(32, 31);
            this.tile162.TabIndex = 206;
            this.tile162.TabStop = false;
            // 
            // tile161
            // 
            this.tile161.BackColor = System.Drawing.Color.White;
            this.tile161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile161.Location = new System.Drawing.Point(6, 167);
            this.tile161.Name = "tile161";
            this.tile161.Size = new System.Drawing.Size(32, 31);
            this.tile161.TabIndex = 205;
            this.tile161.TabStop = false;
            // 
            // tile153
            // 
            this.tile153.BackColor = System.Drawing.Color.White;
            this.tile153.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile153.Location = new System.Drawing.Point(1222, 130);
            this.tile153.Name = "tile153";
            this.tile153.Size = new System.Drawing.Size(32, 31);
            this.tile153.TabIndex = 204;
            this.tile153.TabStop = false;
            // 
            // tile154
            // 
            this.tile154.BackColor = System.Drawing.Color.White;
            this.tile154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile154.Location = new System.Drawing.Point(1260, 130);
            this.tile154.Name = "tile154";
            this.tile154.Size = new System.Drawing.Size(32, 31);
            this.tile154.TabIndex = 203;
            this.tile154.TabStop = false;
            // 
            // tile155
            // 
            this.tile155.BackColor = System.Drawing.Color.White;
            this.tile155.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile155.Location = new System.Drawing.Point(1298, 130);
            this.tile155.Name = "tile155";
            this.tile155.Size = new System.Drawing.Size(32, 31);
            this.tile155.TabIndex = 202;
            this.tile155.TabStop = false;
            // 
            // tile156
            // 
            this.tile156.BackColor = System.Drawing.Color.White;
            this.tile156.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile156.Location = new System.Drawing.Point(1336, 130);
            this.tile156.Name = "tile156";
            this.tile156.Size = new System.Drawing.Size(32, 31);
            this.tile156.TabIndex = 201;
            this.tile156.TabStop = false;
            // 
            // tile157
            // 
            this.tile157.BackColor = System.Drawing.Color.White;
            this.tile157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile157.Location = new System.Drawing.Point(1374, 130);
            this.tile157.Name = "tile157";
            this.tile157.Size = new System.Drawing.Size(32, 31);
            this.tile157.TabIndex = 200;
            this.tile157.TabStop = false;
            // 
            // tile158
            // 
            this.tile158.BackColor = System.Drawing.Color.White;
            this.tile158.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile158.Location = new System.Drawing.Point(1412, 130);
            this.tile158.Name = "tile158";
            this.tile158.Size = new System.Drawing.Size(32, 31);
            this.tile158.TabIndex = 199;
            this.tile158.TabStop = false;
            // 
            // tile160
            // 
            this.tile160.BackColor = System.Drawing.Color.White;
            this.tile160.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile160.Location = new System.Drawing.Point(1488, 130);
            this.tile160.Name = "tile160";
            this.tile160.Size = new System.Drawing.Size(32, 31);
            this.tile160.TabIndex = 198;
            this.tile160.TabStop = false;
            // 
            // tile159
            // 
            this.tile159.BackColor = System.Drawing.Color.White;
            this.tile159.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile159.Location = new System.Drawing.Point(1450, 130);
            this.tile159.Name = "tile159";
            this.tile159.Size = new System.Drawing.Size(32, 31);
            this.tile159.TabIndex = 197;
            this.tile159.TabStop = false;
            // 
            // tile152
            // 
            this.tile152.BackColor = System.Drawing.Color.White;
            this.tile152.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile152.Location = new System.Drawing.Point(1184, 130);
            this.tile152.Name = "tile152";
            this.tile152.Size = new System.Drawing.Size(32, 31);
            this.tile152.TabIndex = 196;
            this.tile152.TabStop = false;
            // 
            // tile151
            // 
            this.tile151.BackColor = System.Drawing.Color.White;
            this.tile151.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile151.Location = new System.Drawing.Point(1146, 130);
            this.tile151.Name = "tile151";
            this.tile151.Size = new System.Drawing.Size(32, 31);
            this.tile151.TabIndex = 195;
            this.tile151.TabStop = false;
            // 
            // tile148
            // 
            this.tile148.BackColor = System.Drawing.Color.White;
            this.tile148.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile148.Location = new System.Drawing.Point(1032, 130);
            this.tile148.Name = "tile148";
            this.tile148.Size = new System.Drawing.Size(32, 31);
            this.tile148.TabIndex = 194;
            this.tile148.TabStop = false;
            // 
            // tile147
            // 
            this.tile147.BackColor = System.Drawing.Color.White;
            this.tile147.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile147.Location = new System.Drawing.Point(994, 130);
            this.tile147.Name = "tile147";
            this.tile147.Size = new System.Drawing.Size(32, 31);
            this.tile147.TabIndex = 193;
            this.tile147.TabStop = false;
            // 
            // tile146
            // 
            this.tile146.BackColor = System.Drawing.Color.White;
            this.tile146.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile146.Location = new System.Drawing.Point(956, 130);
            this.tile146.Name = "tile146";
            this.tile146.Size = new System.Drawing.Size(32, 31);
            this.tile146.TabIndex = 192;
            this.tile146.TabStop = false;
            // 
            // tile145
            // 
            this.tile145.BackColor = System.Drawing.Color.White;
            this.tile145.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile145.Location = new System.Drawing.Point(918, 130);
            this.tile145.Name = "tile145";
            this.tile145.Size = new System.Drawing.Size(32, 31);
            this.tile145.TabIndex = 191;
            this.tile145.TabStop = false;
            // 
            // tile144
            // 
            this.tile144.BackColor = System.Drawing.Color.White;
            this.tile144.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile144.Location = new System.Drawing.Point(880, 130);
            this.tile144.Name = "tile144";
            this.tile144.Size = new System.Drawing.Size(32, 31);
            this.tile144.TabIndex = 190;
            this.tile144.TabStop = false;
            // 
            // tile143
            // 
            this.tile143.BackColor = System.Drawing.Color.White;
            this.tile143.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile143.Location = new System.Drawing.Point(842, 130);
            this.tile143.Name = "tile143";
            this.tile143.Size = new System.Drawing.Size(32, 31);
            this.tile143.TabIndex = 189;
            this.tile143.TabStop = false;
            // 
            // tile141
            // 
            this.tile141.BackColor = System.Drawing.Color.White;
            this.tile141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile141.Location = new System.Drawing.Point(766, 130);
            this.tile141.Name = "tile141";
            this.tile141.Size = new System.Drawing.Size(32, 31);
            this.tile141.TabIndex = 188;
            this.tile141.TabStop = false;
            // 
            // tile142
            // 
            this.tile142.BackColor = System.Drawing.Color.White;
            this.tile142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile142.Location = new System.Drawing.Point(804, 130);
            this.tile142.Name = "tile142";
            this.tile142.Size = new System.Drawing.Size(32, 31);
            this.tile142.TabIndex = 187;
            this.tile142.TabStop = false;
            // 
            // tile149
            // 
            this.tile149.BackColor = System.Drawing.Color.White;
            this.tile149.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile149.Location = new System.Drawing.Point(1070, 130);
            this.tile149.Name = "tile149";
            this.tile149.Size = new System.Drawing.Size(32, 31);
            this.tile149.TabIndex = 186;
            this.tile149.TabStop = false;
            // 
            // tile150
            // 
            this.tile150.BackColor = System.Drawing.Color.White;
            this.tile150.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile150.Location = new System.Drawing.Point(1108, 130);
            this.tile150.Name = "tile150";
            this.tile150.Size = new System.Drawing.Size(32, 31);
            this.tile150.TabIndex = 185;
            this.tile150.TabStop = false;
            // 
            // tile133
            // 
            this.tile133.BackColor = System.Drawing.Color.White;
            this.tile133.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile133.Location = new System.Drawing.Point(462, 130);
            this.tile133.Name = "tile133";
            this.tile133.Size = new System.Drawing.Size(32, 31);
            this.tile133.TabIndex = 184;
            this.tile133.TabStop = false;
            // 
            // tile134
            // 
            this.tile134.BackColor = System.Drawing.Color.White;
            this.tile134.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile134.Location = new System.Drawing.Point(500, 130);
            this.tile134.Name = "tile134";
            this.tile134.Size = new System.Drawing.Size(32, 31);
            this.tile134.TabIndex = 183;
            this.tile134.TabStop = false;
            // 
            // tile135
            // 
            this.tile135.BackColor = System.Drawing.Color.White;
            this.tile135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile135.Location = new System.Drawing.Point(538, 130);
            this.tile135.Name = "tile135";
            this.tile135.Size = new System.Drawing.Size(32, 31);
            this.tile135.TabIndex = 182;
            this.tile135.TabStop = false;
            // 
            // tile136
            // 
            this.tile136.BackColor = System.Drawing.Color.White;
            this.tile136.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile136.Location = new System.Drawing.Point(576, 130);
            this.tile136.Name = "tile136";
            this.tile136.Size = new System.Drawing.Size(32, 31);
            this.tile136.TabIndex = 181;
            this.tile136.TabStop = false;
            // 
            // tile137
            // 
            this.tile137.BackColor = System.Drawing.Color.White;
            this.tile137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile137.Location = new System.Drawing.Point(614, 130);
            this.tile137.Name = "tile137";
            this.tile137.Size = new System.Drawing.Size(32, 31);
            this.tile137.TabIndex = 180;
            this.tile137.TabStop = false;
            // 
            // tile138
            // 
            this.tile138.BackColor = System.Drawing.Color.White;
            this.tile138.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile138.Location = new System.Drawing.Point(652, 130);
            this.tile138.Name = "tile138";
            this.tile138.Size = new System.Drawing.Size(32, 31);
            this.tile138.TabIndex = 179;
            this.tile138.TabStop = false;
            // 
            // tile139
            // 
            this.tile139.BackColor = System.Drawing.Color.White;
            this.tile139.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile139.Location = new System.Drawing.Point(690, 130);
            this.tile139.Name = "tile139";
            this.tile139.Size = new System.Drawing.Size(32, 31);
            this.tile139.TabIndex = 178;
            this.tile139.TabStop = false;
            // 
            // tile140
            // 
            this.tile140.BackColor = System.Drawing.Color.White;
            this.tile140.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile140.Location = new System.Drawing.Point(728, 130);
            this.tile140.Name = "tile140";
            this.tile140.Size = new System.Drawing.Size(32, 31);
            this.tile140.TabIndex = 177;
            this.tile140.TabStop = false;
            // 
            // tile132
            // 
            this.tile132.BackColor = System.Drawing.Color.White;
            this.tile132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile132.Location = new System.Drawing.Point(424, 130);
            this.tile132.Name = "tile132";
            this.tile132.Size = new System.Drawing.Size(32, 31);
            this.tile132.TabIndex = 176;
            this.tile132.TabStop = false;
            // 
            // tile131
            // 
            this.tile131.BackColor = System.Drawing.Color.White;
            this.tile131.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile131.Location = new System.Drawing.Point(386, 130);
            this.tile131.Name = "tile131";
            this.tile131.Size = new System.Drawing.Size(32, 31);
            this.tile131.TabIndex = 175;
            this.tile131.TabStop = false;
            // 
            // tile123
            // 
            this.tile123.BackColor = System.Drawing.Color.White;
            this.tile123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile123.Location = new System.Drawing.Point(82, 130);
            this.tile123.Name = "tile123";
            this.tile123.Size = new System.Drawing.Size(32, 31);
            this.tile123.TabIndex = 174;
            this.tile123.TabStop = false;
            // 
            // tile124
            // 
            this.tile124.BackColor = System.Drawing.Color.White;
            this.tile124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile124.Location = new System.Drawing.Point(120, 130);
            this.tile124.Name = "tile124";
            this.tile124.Size = new System.Drawing.Size(32, 31);
            this.tile124.TabIndex = 173;
            this.tile124.TabStop = false;
            // 
            // tile125
            // 
            this.tile125.BackColor = System.Drawing.Color.White;
            this.tile125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile125.Location = new System.Drawing.Point(158, 130);
            this.tile125.Name = "tile125";
            this.tile125.Size = new System.Drawing.Size(32, 31);
            this.tile125.TabIndex = 172;
            this.tile125.TabStop = false;
            // 
            // tile126
            // 
            this.tile126.BackColor = System.Drawing.Color.White;
            this.tile126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile126.Location = new System.Drawing.Point(196, 130);
            this.tile126.Name = "tile126";
            this.tile126.Size = new System.Drawing.Size(32, 31);
            this.tile126.TabIndex = 171;
            this.tile126.TabStop = false;
            // 
            // tile127
            // 
            this.tile127.BackColor = System.Drawing.Color.White;
            this.tile127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile127.Location = new System.Drawing.Point(234, 130);
            this.tile127.Name = "tile127";
            this.tile127.Size = new System.Drawing.Size(32, 31);
            this.tile127.TabIndex = 170;
            this.tile127.TabStop = false;
            // 
            // tile128
            // 
            this.tile128.BackColor = System.Drawing.Color.White;
            this.tile128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile128.Location = new System.Drawing.Point(272, 130);
            this.tile128.Name = "tile128";
            this.tile128.Size = new System.Drawing.Size(32, 31);
            this.tile128.TabIndex = 169;
            this.tile128.TabStop = false;
            // 
            // tile129
            // 
            this.tile129.BackColor = System.Drawing.Color.White;
            this.tile129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile129.Location = new System.Drawing.Point(310, 130);
            this.tile129.Name = "tile129";
            this.tile129.Size = new System.Drawing.Size(32, 31);
            this.tile129.TabIndex = 168;
            this.tile129.TabStop = false;
            // 
            // tile130
            // 
            this.tile130.BackColor = System.Drawing.Color.White;
            this.tile130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile130.Location = new System.Drawing.Point(348, 130);
            this.tile130.Name = "tile130";
            this.tile130.Size = new System.Drawing.Size(32, 31);
            this.tile130.TabIndex = 167;
            this.tile130.TabStop = false;
            // 
            // tile122
            // 
            this.tile122.BackColor = System.Drawing.Color.White;
            this.tile122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile122.Location = new System.Drawing.Point(44, 130);
            this.tile122.Name = "tile122";
            this.tile122.Size = new System.Drawing.Size(32, 31);
            this.tile122.TabIndex = 166;
            this.tile122.TabStop = false;
            // 
            // tile121
            // 
            this.tile121.BackColor = System.Drawing.Color.White;
            this.tile121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile121.Location = new System.Drawing.Point(6, 130);
            this.tile121.Name = "tile121";
            this.tile121.Size = new System.Drawing.Size(32, 31);
            this.tile121.TabIndex = 165;
            this.tile121.TabStop = false;
            // 
            // tile113
            // 
            this.tile113.BackColor = System.Drawing.Color.White;
            this.tile113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile113.Location = new System.Drawing.Point(1222, 93);
            this.tile113.Name = "tile113";
            this.tile113.Size = new System.Drawing.Size(32, 31);
            this.tile113.TabIndex = 164;
            this.tile113.TabStop = false;
            // 
            // tile114
            // 
            this.tile114.BackColor = System.Drawing.Color.White;
            this.tile114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile114.Location = new System.Drawing.Point(1260, 93);
            this.tile114.Name = "tile114";
            this.tile114.Size = new System.Drawing.Size(32, 31);
            this.tile114.TabIndex = 163;
            this.tile114.TabStop = false;
            // 
            // tile115
            // 
            this.tile115.BackColor = System.Drawing.Color.White;
            this.tile115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile115.Location = new System.Drawing.Point(1298, 93);
            this.tile115.Name = "tile115";
            this.tile115.Size = new System.Drawing.Size(32, 31);
            this.tile115.TabIndex = 162;
            this.tile115.TabStop = false;
            // 
            // tile116
            // 
            this.tile116.BackColor = System.Drawing.Color.White;
            this.tile116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile116.Location = new System.Drawing.Point(1336, 93);
            this.tile116.Name = "tile116";
            this.tile116.Size = new System.Drawing.Size(32, 31);
            this.tile116.TabIndex = 161;
            this.tile116.TabStop = false;
            // 
            // tile117
            // 
            this.tile117.BackColor = System.Drawing.Color.White;
            this.tile117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile117.Location = new System.Drawing.Point(1374, 93);
            this.tile117.Name = "tile117";
            this.tile117.Size = new System.Drawing.Size(32, 31);
            this.tile117.TabIndex = 160;
            this.tile117.TabStop = false;
            // 
            // tile118
            // 
            this.tile118.BackColor = System.Drawing.Color.White;
            this.tile118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile118.Location = new System.Drawing.Point(1412, 93);
            this.tile118.Name = "tile118";
            this.tile118.Size = new System.Drawing.Size(32, 31);
            this.tile118.TabIndex = 159;
            this.tile118.TabStop = false;
            // 
            // tile120
            // 
            this.tile120.BackColor = System.Drawing.Color.White;
            this.tile120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile120.Location = new System.Drawing.Point(1488, 93);
            this.tile120.Name = "tile120";
            this.tile120.Size = new System.Drawing.Size(32, 31);
            this.tile120.TabIndex = 158;
            this.tile120.TabStop = false;
            // 
            // tile119
            // 
            this.tile119.BackColor = System.Drawing.Color.White;
            this.tile119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile119.Location = new System.Drawing.Point(1450, 93);
            this.tile119.Name = "tile119";
            this.tile119.Size = new System.Drawing.Size(32, 31);
            this.tile119.TabIndex = 157;
            this.tile119.TabStop = false;
            // 
            // tile112
            // 
            this.tile112.BackColor = System.Drawing.Color.White;
            this.tile112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile112.Location = new System.Drawing.Point(1184, 93);
            this.tile112.Name = "tile112";
            this.tile112.Size = new System.Drawing.Size(32, 31);
            this.tile112.TabIndex = 156;
            this.tile112.TabStop = false;
            // 
            // tile111
            // 
            this.tile111.BackColor = System.Drawing.Color.White;
            this.tile111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile111.Location = new System.Drawing.Point(1146, 93);
            this.tile111.Name = "tile111";
            this.tile111.Size = new System.Drawing.Size(32, 31);
            this.tile111.TabIndex = 155;
            this.tile111.TabStop = false;
            // 
            // tile108
            // 
            this.tile108.BackColor = System.Drawing.Color.White;
            this.tile108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile108.Location = new System.Drawing.Point(1032, 93);
            this.tile108.Name = "tile108";
            this.tile108.Size = new System.Drawing.Size(32, 31);
            this.tile108.TabIndex = 154;
            this.tile108.TabStop = false;
            // 
            // tile107
            // 
            this.tile107.BackColor = System.Drawing.Color.White;
            this.tile107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile107.Location = new System.Drawing.Point(994, 93);
            this.tile107.Name = "tile107";
            this.tile107.Size = new System.Drawing.Size(32, 31);
            this.tile107.TabIndex = 153;
            this.tile107.TabStop = false;
            // 
            // tile106
            // 
            this.tile106.BackColor = System.Drawing.Color.White;
            this.tile106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile106.Location = new System.Drawing.Point(956, 93);
            this.tile106.Name = "tile106";
            this.tile106.Size = new System.Drawing.Size(32, 31);
            this.tile106.TabIndex = 152;
            this.tile106.TabStop = false;
            // 
            // tile105
            // 
            this.tile105.BackColor = System.Drawing.Color.White;
            this.tile105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile105.Location = new System.Drawing.Point(918, 93);
            this.tile105.Name = "tile105";
            this.tile105.Size = new System.Drawing.Size(32, 31);
            this.tile105.TabIndex = 151;
            this.tile105.TabStop = false;
            // 
            // tile104
            // 
            this.tile104.BackColor = System.Drawing.Color.White;
            this.tile104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile104.Location = new System.Drawing.Point(880, 93);
            this.tile104.Name = "tile104";
            this.tile104.Size = new System.Drawing.Size(32, 31);
            this.tile104.TabIndex = 150;
            this.tile104.TabStop = false;
            // 
            // tile103
            // 
            this.tile103.BackColor = System.Drawing.Color.White;
            this.tile103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile103.Location = new System.Drawing.Point(842, 93);
            this.tile103.Name = "tile103";
            this.tile103.Size = new System.Drawing.Size(32, 31);
            this.tile103.TabIndex = 149;
            this.tile103.TabStop = false;
            // 
            // tile101
            // 
            this.tile101.BackColor = System.Drawing.Color.White;
            this.tile101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile101.Location = new System.Drawing.Point(766, 93);
            this.tile101.Name = "tile101";
            this.tile101.Size = new System.Drawing.Size(32, 31);
            this.tile101.TabIndex = 148;
            this.tile101.TabStop = false;
            // 
            // tile102
            // 
            this.tile102.BackColor = System.Drawing.Color.White;
            this.tile102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile102.Location = new System.Drawing.Point(804, 93);
            this.tile102.Name = "tile102";
            this.tile102.Size = new System.Drawing.Size(32, 31);
            this.tile102.TabIndex = 147;
            this.tile102.TabStop = false;
            // 
            // tile109
            // 
            this.tile109.BackColor = System.Drawing.Color.White;
            this.tile109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile109.Location = new System.Drawing.Point(1070, 93);
            this.tile109.Name = "tile109";
            this.tile109.Size = new System.Drawing.Size(32, 31);
            this.tile109.TabIndex = 146;
            this.tile109.TabStop = false;
            // 
            // tile110
            // 
            this.tile110.BackColor = System.Drawing.Color.White;
            this.tile110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile110.Location = new System.Drawing.Point(1108, 93);
            this.tile110.Name = "tile110";
            this.tile110.Size = new System.Drawing.Size(32, 31);
            this.tile110.TabIndex = 145;
            this.tile110.TabStop = false;
            // 
            // tile93
            // 
            this.tile93.BackColor = System.Drawing.Color.White;
            this.tile93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile93.Location = new System.Drawing.Point(462, 93);
            this.tile93.Name = "tile93";
            this.tile93.Size = new System.Drawing.Size(32, 31);
            this.tile93.TabIndex = 144;
            this.tile93.TabStop = false;
            // 
            // tile94
            // 
            this.tile94.BackColor = System.Drawing.Color.White;
            this.tile94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile94.Location = new System.Drawing.Point(500, 93);
            this.tile94.Name = "tile94";
            this.tile94.Size = new System.Drawing.Size(32, 31);
            this.tile94.TabIndex = 143;
            this.tile94.TabStop = false;
            // 
            // tile95
            // 
            this.tile95.BackColor = System.Drawing.Color.White;
            this.tile95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile95.Location = new System.Drawing.Point(538, 93);
            this.tile95.Name = "tile95";
            this.tile95.Size = new System.Drawing.Size(32, 31);
            this.tile95.TabIndex = 142;
            this.tile95.TabStop = false;
            // 
            // tile96
            // 
            this.tile96.BackColor = System.Drawing.Color.White;
            this.tile96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile96.Location = new System.Drawing.Point(576, 93);
            this.tile96.Name = "tile96";
            this.tile96.Size = new System.Drawing.Size(32, 31);
            this.tile96.TabIndex = 141;
            this.tile96.TabStop = false;
            // 
            // tile97
            // 
            this.tile97.BackColor = System.Drawing.Color.White;
            this.tile97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile97.Location = new System.Drawing.Point(614, 93);
            this.tile97.Name = "tile97";
            this.tile97.Size = new System.Drawing.Size(32, 31);
            this.tile97.TabIndex = 140;
            this.tile97.TabStop = false;
            // 
            // tile98
            // 
            this.tile98.BackColor = System.Drawing.Color.White;
            this.tile98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile98.Location = new System.Drawing.Point(652, 93);
            this.tile98.Name = "tile98";
            this.tile98.Size = new System.Drawing.Size(32, 31);
            this.tile98.TabIndex = 139;
            this.tile98.TabStop = false;
            // 
            // tile99
            // 
            this.tile99.BackColor = System.Drawing.Color.White;
            this.tile99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile99.Location = new System.Drawing.Point(690, 93);
            this.tile99.Name = "tile99";
            this.tile99.Size = new System.Drawing.Size(32, 31);
            this.tile99.TabIndex = 138;
            this.tile99.TabStop = false;
            // 
            // tile100
            // 
            this.tile100.BackColor = System.Drawing.Color.White;
            this.tile100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile100.Location = new System.Drawing.Point(728, 93);
            this.tile100.Name = "tile100";
            this.tile100.Size = new System.Drawing.Size(32, 31);
            this.tile100.TabIndex = 137;
            this.tile100.TabStop = false;
            // 
            // tile92
            // 
            this.tile92.BackColor = System.Drawing.Color.White;
            this.tile92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile92.Location = new System.Drawing.Point(424, 93);
            this.tile92.Name = "tile92";
            this.tile92.Size = new System.Drawing.Size(32, 31);
            this.tile92.TabIndex = 136;
            this.tile92.TabStop = false;
            // 
            // tile91
            // 
            this.tile91.BackColor = System.Drawing.Color.White;
            this.tile91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile91.Location = new System.Drawing.Point(386, 93);
            this.tile91.Name = "tile91";
            this.tile91.Size = new System.Drawing.Size(32, 31);
            this.tile91.TabIndex = 135;
            this.tile91.TabStop = false;
            // 
            // tile83
            // 
            this.tile83.BackColor = System.Drawing.Color.White;
            this.tile83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile83.Location = new System.Drawing.Point(82, 93);
            this.tile83.Name = "tile83";
            this.tile83.Size = new System.Drawing.Size(32, 31);
            this.tile83.TabIndex = 134;
            this.tile83.TabStop = false;
            // 
            // tile84
            // 
            this.tile84.BackColor = System.Drawing.Color.White;
            this.tile84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile84.Location = new System.Drawing.Point(120, 93);
            this.tile84.Name = "tile84";
            this.tile84.Size = new System.Drawing.Size(32, 31);
            this.tile84.TabIndex = 133;
            this.tile84.TabStop = false;
            // 
            // tile85
            // 
            this.tile85.BackColor = System.Drawing.Color.White;
            this.tile85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile85.Location = new System.Drawing.Point(158, 93);
            this.tile85.Name = "tile85";
            this.tile85.Size = new System.Drawing.Size(32, 31);
            this.tile85.TabIndex = 132;
            this.tile85.TabStop = false;
            // 
            // tile86
            // 
            this.tile86.BackColor = System.Drawing.Color.White;
            this.tile86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile86.Location = new System.Drawing.Point(196, 93);
            this.tile86.Name = "tile86";
            this.tile86.Size = new System.Drawing.Size(32, 31);
            this.tile86.TabIndex = 131;
            this.tile86.TabStop = false;
            // 
            // tile87
            // 
            this.tile87.BackColor = System.Drawing.Color.White;
            this.tile87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile87.Location = new System.Drawing.Point(234, 93);
            this.tile87.Name = "tile87";
            this.tile87.Size = new System.Drawing.Size(32, 31);
            this.tile87.TabIndex = 130;
            this.tile87.TabStop = false;
            // 
            // tile88
            // 
            this.tile88.BackColor = System.Drawing.Color.White;
            this.tile88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile88.Location = new System.Drawing.Point(272, 93);
            this.tile88.Name = "tile88";
            this.tile88.Size = new System.Drawing.Size(32, 31);
            this.tile88.TabIndex = 129;
            this.tile88.TabStop = false;
            // 
            // tile89
            // 
            this.tile89.BackColor = System.Drawing.Color.White;
            this.tile89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile89.Location = new System.Drawing.Point(310, 93);
            this.tile89.Name = "tile89";
            this.tile89.Size = new System.Drawing.Size(32, 31);
            this.tile89.TabIndex = 128;
            this.tile89.TabStop = false;
            // 
            // tile90
            // 
            this.tile90.BackColor = System.Drawing.Color.White;
            this.tile90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile90.Location = new System.Drawing.Point(348, 93);
            this.tile90.Name = "tile90";
            this.tile90.Size = new System.Drawing.Size(32, 31);
            this.tile90.TabIndex = 127;
            this.tile90.TabStop = false;
            // 
            // tile82
            // 
            this.tile82.BackColor = System.Drawing.Color.White;
            this.tile82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile82.Location = new System.Drawing.Point(44, 93);
            this.tile82.Name = "tile82";
            this.tile82.Size = new System.Drawing.Size(32, 31);
            this.tile82.TabIndex = 126;
            this.tile82.TabStop = false;
            // 
            // tile81
            // 
            this.tile81.BackColor = System.Drawing.Color.White;
            this.tile81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile81.Location = new System.Drawing.Point(6, 93);
            this.tile81.Name = "tile81";
            this.tile81.Size = new System.Drawing.Size(32, 31);
            this.tile81.TabIndex = 125;
            this.tile81.TabStop = false;
            // 
            // tile73
            // 
            this.tile73.BackColor = System.Drawing.Color.White;
            this.tile73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile73.Location = new System.Drawing.Point(1222, 56);
            this.tile73.Name = "tile73";
            this.tile73.Size = new System.Drawing.Size(32, 31);
            this.tile73.TabIndex = 124;
            this.tile73.TabStop = false;
            // 
            // tile74
            // 
            this.tile74.BackColor = System.Drawing.Color.White;
            this.tile74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile74.Location = new System.Drawing.Point(1260, 56);
            this.tile74.Name = "tile74";
            this.tile74.Size = new System.Drawing.Size(32, 31);
            this.tile74.TabIndex = 123;
            this.tile74.TabStop = false;
            // 
            // tile75
            // 
            this.tile75.BackColor = System.Drawing.Color.White;
            this.tile75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile75.Location = new System.Drawing.Point(1298, 56);
            this.tile75.Name = "tile75";
            this.tile75.Size = new System.Drawing.Size(32, 31);
            this.tile75.TabIndex = 122;
            this.tile75.TabStop = false;
            // 
            // tile76
            // 
            this.tile76.BackColor = System.Drawing.Color.White;
            this.tile76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile76.Location = new System.Drawing.Point(1336, 56);
            this.tile76.Name = "tile76";
            this.tile76.Size = new System.Drawing.Size(32, 31);
            this.tile76.TabIndex = 121;
            this.tile76.TabStop = false;
            // 
            // tile77
            // 
            this.tile77.BackColor = System.Drawing.Color.White;
            this.tile77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile77.Location = new System.Drawing.Point(1374, 56);
            this.tile77.Name = "tile77";
            this.tile77.Size = new System.Drawing.Size(32, 31);
            this.tile77.TabIndex = 120;
            this.tile77.TabStop = false;
            // 
            // tile78
            // 
            this.tile78.BackColor = System.Drawing.Color.White;
            this.tile78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile78.Location = new System.Drawing.Point(1412, 56);
            this.tile78.Name = "tile78";
            this.tile78.Size = new System.Drawing.Size(32, 31);
            this.tile78.TabIndex = 119;
            this.tile78.TabStop = false;
            // 
            // tile80
            // 
            this.tile80.BackColor = System.Drawing.Color.White;
            this.tile80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile80.Location = new System.Drawing.Point(1488, 56);
            this.tile80.Name = "tile80";
            this.tile80.Size = new System.Drawing.Size(32, 31);
            this.tile80.TabIndex = 118;
            this.tile80.TabStop = false;
            // 
            // tile79
            // 
            this.tile79.BackColor = System.Drawing.Color.White;
            this.tile79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile79.Location = new System.Drawing.Point(1450, 56);
            this.tile79.Name = "tile79";
            this.tile79.Size = new System.Drawing.Size(32, 31);
            this.tile79.TabIndex = 117;
            this.tile79.TabStop = false;
            // 
            // tile72
            // 
            this.tile72.BackColor = System.Drawing.Color.White;
            this.tile72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile72.Location = new System.Drawing.Point(1184, 56);
            this.tile72.Name = "tile72";
            this.tile72.Size = new System.Drawing.Size(32, 31);
            this.tile72.TabIndex = 116;
            this.tile72.TabStop = false;
            // 
            // tile71
            // 
            this.tile71.BackColor = System.Drawing.Color.White;
            this.tile71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile71.Location = new System.Drawing.Point(1146, 56);
            this.tile71.Name = "tile71";
            this.tile71.Size = new System.Drawing.Size(32, 31);
            this.tile71.TabIndex = 115;
            this.tile71.TabStop = false;
            // 
            // tile68
            // 
            this.tile68.BackColor = System.Drawing.Color.White;
            this.tile68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile68.Location = new System.Drawing.Point(1032, 56);
            this.tile68.Name = "tile68";
            this.tile68.Size = new System.Drawing.Size(32, 31);
            this.tile68.TabIndex = 114;
            this.tile68.TabStop = false;
            // 
            // tile67
            // 
            this.tile67.BackColor = System.Drawing.Color.White;
            this.tile67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile67.Location = new System.Drawing.Point(994, 56);
            this.tile67.Name = "tile67";
            this.tile67.Size = new System.Drawing.Size(32, 31);
            this.tile67.TabIndex = 113;
            this.tile67.TabStop = false;
            // 
            // tile66
            // 
            this.tile66.BackColor = System.Drawing.Color.White;
            this.tile66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile66.Location = new System.Drawing.Point(956, 56);
            this.tile66.Name = "tile66";
            this.tile66.Size = new System.Drawing.Size(32, 31);
            this.tile66.TabIndex = 112;
            this.tile66.TabStop = false;
            // 
            // tile65
            // 
            this.tile65.BackColor = System.Drawing.Color.White;
            this.tile65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile65.Location = new System.Drawing.Point(918, 56);
            this.tile65.Name = "tile65";
            this.tile65.Size = new System.Drawing.Size(32, 31);
            this.tile65.TabIndex = 111;
            this.tile65.TabStop = false;
            // 
            // tile64
            // 
            this.tile64.BackColor = System.Drawing.Color.White;
            this.tile64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile64.Location = new System.Drawing.Point(880, 56);
            this.tile64.Name = "tile64";
            this.tile64.Size = new System.Drawing.Size(32, 31);
            this.tile64.TabIndex = 110;
            this.tile64.TabStop = false;
            // 
            // tile63
            // 
            this.tile63.BackColor = System.Drawing.Color.White;
            this.tile63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile63.Location = new System.Drawing.Point(842, 56);
            this.tile63.Name = "tile63";
            this.tile63.Size = new System.Drawing.Size(32, 31);
            this.tile63.TabIndex = 109;
            this.tile63.TabStop = false;
            // 
            // tile61
            // 
            this.tile61.BackColor = System.Drawing.Color.White;
            this.tile61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile61.Location = new System.Drawing.Point(766, 56);
            this.tile61.Name = "tile61";
            this.tile61.Size = new System.Drawing.Size(32, 31);
            this.tile61.TabIndex = 108;
            this.tile61.TabStop = false;
            // 
            // tile62
            // 
            this.tile62.BackColor = System.Drawing.Color.White;
            this.tile62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile62.Location = new System.Drawing.Point(804, 56);
            this.tile62.Name = "tile62";
            this.tile62.Size = new System.Drawing.Size(32, 31);
            this.tile62.TabIndex = 107;
            this.tile62.TabStop = false;
            // 
            // tile69
            // 
            this.tile69.BackColor = System.Drawing.Color.White;
            this.tile69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile69.Location = new System.Drawing.Point(1070, 56);
            this.tile69.Name = "tile69";
            this.tile69.Size = new System.Drawing.Size(32, 31);
            this.tile69.TabIndex = 106;
            this.tile69.TabStop = false;
            // 
            // tile70
            // 
            this.tile70.BackColor = System.Drawing.Color.White;
            this.tile70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile70.Location = new System.Drawing.Point(1108, 56);
            this.tile70.Name = "tile70";
            this.tile70.Size = new System.Drawing.Size(32, 31);
            this.tile70.TabIndex = 105;
            this.tile70.TabStop = false;
            // 
            // tile53
            // 
            this.tile53.BackColor = System.Drawing.Color.White;
            this.tile53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile53.Location = new System.Drawing.Point(462, 56);
            this.tile53.Name = "tile53";
            this.tile53.Size = new System.Drawing.Size(32, 31);
            this.tile53.TabIndex = 104;
            this.tile53.TabStop = false;
            // 
            // tile54
            // 
            this.tile54.BackColor = System.Drawing.Color.White;
            this.tile54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile54.Location = new System.Drawing.Point(500, 56);
            this.tile54.Name = "tile54";
            this.tile54.Size = new System.Drawing.Size(32, 31);
            this.tile54.TabIndex = 103;
            this.tile54.TabStop = false;
            // 
            // tile55
            // 
            this.tile55.BackColor = System.Drawing.Color.White;
            this.tile55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile55.Location = new System.Drawing.Point(538, 56);
            this.tile55.Name = "tile55";
            this.tile55.Size = new System.Drawing.Size(32, 31);
            this.tile55.TabIndex = 102;
            this.tile55.TabStop = false;
            // 
            // tile56
            // 
            this.tile56.BackColor = System.Drawing.Color.White;
            this.tile56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile56.Location = new System.Drawing.Point(576, 56);
            this.tile56.Name = "tile56";
            this.tile56.Size = new System.Drawing.Size(32, 31);
            this.tile56.TabIndex = 101;
            this.tile56.TabStop = false;
            // 
            // tile57
            // 
            this.tile57.BackColor = System.Drawing.Color.White;
            this.tile57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile57.Location = new System.Drawing.Point(614, 56);
            this.tile57.Name = "tile57";
            this.tile57.Size = new System.Drawing.Size(32, 31);
            this.tile57.TabIndex = 100;
            this.tile57.TabStop = false;
            // 
            // tile58
            // 
            this.tile58.BackColor = System.Drawing.Color.White;
            this.tile58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile58.Location = new System.Drawing.Point(652, 56);
            this.tile58.Name = "tile58";
            this.tile58.Size = new System.Drawing.Size(32, 31);
            this.tile58.TabIndex = 99;
            this.tile58.TabStop = false;
            // 
            // tile59
            // 
            this.tile59.BackColor = System.Drawing.Color.White;
            this.tile59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile59.Location = new System.Drawing.Point(690, 56);
            this.tile59.Name = "tile59";
            this.tile59.Size = new System.Drawing.Size(32, 31);
            this.tile59.TabIndex = 98;
            this.tile59.TabStop = false;
            // 
            // tile60
            // 
            this.tile60.BackColor = System.Drawing.Color.White;
            this.tile60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile60.Location = new System.Drawing.Point(728, 56);
            this.tile60.Name = "tile60";
            this.tile60.Size = new System.Drawing.Size(32, 31);
            this.tile60.TabIndex = 97;
            this.tile60.TabStop = false;
            // 
            // tile52
            // 
            this.tile52.BackColor = System.Drawing.Color.White;
            this.tile52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile52.Location = new System.Drawing.Point(424, 56);
            this.tile52.Name = "tile52";
            this.tile52.Size = new System.Drawing.Size(32, 31);
            this.tile52.TabIndex = 96;
            this.tile52.TabStop = false;
            // 
            // tile51
            // 
            this.tile51.BackColor = System.Drawing.Color.White;
            this.tile51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile51.Location = new System.Drawing.Point(386, 56);
            this.tile51.Name = "tile51";
            this.tile51.Size = new System.Drawing.Size(32, 31);
            this.tile51.TabIndex = 95;
            this.tile51.TabStop = false;
            // 
            // tile43
            // 
            this.tile43.BackColor = System.Drawing.Color.White;
            this.tile43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile43.Location = new System.Drawing.Point(82, 56);
            this.tile43.Name = "tile43";
            this.tile43.Size = new System.Drawing.Size(32, 31);
            this.tile43.TabIndex = 94;
            this.tile43.TabStop = false;
            // 
            // tile44
            // 
            this.tile44.BackColor = System.Drawing.Color.White;
            this.tile44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile44.Location = new System.Drawing.Point(120, 56);
            this.tile44.Name = "tile44";
            this.tile44.Size = new System.Drawing.Size(32, 31);
            this.tile44.TabIndex = 93;
            this.tile44.TabStop = false;
            // 
            // tile45
            // 
            this.tile45.BackColor = System.Drawing.Color.White;
            this.tile45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile45.Location = new System.Drawing.Point(158, 56);
            this.tile45.Name = "tile45";
            this.tile45.Size = new System.Drawing.Size(32, 31);
            this.tile45.TabIndex = 92;
            this.tile45.TabStop = false;
            // 
            // tile46
            // 
            this.tile46.BackColor = System.Drawing.Color.White;
            this.tile46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile46.Location = new System.Drawing.Point(196, 56);
            this.tile46.Name = "tile46";
            this.tile46.Size = new System.Drawing.Size(32, 31);
            this.tile46.TabIndex = 91;
            this.tile46.TabStop = false;
            // 
            // tile47
            // 
            this.tile47.BackColor = System.Drawing.Color.White;
            this.tile47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile47.Location = new System.Drawing.Point(234, 56);
            this.tile47.Name = "tile47";
            this.tile47.Size = new System.Drawing.Size(32, 31);
            this.tile47.TabIndex = 90;
            this.tile47.TabStop = false;
            // 
            // tile48
            // 
            this.tile48.BackColor = System.Drawing.Color.White;
            this.tile48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile48.Location = new System.Drawing.Point(272, 56);
            this.tile48.Name = "tile48";
            this.tile48.Size = new System.Drawing.Size(32, 31);
            this.tile48.TabIndex = 89;
            this.tile48.TabStop = false;
            // 
            // tile49
            // 
            this.tile49.BackColor = System.Drawing.Color.White;
            this.tile49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile49.Location = new System.Drawing.Point(310, 56);
            this.tile49.Name = "tile49";
            this.tile49.Size = new System.Drawing.Size(32, 31);
            this.tile49.TabIndex = 88;
            this.tile49.TabStop = false;
            // 
            // tile50
            // 
            this.tile50.BackColor = System.Drawing.Color.White;
            this.tile50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile50.Location = new System.Drawing.Point(348, 56);
            this.tile50.Name = "tile50";
            this.tile50.Size = new System.Drawing.Size(32, 31);
            this.tile50.TabIndex = 87;
            this.tile50.TabStop = false;
            // 
            // tile42
            // 
            this.tile42.BackColor = System.Drawing.Color.White;
            this.tile42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile42.Location = new System.Drawing.Point(44, 56);
            this.tile42.Name = "tile42";
            this.tile42.Size = new System.Drawing.Size(32, 31);
            this.tile42.TabIndex = 86;
            this.tile42.TabStop = false;
            // 
            // tile41
            // 
            this.tile41.BackColor = System.Drawing.Color.White;
            this.tile41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile41.Location = new System.Drawing.Point(6, 56);
            this.tile41.Name = "tile41";
            this.tile41.Size = new System.Drawing.Size(32, 31);
            this.tile41.TabIndex = 85;
            this.tile41.TabStop = false;
            // 
            // tile33
            // 
            this.tile33.BackColor = System.Drawing.Color.White;
            this.tile33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile33.Location = new System.Drawing.Point(1222, 19);
            this.tile33.Name = "tile33";
            this.tile33.Size = new System.Drawing.Size(32, 31);
            this.tile33.TabIndex = 84;
            this.tile33.TabStop = false;
            // 
            // tile34
            // 
            this.tile34.BackColor = System.Drawing.Color.White;
            this.tile34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile34.Location = new System.Drawing.Point(1260, 19);
            this.tile34.Name = "tile34";
            this.tile34.Size = new System.Drawing.Size(32, 31);
            this.tile34.TabIndex = 83;
            this.tile34.TabStop = false;
            // 
            // tile35
            // 
            this.tile35.BackColor = System.Drawing.Color.White;
            this.tile35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile35.Location = new System.Drawing.Point(1298, 19);
            this.tile35.Name = "tile35";
            this.tile35.Size = new System.Drawing.Size(32, 31);
            this.tile35.TabIndex = 82;
            this.tile35.TabStop = false;
            // 
            // tile36
            // 
            this.tile36.BackColor = System.Drawing.Color.White;
            this.tile36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile36.Location = new System.Drawing.Point(1336, 19);
            this.tile36.Name = "tile36";
            this.tile36.Size = new System.Drawing.Size(32, 31);
            this.tile36.TabIndex = 81;
            this.tile36.TabStop = false;
            // 
            // tile37
            // 
            this.tile37.BackColor = System.Drawing.Color.White;
            this.tile37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile37.Location = new System.Drawing.Point(1374, 19);
            this.tile37.Name = "tile37";
            this.tile37.Size = new System.Drawing.Size(32, 31);
            this.tile37.TabIndex = 80;
            this.tile37.TabStop = false;
            // 
            // tile38
            // 
            this.tile38.BackColor = System.Drawing.Color.White;
            this.tile38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile38.Location = new System.Drawing.Point(1412, 19);
            this.tile38.Name = "tile38";
            this.tile38.Size = new System.Drawing.Size(32, 31);
            this.tile38.TabIndex = 79;
            this.tile38.TabStop = false;
            // 
            // tile40
            // 
            this.tile40.BackColor = System.Drawing.Color.White;
            this.tile40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile40.Location = new System.Drawing.Point(1488, 19);
            this.tile40.Name = "tile40";
            this.tile40.Size = new System.Drawing.Size(32, 31);
            this.tile40.TabIndex = 78;
            this.tile40.TabStop = false;
            // 
            // tile39
            // 
            this.tile39.BackColor = System.Drawing.Color.White;
            this.tile39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile39.Location = new System.Drawing.Point(1450, 19);
            this.tile39.Name = "tile39";
            this.tile39.Size = new System.Drawing.Size(32, 31);
            this.tile39.TabIndex = 77;
            this.tile39.TabStop = false;
            // 
            // tile32
            // 
            this.tile32.BackColor = System.Drawing.Color.White;
            this.tile32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile32.Location = new System.Drawing.Point(1184, 19);
            this.tile32.Name = "tile32";
            this.tile32.Size = new System.Drawing.Size(32, 31);
            this.tile32.TabIndex = 76;
            this.tile32.TabStop = false;
            // 
            // tile31
            // 
            this.tile31.BackColor = System.Drawing.Color.White;
            this.tile31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile31.Location = new System.Drawing.Point(1146, 19);
            this.tile31.Name = "tile31";
            this.tile31.Size = new System.Drawing.Size(32, 31);
            this.tile31.TabIndex = 75;
            this.tile31.TabStop = false;
            // 
            // tile28
            // 
            this.tile28.BackColor = System.Drawing.Color.White;
            this.tile28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile28.Location = new System.Drawing.Point(1032, 19);
            this.tile28.Name = "tile28";
            this.tile28.Size = new System.Drawing.Size(32, 31);
            this.tile28.TabIndex = 74;
            this.tile28.TabStop = false;
            // 
            // tile27
            // 
            this.tile27.BackColor = System.Drawing.Color.White;
            this.tile27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile27.Location = new System.Drawing.Point(994, 19);
            this.tile27.Name = "tile27";
            this.tile27.Size = new System.Drawing.Size(32, 31);
            this.tile27.TabIndex = 73;
            this.tile27.TabStop = false;
            // 
            // tile26
            // 
            this.tile26.BackColor = System.Drawing.Color.White;
            this.tile26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile26.Location = new System.Drawing.Point(956, 19);
            this.tile26.Name = "tile26";
            this.tile26.Size = new System.Drawing.Size(32, 31);
            this.tile26.TabIndex = 72;
            this.tile26.TabStop = false;
            // 
            // tile25
            // 
            this.tile25.BackColor = System.Drawing.Color.White;
            this.tile25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile25.Location = new System.Drawing.Point(918, 19);
            this.tile25.Name = "tile25";
            this.tile25.Size = new System.Drawing.Size(32, 31);
            this.tile25.TabIndex = 71;
            this.tile25.TabStop = false;
            // 
            // tile24
            // 
            this.tile24.BackColor = System.Drawing.Color.White;
            this.tile24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile24.Location = new System.Drawing.Point(880, 19);
            this.tile24.Name = "tile24";
            this.tile24.Size = new System.Drawing.Size(32, 31);
            this.tile24.TabIndex = 70;
            this.tile24.TabStop = false;
            // 
            // tile23
            // 
            this.tile23.BackColor = System.Drawing.Color.White;
            this.tile23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile23.Location = new System.Drawing.Point(842, 19);
            this.tile23.Name = "tile23";
            this.tile23.Size = new System.Drawing.Size(32, 31);
            this.tile23.TabIndex = 69;
            this.tile23.TabStop = false;
            // 
            // tile21
            // 
            this.tile21.BackColor = System.Drawing.Color.White;
            this.tile21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile21.Location = new System.Drawing.Point(766, 19);
            this.tile21.Name = "tile21";
            this.tile21.Size = new System.Drawing.Size(32, 31);
            this.tile21.TabIndex = 68;
            this.tile21.TabStop = false;
            // 
            // tile22
            // 
            this.tile22.BackColor = System.Drawing.Color.White;
            this.tile22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile22.Location = new System.Drawing.Point(804, 19);
            this.tile22.Name = "tile22";
            this.tile22.Size = new System.Drawing.Size(32, 31);
            this.tile22.TabIndex = 67;
            this.tile22.TabStop = false;
            // 
            // tile29
            // 
            this.tile29.BackColor = System.Drawing.Color.White;
            this.tile29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile29.Location = new System.Drawing.Point(1070, 19);
            this.tile29.Name = "tile29";
            this.tile29.Size = new System.Drawing.Size(32, 31);
            this.tile29.TabIndex = 66;
            this.tile29.TabStop = false;
            // 
            // tile30
            // 
            this.tile30.BackColor = System.Drawing.Color.White;
            this.tile30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile30.Location = new System.Drawing.Point(1108, 19);
            this.tile30.Name = "tile30";
            this.tile30.Size = new System.Drawing.Size(32, 31);
            this.tile30.TabIndex = 65;
            this.tile30.TabStop = false;
            // 
            // tile13
            // 
            this.tile13.BackColor = System.Drawing.Color.White;
            this.tile13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile13.Location = new System.Drawing.Point(462, 19);
            this.tile13.Name = "tile13";
            this.tile13.Size = new System.Drawing.Size(32, 31);
            this.tile13.TabIndex = 64;
            this.tile13.TabStop = false;
            // 
            // tile14
            // 
            this.tile14.BackColor = System.Drawing.Color.White;
            this.tile14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile14.Location = new System.Drawing.Point(500, 19);
            this.tile14.Name = "tile14";
            this.tile14.Size = new System.Drawing.Size(32, 31);
            this.tile14.TabIndex = 63;
            this.tile14.TabStop = false;
            // 
            // tile15
            // 
            this.tile15.BackColor = System.Drawing.Color.White;
            this.tile15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile15.Location = new System.Drawing.Point(538, 19);
            this.tile15.Name = "tile15";
            this.tile15.Size = new System.Drawing.Size(32, 31);
            this.tile15.TabIndex = 62;
            this.tile15.TabStop = false;
            // 
            // tile16
            // 
            this.tile16.BackColor = System.Drawing.Color.White;
            this.tile16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile16.Location = new System.Drawing.Point(576, 19);
            this.tile16.Name = "tile16";
            this.tile16.Size = new System.Drawing.Size(32, 31);
            this.tile16.TabIndex = 61;
            this.tile16.TabStop = false;
            // 
            // tile17
            // 
            this.tile17.BackColor = System.Drawing.Color.White;
            this.tile17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile17.Location = new System.Drawing.Point(614, 19);
            this.tile17.Name = "tile17";
            this.tile17.Size = new System.Drawing.Size(32, 31);
            this.tile17.TabIndex = 60;
            this.tile17.TabStop = false;
            // 
            // tile18
            // 
            this.tile18.BackColor = System.Drawing.Color.White;
            this.tile18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile18.Location = new System.Drawing.Point(652, 19);
            this.tile18.Name = "tile18";
            this.tile18.Size = new System.Drawing.Size(32, 31);
            this.tile18.TabIndex = 59;
            this.tile18.TabStop = false;
            // 
            // tile19
            // 
            this.tile19.BackColor = System.Drawing.Color.White;
            this.tile19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile19.Location = new System.Drawing.Point(690, 19);
            this.tile19.Name = "tile19";
            this.tile19.Size = new System.Drawing.Size(32, 31);
            this.tile19.TabIndex = 58;
            this.tile19.TabStop = false;
            // 
            // tile20
            // 
            this.tile20.BackColor = System.Drawing.Color.White;
            this.tile20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile20.Location = new System.Drawing.Point(728, 19);
            this.tile20.Name = "tile20";
            this.tile20.Size = new System.Drawing.Size(32, 31);
            this.tile20.TabIndex = 57;
            this.tile20.TabStop = false;
            // 
            // tile12
            // 
            this.tile12.BackColor = System.Drawing.Color.White;
            this.tile12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile12.Location = new System.Drawing.Point(424, 19);
            this.tile12.Name = "tile12";
            this.tile12.Size = new System.Drawing.Size(32, 31);
            this.tile12.TabIndex = 56;
            this.tile12.TabStop = false;
            // 
            // tile11
            // 
            this.tile11.BackColor = System.Drawing.Color.White;
            this.tile11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile11.Location = new System.Drawing.Point(386, 19);
            this.tile11.Name = "tile11";
            this.tile11.Size = new System.Drawing.Size(32, 31);
            this.tile11.TabIndex = 55;
            this.tile11.TabStop = false;
            // 
            // tile3
            // 
            this.tile3.BackColor = System.Drawing.Color.White;
            this.tile3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile3.Location = new System.Drawing.Point(82, 19);
            this.tile3.Name = "tile3";
            this.tile3.Size = new System.Drawing.Size(32, 31);
            this.tile3.TabIndex = 54;
            this.tile3.TabStop = false;
            // 
            // tile4
            // 
            this.tile4.BackColor = System.Drawing.Color.White;
            this.tile4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile4.Location = new System.Drawing.Point(120, 19);
            this.tile4.Name = "tile4";
            this.tile4.Size = new System.Drawing.Size(32, 31);
            this.tile4.TabIndex = 53;
            this.tile4.TabStop = false;
            // 
            // tile5
            // 
            this.tile5.BackColor = System.Drawing.Color.White;
            this.tile5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile5.Location = new System.Drawing.Point(158, 19);
            this.tile5.Name = "tile5";
            this.tile5.Size = new System.Drawing.Size(32, 31);
            this.tile5.TabIndex = 52;
            this.tile5.TabStop = false;
            // 
            // tile6
            // 
            this.tile6.BackColor = System.Drawing.Color.White;
            this.tile6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile6.Location = new System.Drawing.Point(196, 19);
            this.tile6.Name = "tile6";
            this.tile6.Size = new System.Drawing.Size(32, 31);
            this.tile6.TabIndex = 51;
            this.tile6.TabStop = false;
            // 
            // tile7
            // 
            this.tile7.BackColor = System.Drawing.Color.White;
            this.tile7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile7.Location = new System.Drawing.Point(234, 19);
            this.tile7.Name = "tile7";
            this.tile7.Size = new System.Drawing.Size(32, 31);
            this.tile7.TabIndex = 50;
            this.tile7.TabStop = false;
            // 
            // tile8
            // 
            this.tile8.BackColor = System.Drawing.Color.White;
            this.tile8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile8.Location = new System.Drawing.Point(272, 19);
            this.tile8.Name = "tile8";
            this.tile8.Size = new System.Drawing.Size(32, 31);
            this.tile8.TabIndex = 49;
            this.tile8.TabStop = false;
            // 
            // tile9
            // 
            this.tile9.BackColor = System.Drawing.Color.White;
            this.tile9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile9.Location = new System.Drawing.Point(311, 19);
            this.tile9.Name = "tile9";
            this.tile9.Size = new System.Drawing.Size(32, 31);
            this.tile9.TabIndex = 48;
            this.tile9.TabStop = false;
            // 
            // tile10
            // 
            this.tile10.BackColor = System.Drawing.Color.White;
            this.tile10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile10.Location = new System.Drawing.Point(348, 19);
            this.tile10.Name = "tile10";
            this.tile10.Size = new System.Drawing.Size(32, 31);
            this.tile10.TabIndex = 47;
            this.tile10.TabStop = false;
            // 
            // tile2
            // 
            this.tile2.BackColor = System.Drawing.Color.White;
            this.tile2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile2.Location = new System.Drawing.Point(44, 19);
            this.tile2.Name = "tile2";
            this.tile2.Size = new System.Drawing.Size(32, 31);
            this.tile2.TabIndex = 27;
            this.tile2.TabStop = false;
            this.tile2.Click += new System.EventHandler(this.tile2_Click);
            this.tile2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tile2_MouseClick);
            // 
            // tile1
            // 
            this.tile1.BackColor = System.Drawing.Color.White;
            this.tile1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tile1.Location = new System.Drawing.Point(6, 19);
            this.tile1.Name = "tile1";
            this.tile1.Size = new System.Drawing.Size(32, 31);
            this.tile1.TabIndex = 26;
            this.tile1.TabStop = false;
            this.tile1.Click += new System.EventHandler(this.tile1_Click);
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(1369, 56);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 50);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // levelNameBox
            // 
            this.levelNameBox.Location = new System.Drawing.Point(1604, 810);
            this.levelNameBox.Name = "levelNameBox";
            this.levelNameBox.Size = new System.Drawing.Size(137, 20);
            this.levelNameBox.TabIndex = 8;
            // 
            // labelSaveName
            // 
            this.labelSaveName.AutoSize = true;
            this.labelSaveName.Location = new System.Drawing.Point(1602, 794);
            this.labelSaveName.Name = "labelSaveName";
            this.labelSaveName.Size = new System.Drawing.Size(138, 13);
            this.labelSaveName.TabIndex = 9;
            this.labelSaveName.Text = "Save Level Pane Name As:";
            this.labelSaveName.Click += new System.EventHandler(this.labelSaveName_Click);
            // 
            // groupBoxInstructions
            // 
            this.groupBoxInstructions.Controls.Add(this.panel1);
            this.groupBoxInstructions.Location = new System.Drawing.Point(1568, 284);
            this.groupBoxInstructions.Name = "groupBoxInstructions";
            this.groupBoxInstructions.Size = new System.Drawing.Size(173, 507);
            this.groupBoxInstructions.TabIndex = 10;
            this.groupBoxInstructions.TabStop = false;
            this.groupBoxInstructions.Text = "Instructions";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 485);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 481);
            this.label2.TabIndex = 0;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1753, 874);
            this.Controls.Add(this.groupBoxInstructions);
            this.Controls.Add(this.labelSaveName);
            this.Controls.Add(this.levelNameBox);
            this.Controls.Add(this.editor);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.groupBoxKey);
            this.Controls.Add(this.pictureBox3);
            this.Name = "Form1";
            this.Text = "Rocket Jump - Map Editor";
            this.MouseEnter += new System.EventHandler(this.Form1_MouseEnter);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.referencePlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceEnemy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceFloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.referenceLedge)).EndInit();
            this.groupBoxKey.ResumeLayout(false);
            this.groupBoxKey.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.referenceBlank)).EndInit();
            this.editor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tile873)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile874)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile875)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile876)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile877)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile878)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile880)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile879)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile872)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile871)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile868)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile867)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile866)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile865)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile864)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile863)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile861)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile862)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile869)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile870)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile853)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile854)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile855)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile856)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile857)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile858)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile859)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile860)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile852)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile851)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile843)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile844)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile845)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile846)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile847)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile848)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile849)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile850)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile842)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile841)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile833)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile834)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile835)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile836)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile837)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile838)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile840)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile839)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile832)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile831)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile828)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile827)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile826)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile825)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile824)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile823)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile821)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile822)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile829)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile830)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile813)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile814)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile815)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile816)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile817)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile818)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile819)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile820)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile812)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile811)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile803)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile804)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile805)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile806)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile807)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile808)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile809)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile810)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile802)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile801)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile793)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile794)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile795)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile796)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile797)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile798)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile800)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile799)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile792)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile791)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile788)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile787)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile786)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile785)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile784)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile783)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile781)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile782)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile789)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile790)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile773)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile774)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile775)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile776)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile777)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile778)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile779)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile780)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile772)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile771)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile763)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile764)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile765)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile766)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile767)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile768)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile769)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile770)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile762)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile761)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile753)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile754)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile755)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile756)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile757)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile758)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile760)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile759)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile752)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile751)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile748)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile747)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile746)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile745)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile744)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile743)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile741)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile742)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile749)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile750)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile733)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile734)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile735)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile736)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile737)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile738)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile739)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile740)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile732)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile731)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile723)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile724)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile725)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile726)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile727)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile728)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile729)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile730)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile722)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile721)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile713)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile714)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile715)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile716)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile717)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile718)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile720)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile719)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile712)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile711)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile708)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile707)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile706)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile705)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile704)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile703)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile701)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile702)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile709)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile710)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile693)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile694)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile695)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile696)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile697)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile698)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile699)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile700)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile692)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile691)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile683)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile684)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile685)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile686)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile687)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile688)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile689)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile690)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile682)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile681)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile673)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile674)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile675)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile676)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile677)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile678)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile680)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile679)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile672)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile671)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile668)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile667)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile666)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile665)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile664)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile663)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile661)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile662)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile669)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile670)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile653)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile654)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile655)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile656)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile657)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile658)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile659)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile660)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile652)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile651)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile643)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile644)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile645)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile646)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile647)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile648)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile649)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile650)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile642)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile641)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile633)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile634)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile635)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile636)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile637)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile638)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile640)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile639)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile632)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile631)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile628)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile627)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile626)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile625)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile624)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile623)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile621)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile622)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile629)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile630)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile613)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile614)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile615)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile616)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile617)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile618)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile619)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile620)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile612)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile611)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile603)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile604)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile605)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile606)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile607)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile608)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile609)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile610)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile602)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile601)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile593)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile594)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile595)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile596)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile597)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile598)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile600)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile599)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile592)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile591)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile588)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile587)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile586)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile585)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile584)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile583)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile581)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile582)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile589)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile590)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile573)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile574)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile575)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile576)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile577)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile578)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile579)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile580)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile572)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile571)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile563)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile564)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile565)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile566)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile567)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile568)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile569)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile570)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile562)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile561)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile553)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile554)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile555)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile556)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile557)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile558)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile560)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile559)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile552)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile551)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile548)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile547)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile546)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile545)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile544)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile543)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile541)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile542)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile549)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile550)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile533)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile534)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile535)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile536)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile537)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile538)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile539)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile540)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile532)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile531)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile523)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile524)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile525)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile526)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile527)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile528)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile529)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile530)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile522)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile521)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile513)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile514)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile515)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile516)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile517)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile518)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile520)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile519)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile512)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile511)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile508)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile507)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile506)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile505)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile504)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile503)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile501)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile502)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile509)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile510)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile493)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile494)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile495)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile496)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile497)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile498)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile499)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile500)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile492)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile491)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile483)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile484)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile485)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile486)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile487)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile488)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile489)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile490)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile482)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile481)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile473)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile474)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile475)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile476)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile477)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile478)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile480)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile479)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile472)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile471)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile468)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile467)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile466)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile465)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile464)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile463)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile461)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile462)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile469)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile470)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile453)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile454)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile455)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile456)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile457)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile458)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile459)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile460)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile452)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile451)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile443)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile444)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile445)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile446)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile447)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile448)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile449)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile450)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile442)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile441)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile433)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile434)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile435)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile436)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile437)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile438)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile440)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile439)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile432)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile431)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile428)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile427)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile426)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile425)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile424)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile423)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile421)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile422)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile429)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile430)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile413)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile414)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile415)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile416)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile417)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile418)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile419)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile420)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile412)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile411)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile403)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile404)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile405)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile406)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile407)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile408)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile409)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile410)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile402)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile401)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile393)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile394)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile395)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile396)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile397)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile398)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile400)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile399)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile392)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile391)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile388)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile387)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile386)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile385)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile384)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile383)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile381)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile382)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile389)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile390)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile373)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile374)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile375)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile376)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile377)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile378)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile379)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile380)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile372)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile371)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile363)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile364)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile365)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile366)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile367)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile368)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile369)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile370)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile362)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile361)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile353)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile354)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile355)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile356)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile357)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile358)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile360)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile359)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile352)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile351)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile348)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile347)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile346)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile345)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile344)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile343)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile341)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile342)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile349)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile350)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile333)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile334)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile335)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile336)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile337)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile338)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile339)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile340)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile332)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile331)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile323)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile324)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile325)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile326)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile327)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile328)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile329)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile330)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile322)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile321)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile313)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile314)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile315)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile316)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile317)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile318)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile320)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile319)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile312)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile311)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile308)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile307)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile306)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile305)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile304)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile303)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile301)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile302)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile309)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile310)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile293)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile294)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile295)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile296)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile297)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile298)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile299)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile300)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile292)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile291)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile283)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile284)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile285)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile286)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile287)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile288)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile289)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile290)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile282)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile281)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile273)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile274)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile275)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile276)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile277)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile278)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile280)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile279)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile272)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile271)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile268)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile267)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile266)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile265)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile264)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile263)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile261)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile262)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile269)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile270)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile253)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile254)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile255)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile256)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile257)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile258)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile259)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile260)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile252)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile251)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile243)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile244)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile245)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile246)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile247)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile248)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile249)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile250)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile242)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile241)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile233)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile234)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile235)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile236)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile237)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile238)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile240)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile239)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile232)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile231)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile228)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile227)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile226)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile225)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile224)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile229)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile230)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile214)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile215)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile216)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile217)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile218)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile219)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile203)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile204)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile205)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile206)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile207)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile208)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile209)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile202)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile201)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile193)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile194)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile195)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile196)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile197)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile198)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile200)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile199)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile192)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile191)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile188)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile187)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile186)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile185)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile184)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile181)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile182)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile189)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile190)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile175)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile176)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile177)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile178)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile179)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile180)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile163)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile164)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile165)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile167)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile168)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile169)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile162)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile161)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile156)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile151)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile147)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile146)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile145)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile150)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBoxInstructions.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox referencePlayer;
        private System.Windows.Forms.Label labelPlayer;
        private System.Windows.Forms.Label labelEnemy;
        private System.Windows.Forms.Label labelFloor;
        private System.Windows.Forms.Label labelLedge;
        private System.Windows.Forms.PictureBox referenceEnemy;
        private System.Windows.Forms.PictureBox referenceFloor;
        private System.Windows.Forms.PictureBox referenceLedge;
        private System.Windows.Forms.GroupBox groupBoxKey;
        private System.Windows.Forms.PictureBox referenceBlank;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label labelBlank;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.GroupBox editor;
        private System.Windows.Forms.PictureBox tile793;
        private System.Windows.Forms.PictureBox tile794;
        private System.Windows.Forms.PictureBox tile795;
        private System.Windows.Forms.PictureBox tile796;
        private System.Windows.Forms.PictureBox tile797;
        private System.Windows.Forms.PictureBox tile798;
        private System.Windows.Forms.PictureBox tile800;
        private System.Windows.Forms.PictureBox tile799;
        private System.Windows.Forms.PictureBox tile792;
        private System.Windows.Forms.PictureBox tile791;
        private System.Windows.Forms.PictureBox tile788;
        private System.Windows.Forms.PictureBox tile787;
        private System.Windows.Forms.PictureBox tile786;
        private System.Windows.Forms.PictureBox tile785;
        private System.Windows.Forms.PictureBox tile784;
        private System.Windows.Forms.PictureBox tile781;
        private System.Windows.Forms.PictureBox tile782;
        private System.Windows.Forms.PictureBox tile789;
        private System.Windows.Forms.PictureBox tile790;
        private System.Windows.Forms.PictureBox tile773;
        private System.Windows.Forms.PictureBox tile774;
        private System.Windows.Forms.PictureBox tile775;
        private System.Windows.Forms.PictureBox tile776;
        private System.Windows.Forms.PictureBox tile777;
        private System.Windows.Forms.PictureBox tile778;
        private System.Windows.Forms.PictureBox tile779;
        private System.Windows.Forms.PictureBox tile780;
        private System.Windows.Forms.PictureBox tile772;
        private System.Windows.Forms.PictureBox tile771;
        private System.Windows.Forms.PictureBox tile763;
        private System.Windows.Forms.PictureBox tile765;
        private System.Windows.Forms.PictureBox tile766;
        private System.Windows.Forms.PictureBox tile767;
        private System.Windows.Forms.PictureBox tile768;
        private System.Windows.Forms.PictureBox tile769;
        private System.Windows.Forms.PictureBox tile770;
        private System.Windows.Forms.PictureBox tile762;
        private System.Windows.Forms.PictureBox tile761;
        private System.Windows.Forms.PictureBox tile753;
        private System.Windows.Forms.PictureBox tile754;
        private System.Windows.Forms.PictureBox tile755;
        private System.Windows.Forms.PictureBox tile756;
        private System.Windows.Forms.PictureBox tile757;
        private System.Windows.Forms.PictureBox tile758;
        private System.Windows.Forms.PictureBox tile760;
        private System.Windows.Forms.PictureBox tile759;
        private System.Windows.Forms.PictureBox tile752;
        private System.Windows.Forms.PictureBox tile751;
        private System.Windows.Forms.PictureBox tile748;
        private System.Windows.Forms.PictureBox tile747;
        private System.Windows.Forms.PictureBox tile746;
        private System.Windows.Forms.PictureBox tile745;
        private System.Windows.Forms.PictureBox tile744;
        private System.Windows.Forms.PictureBox tile743;
        private System.Windows.Forms.PictureBox tile741;
        private System.Windows.Forms.PictureBox tile742;
        private System.Windows.Forms.PictureBox tile749;
        private System.Windows.Forms.PictureBox tile750;
        private System.Windows.Forms.PictureBox tile733;
        private System.Windows.Forms.PictureBox tile734;
        private System.Windows.Forms.PictureBox tile735;
        private System.Windows.Forms.PictureBox tile736;
        private System.Windows.Forms.PictureBox tile737;
        private System.Windows.Forms.PictureBox tile738;
        private System.Windows.Forms.PictureBox tile739;
        private System.Windows.Forms.PictureBox tile740;
        private System.Windows.Forms.PictureBox tile732;
        private System.Windows.Forms.PictureBox tile731;
        private System.Windows.Forms.PictureBox tile723;
        private System.Windows.Forms.PictureBox tile724;
        private System.Windows.Forms.PictureBox tile725;
        private System.Windows.Forms.PictureBox tile726;
        private System.Windows.Forms.PictureBox tile727;
        private System.Windows.Forms.PictureBox tile728;
        private System.Windows.Forms.PictureBox tile729;
        private System.Windows.Forms.PictureBox tile730;
        private System.Windows.Forms.PictureBox tile722;
        private System.Windows.Forms.PictureBox tile721;
        private System.Windows.Forms.PictureBox tile713;
        private System.Windows.Forms.PictureBox tile714;
        private System.Windows.Forms.PictureBox tile715;
        private System.Windows.Forms.PictureBox tile716;
        private System.Windows.Forms.PictureBox tile717;
        private System.Windows.Forms.PictureBox tile718;
        private System.Windows.Forms.PictureBox tile720;
        private System.Windows.Forms.PictureBox tile719;
        private System.Windows.Forms.PictureBox tile712;
        private System.Windows.Forms.PictureBox tile711;
        private System.Windows.Forms.PictureBox tile708;
        private System.Windows.Forms.PictureBox tile707;
        private System.Windows.Forms.PictureBox tile706;
        private System.Windows.Forms.PictureBox tile705;
        private System.Windows.Forms.PictureBox tile704;
        private System.Windows.Forms.PictureBox tile703;
        private System.Windows.Forms.PictureBox tile701;
        private System.Windows.Forms.PictureBox tile709;
        private System.Windows.Forms.PictureBox tile710;
        private System.Windows.Forms.PictureBox tile693;
        private System.Windows.Forms.PictureBox tile694;
        private System.Windows.Forms.PictureBox tile695;
        private System.Windows.Forms.PictureBox tile696;
        private System.Windows.Forms.PictureBox tile697;
        private System.Windows.Forms.PictureBox tile698;
        private System.Windows.Forms.PictureBox tile699;
        private System.Windows.Forms.PictureBox tile700;
        private System.Windows.Forms.PictureBox tile692;
        private System.Windows.Forms.PictureBox tile691;
        private System.Windows.Forms.PictureBox tile683;
        private System.Windows.Forms.PictureBox tile684;
        private System.Windows.Forms.PictureBox tile685;
        private System.Windows.Forms.PictureBox tile686;
        private System.Windows.Forms.PictureBox tile687;
        private System.Windows.Forms.PictureBox tile688;
        private System.Windows.Forms.PictureBox tile689;
        private System.Windows.Forms.PictureBox tile682;
        private System.Windows.Forms.PictureBox tile681;
        private System.Windows.Forms.PictureBox tile673;
        private System.Windows.Forms.PictureBox tile674;
        private System.Windows.Forms.PictureBox tile677;
        private System.Windows.Forms.PictureBox tile678;
        private System.Windows.Forms.PictureBox tile680;
        private System.Windows.Forms.PictureBox tile679;
        private System.Windows.Forms.PictureBox tile672;
        private System.Windows.Forms.PictureBox tile671;
        private System.Windows.Forms.PictureBox tile668;
        private System.Windows.Forms.PictureBox tile667;
        private System.Windows.Forms.PictureBox tile666;
        private System.Windows.Forms.PictureBox tile665;
        private System.Windows.Forms.PictureBox tile664;
        private System.Windows.Forms.PictureBox tile661;
        private System.Windows.Forms.PictureBox tile662;
        private System.Windows.Forms.PictureBox tile669;
        private System.Windows.Forms.PictureBox tile670;
        private System.Windows.Forms.PictureBox tile653;
        private System.Windows.Forms.PictureBox tile655;
        private System.Windows.Forms.PictureBox tile656;
        private System.Windows.Forms.PictureBox tile657;
        private System.Windows.Forms.PictureBox tile658;
        private System.Windows.Forms.PictureBox tile659;
        private System.Windows.Forms.PictureBox tile660;
        private System.Windows.Forms.PictureBox tile652;
        private System.Windows.Forms.PictureBox tile651;
        private System.Windows.Forms.PictureBox tile643;
        private System.Windows.Forms.PictureBox tile644;
        private System.Windows.Forms.PictureBox tile645;
        private System.Windows.Forms.PictureBox tile646;
        private System.Windows.Forms.PictureBox tile647;
        private System.Windows.Forms.PictureBox tile648;
        private System.Windows.Forms.PictureBox tile649;
        private System.Windows.Forms.PictureBox tile650;
        private System.Windows.Forms.PictureBox tile641;
        private System.Windows.Forms.PictureBox tile633;
        private System.Windows.Forms.PictureBox tile634;
        private System.Windows.Forms.PictureBox tile635;
        private System.Windows.Forms.PictureBox tile636;
        private System.Windows.Forms.PictureBox tile637;
        private System.Windows.Forms.PictureBox tile638;
        private System.Windows.Forms.PictureBox tile640;
        private System.Windows.Forms.PictureBox tile639;
        private System.Windows.Forms.PictureBox tile632;
        private System.Windows.Forms.PictureBox tile631;
        private System.Windows.Forms.PictureBox tile628;
        private System.Windows.Forms.PictureBox tile627;
        private System.Windows.Forms.PictureBox tile626;
        private System.Windows.Forms.PictureBox tile625;
        private System.Windows.Forms.PictureBox tile624;
        private System.Windows.Forms.PictureBox tile623;
        private System.Windows.Forms.PictureBox tile621;
        private System.Windows.Forms.PictureBox tile622;
        private System.Windows.Forms.PictureBox tile629;
        private System.Windows.Forms.PictureBox tile630;
        private System.Windows.Forms.PictureBox tile613;
        private System.Windows.Forms.PictureBox tile614;
        private System.Windows.Forms.PictureBox tile615;
        private System.Windows.Forms.PictureBox tile616;
        private System.Windows.Forms.PictureBox tile617;
        private System.Windows.Forms.PictureBox tile618;
        private System.Windows.Forms.PictureBox tile619;
        private System.Windows.Forms.PictureBox tile612;
        private System.Windows.Forms.PictureBox tile611;
        private System.Windows.Forms.PictureBox tile603;
        private System.Windows.Forms.PictureBox tile604;
        private System.Windows.Forms.PictureBox tile605;
        private System.Windows.Forms.PictureBox tile607;
        private System.Windows.Forms.PictureBox tile608;
        private System.Windows.Forms.PictureBox tile609;
        private System.Windows.Forms.PictureBox tile610;
        private System.Windows.Forms.PictureBox tile602;
        private System.Windows.Forms.PictureBox tile601;
        private System.Windows.Forms.PictureBox tile593;
        private System.Windows.Forms.PictureBox tile594;
        private System.Windows.Forms.PictureBox tile595;
        private System.Windows.Forms.PictureBox tile596;
        private System.Windows.Forms.PictureBox tile597;
        private System.Windows.Forms.PictureBox tile598;
        private System.Windows.Forms.PictureBox tile600;
        private System.Windows.Forms.PictureBox tile599;
        private System.Windows.Forms.PictureBox tile592;
        private System.Windows.Forms.PictureBox tile591;
        private System.Windows.Forms.PictureBox tile588;
        private System.Windows.Forms.PictureBox tile587;
        private System.Windows.Forms.PictureBox tile586;
        private System.Windows.Forms.PictureBox tile585;
        private System.Windows.Forms.PictureBox tile584;
        private System.Windows.Forms.PictureBox tile583;
        private System.Windows.Forms.PictureBox tile581;
        private System.Windows.Forms.PictureBox tile582;
        private System.Windows.Forms.PictureBox tile589;
        private System.Windows.Forms.PictureBox tile590;
        private System.Windows.Forms.PictureBox tile573;
        private System.Windows.Forms.PictureBox tile574;
        private System.Windows.Forms.PictureBox tile575;
        private System.Windows.Forms.PictureBox tile576;
        private System.Windows.Forms.PictureBox tile577;
        private System.Windows.Forms.PictureBox tile578;
        private System.Windows.Forms.PictureBox tile579;
        private System.Windows.Forms.PictureBox tile580;
        private System.Windows.Forms.PictureBox tile572;
        private System.Windows.Forms.PictureBox tile571;
        private System.Windows.Forms.PictureBox tile563;
        private System.Windows.Forms.PictureBox tile564;
        private System.Windows.Forms.PictureBox tile565;
        private System.Windows.Forms.PictureBox tile566;
        private System.Windows.Forms.PictureBox tile567;
        private System.Windows.Forms.PictureBox tile568;
        private System.Windows.Forms.PictureBox tile569;
        private System.Windows.Forms.PictureBox tile570;
        private System.Windows.Forms.PictureBox tile562;
        private System.Windows.Forms.PictureBox tile561;
        private System.Windows.Forms.PictureBox tile553;
        private System.Windows.Forms.PictureBox tile554;
        private System.Windows.Forms.PictureBox tile555;
        private System.Windows.Forms.PictureBox tile556;
        private System.Windows.Forms.PictureBox tile557;
        private System.Windows.Forms.PictureBox tile558;
        private System.Windows.Forms.PictureBox tile560;
        private System.Windows.Forms.PictureBox tile559;
        private System.Windows.Forms.PictureBox tile552;
        private System.Windows.Forms.PictureBox tile551;
        private System.Windows.Forms.PictureBox tile548;
        private System.Windows.Forms.PictureBox tile547;
        private System.Windows.Forms.PictureBox tile546;
        private System.Windows.Forms.PictureBox tile545;
        private System.Windows.Forms.PictureBox tile544;
        private System.Windows.Forms.PictureBox tile543;
        private System.Windows.Forms.PictureBox tile541;
        private System.Windows.Forms.PictureBox tile542;
        private System.Windows.Forms.PictureBox tile549;
        private System.Windows.Forms.PictureBox tile550;
        private System.Windows.Forms.PictureBox tile533;
        private System.Windows.Forms.PictureBox tile534;
        private System.Windows.Forms.PictureBox tile535;
        private System.Windows.Forms.PictureBox tile536;
        private System.Windows.Forms.PictureBox tile537;
        private System.Windows.Forms.PictureBox tile538;
        private System.Windows.Forms.PictureBox tile539;
        private System.Windows.Forms.PictureBox tile540;
        private System.Windows.Forms.PictureBox tile532;
        private System.Windows.Forms.PictureBox tile531;
        private System.Windows.Forms.PictureBox tile523;
        private System.Windows.Forms.PictureBox tile524;
        private System.Windows.Forms.PictureBox tile525;
        private System.Windows.Forms.PictureBox tile526;
        private System.Windows.Forms.PictureBox tile527;
        private System.Windows.Forms.PictureBox tile528;
        private System.Windows.Forms.PictureBox tile529;
        private System.Windows.Forms.PictureBox tile530;
        private System.Windows.Forms.PictureBox tile522;
        private System.Windows.Forms.PictureBox tile521;
        private System.Windows.Forms.PictureBox tile513;
        private System.Windows.Forms.PictureBox tile514;
        private System.Windows.Forms.PictureBox tile515;
        private System.Windows.Forms.PictureBox tile516;
        private System.Windows.Forms.PictureBox tile517;
        private System.Windows.Forms.PictureBox tile518;
        private System.Windows.Forms.PictureBox tile520;
        private System.Windows.Forms.PictureBox tile519;
        private System.Windows.Forms.PictureBox tile512;
        private System.Windows.Forms.PictureBox tile511;
        private System.Windows.Forms.PictureBox tile508;
        private System.Windows.Forms.PictureBox tile507;
        private System.Windows.Forms.PictureBox tile506;
        private System.Windows.Forms.PictureBox tile505;
        private System.Windows.Forms.PictureBox tile504;
        private System.Windows.Forms.PictureBox tile503;
        private System.Windows.Forms.PictureBox tile501;
        private System.Windows.Forms.PictureBox tile502;
        private System.Windows.Forms.PictureBox tile509;
        private System.Windows.Forms.PictureBox tile510;
        private System.Windows.Forms.PictureBox tile493;
        private System.Windows.Forms.PictureBox tile494;
        private System.Windows.Forms.PictureBox tile495;
        private System.Windows.Forms.PictureBox tile496;
        private System.Windows.Forms.PictureBox tile497;
        private System.Windows.Forms.PictureBox tile498;
        private System.Windows.Forms.PictureBox tile499;
        private System.Windows.Forms.PictureBox tile500;
        private System.Windows.Forms.PictureBox tile492;
        private System.Windows.Forms.PictureBox tile491;
        private System.Windows.Forms.PictureBox tile483;
        private System.Windows.Forms.PictureBox tile484;
        private System.Windows.Forms.PictureBox tile485;
        private System.Windows.Forms.PictureBox tile486;
        private System.Windows.Forms.PictureBox tile487;
        private System.Windows.Forms.PictureBox tile488;
        private System.Windows.Forms.PictureBox tile489;
        private System.Windows.Forms.PictureBox tile490;
        private System.Windows.Forms.PictureBox tile482;
        private System.Windows.Forms.PictureBox tile481;
        private System.Windows.Forms.PictureBox tile473;
        private System.Windows.Forms.PictureBox tile474;
        private System.Windows.Forms.PictureBox tile475;
        private System.Windows.Forms.PictureBox tile476;
        private System.Windows.Forms.PictureBox tile477;
        private System.Windows.Forms.PictureBox tile478;
        private System.Windows.Forms.PictureBox tile480;
        private System.Windows.Forms.PictureBox tile479;
        private System.Windows.Forms.PictureBox tile472;
        private System.Windows.Forms.PictureBox tile471;
        private System.Windows.Forms.PictureBox tile468;
        private System.Windows.Forms.PictureBox tile467;
        private System.Windows.Forms.PictureBox tile466;
        private System.Windows.Forms.PictureBox tile465;
        private System.Windows.Forms.PictureBox tile464;
        private System.Windows.Forms.PictureBox tile463;
        private System.Windows.Forms.PictureBox tile461;
        private System.Windows.Forms.PictureBox tile462;
        private System.Windows.Forms.PictureBox tile469;
        private System.Windows.Forms.PictureBox tile470;
        private System.Windows.Forms.PictureBox tile453;
        private System.Windows.Forms.PictureBox tile454;
        private System.Windows.Forms.PictureBox tile455;
        private System.Windows.Forms.PictureBox tile456;
        private System.Windows.Forms.PictureBox tile457;
        private System.Windows.Forms.PictureBox tile458;
        private System.Windows.Forms.PictureBox tile459;
        private System.Windows.Forms.PictureBox tile460;
        private System.Windows.Forms.PictureBox tile452;
        private System.Windows.Forms.PictureBox tile451;
        private System.Windows.Forms.PictureBox tile443;
        private System.Windows.Forms.PictureBox tile444;
        private System.Windows.Forms.PictureBox tile445;
        private System.Windows.Forms.PictureBox tile446;
        private System.Windows.Forms.PictureBox tile447;
        private System.Windows.Forms.PictureBox tile448;
        private System.Windows.Forms.PictureBox tile449;
        private System.Windows.Forms.PictureBox tile450;
        private System.Windows.Forms.PictureBox tile442;
        private System.Windows.Forms.PictureBox tile441;
        private System.Windows.Forms.PictureBox tile433;
        private System.Windows.Forms.PictureBox tile434;
        private System.Windows.Forms.PictureBox tile435;
        private System.Windows.Forms.PictureBox tile436;
        private System.Windows.Forms.PictureBox tile437;
        private System.Windows.Forms.PictureBox tile438;
        private System.Windows.Forms.PictureBox tile440;
        private System.Windows.Forms.PictureBox tile439;
        private System.Windows.Forms.PictureBox tile432;
        private System.Windows.Forms.PictureBox tile431;
        private System.Windows.Forms.PictureBox tile428;
        private System.Windows.Forms.PictureBox tile427;
        private System.Windows.Forms.PictureBox tile425;
        private System.Windows.Forms.PictureBox tile424;
        private System.Windows.Forms.PictureBox tile423;
        private System.Windows.Forms.PictureBox tile421;
        private System.Windows.Forms.PictureBox tile422;
        private System.Windows.Forms.PictureBox tile429;
        private System.Windows.Forms.PictureBox tile430;
        private System.Windows.Forms.PictureBox tile413;
        private System.Windows.Forms.PictureBox tile414;
        private System.Windows.Forms.PictureBox tile415;
        private System.Windows.Forms.PictureBox tile416;
        private System.Windows.Forms.PictureBox tile417;
        private System.Windows.Forms.PictureBox tile418;
        private System.Windows.Forms.PictureBox tile419;
        private System.Windows.Forms.PictureBox tile420;
        private System.Windows.Forms.PictureBox tile412;
        private System.Windows.Forms.PictureBox tile411;
        private System.Windows.Forms.PictureBox tile403;
        private System.Windows.Forms.PictureBox tile404;
        private System.Windows.Forms.PictureBox tile405;
        private System.Windows.Forms.PictureBox tile406;
        private System.Windows.Forms.PictureBox tile407;
        private System.Windows.Forms.PictureBox tile408;
        private System.Windows.Forms.PictureBox tile409;
        private System.Windows.Forms.PictureBox tile410;
        private System.Windows.Forms.PictureBox tile402;
        private System.Windows.Forms.PictureBox tile401;
        private System.Windows.Forms.PictureBox tile394;
        private System.Windows.Forms.PictureBox tile395;
        private System.Windows.Forms.PictureBox tile396;
        private System.Windows.Forms.PictureBox tile397;
        private System.Windows.Forms.PictureBox tile398;
        private System.Windows.Forms.PictureBox tile400;
        private System.Windows.Forms.PictureBox tile399;
        private System.Windows.Forms.PictureBox tile392;
        private System.Windows.Forms.PictureBox tile391;
        private System.Windows.Forms.PictureBox tile388;
        private System.Windows.Forms.PictureBox tile387;
        private System.Windows.Forms.PictureBox tile386;
        private System.Windows.Forms.PictureBox tile385;
        private System.Windows.Forms.PictureBox tile384;
        private System.Windows.Forms.PictureBox tile383;
        private System.Windows.Forms.PictureBox tile381;
        private System.Windows.Forms.PictureBox tile382;
        private System.Windows.Forms.PictureBox tile390;
        private System.Windows.Forms.PictureBox tile373;
        private System.Windows.Forms.PictureBox tile374;
        private System.Windows.Forms.PictureBox tile375;
        private System.Windows.Forms.PictureBox tile376;
        private System.Windows.Forms.PictureBox tile377;
        private System.Windows.Forms.PictureBox tile378;
        private System.Windows.Forms.PictureBox tile379;
        private System.Windows.Forms.PictureBox tile380;
        private System.Windows.Forms.PictureBox tile372;
        private System.Windows.Forms.PictureBox tile371;
        private System.Windows.Forms.PictureBox tile363;
        private System.Windows.Forms.PictureBox tile364;
        private System.Windows.Forms.PictureBox tile365;
        private System.Windows.Forms.PictureBox tile366;
        private System.Windows.Forms.PictureBox tile367;
        private System.Windows.Forms.PictureBox tile368;
        private System.Windows.Forms.PictureBox tile369;
        private System.Windows.Forms.PictureBox tile370;
        private System.Windows.Forms.PictureBox tile362;
        private System.Windows.Forms.PictureBox tile361;
        private System.Windows.Forms.PictureBox tile353;
        private System.Windows.Forms.PictureBox tile354;
        private System.Windows.Forms.PictureBox tile355;
        private System.Windows.Forms.PictureBox tile356;
        private System.Windows.Forms.PictureBox tile357;
        private System.Windows.Forms.PictureBox tile358;
        private System.Windows.Forms.PictureBox tile360;
        private System.Windows.Forms.PictureBox tile359;
        private System.Windows.Forms.PictureBox tile352;
        private System.Windows.Forms.PictureBox tile351;
        private System.Windows.Forms.PictureBox tile348;
        private System.Windows.Forms.PictureBox tile347;
        private System.Windows.Forms.PictureBox tile346;
        private System.Windows.Forms.PictureBox tile345;
        private System.Windows.Forms.PictureBox tile344;
        private System.Windows.Forms.PictureBox tile343;
        private System.Windows.Forms.PictureBox tile341;
        private System.Windows.Forms.PictureBox tile342;
        private System.Windows.Forms.PictureBox tile349;
        private System.Windows.Forms.PictureBox tile350;
        private System.Windows.Forms.PictureBox tile333;
        private System.Windows.Forms.PictureBox tile334;
        private System.Windows.Forms.PictureBox tile335;
        private System.Windows.Forms.PictureBox tile336;
        private System.Windows.Forms.PictureBox tile337;
        private System.Windows.Forms.PictureBox tile338;
        private System.Windows.Forms.PictureBox tile340;
        private System.Windows.Forms.PictureBox tile332;
        private System.Windows.Forms.PictureBox tile331;
        private System.Windows.Forms.PictureBox tile323;
        private System.Windows.Forms.PictureBox tile324;
        private System.Windows.Forms.PictureBox tile325;
        private System.Windows.Forms.PictureBox tile326;
        private System.Windows.Forms.PictureBox tile327;
        private System.Windows.Forms.PictureBox tile328;
        private System.Windows.Forms.PictureBox tile329;
        private System.Windows.Forms.PictureBox tile330;
        private System.Windows.Forms.PictureBox tile322;
        private System.Windows.Forms.PictureBox tile321;
        private System.Windows.Forms.PictureBox tile313;
        private System.Windows.Forms.PictureBox tile314;
        private System.Windows.Forms.PictureBox tile315;
        private System.Windows.Forms.PictureBox tile316;
        private System.Windows.Forms.PictureBox tile317;
        private System.Windows.Forms.PictureBox tile318;
        private System.Windows.Forms.PictureBox tile320;
        private System.Windows.Forms.PictureBox tile319;
        private System.Windows.Forms.PictureBox tile312;
        private System.Windows.Forms.PictureBox tile311;
        private System.Windows.Forms.PictureBox tile308;
        private System.Windows.Forms.PictureBox tile307;
        private System.Windows.Forms.PictureBox tile306;
        private System.Windows.Forms.PictureBox tile305;
        private System.Windows.Forms.PictureBox tile304;
        private System.Windows.Forms.PictureBox tile303;
        private System.Windows.Forms.PictureBox tile301;
        private System.Windows.Forms.PictureBox tile302;
        private System.Windows.Forms.PictureBox tile309;
        private System.Windows.Forms.PictureBox tile310;
        private System.Windows.Forms.PictureBox tile293;
        private System.Windows.Forms.PictureBox tile294;
        private System.Windows.Forms.PictureBox tile295;
        private System.Windows.Forms.PictureBox tile296;
        private System.Windows.Forms.PictureBox tile297;
        private System.Windows.Forms.PictureBox tile298;
        private System.Windows.Forms.PictureBox tile299;
        private System.Windows.Forms.PictureBox tile300;
        private System.Windows.Forms.PictureBox tile292;
        private System.Windows.Forms.PictureBox tile291;
        private System.Windows.Forms.PictureBox tile283;
        private System.Windows.Forms.PictureBox tile285;
        private System.Windows.Forms.PictureBox tile286;
        private System.Windows.Forms.PictureBox tile287;
        private System.Windows.Forms.PictureBox tile288;
        private System.Windows.Forms.PictureBox tile289;
        private System.Windows.Forms.PictureBox tile290;
        private System.Windows.Forms.PictureBox tile282;
        private System.Windows.Forms.PictureBox tile281;
        private System.Windows.Forms.PictureBox tile273;
        private System.Windows.Forms.PictureBox tile274;
        private System.Windows.Forms.PictureBox tile275;
        private System.Windows.Forms.PictureBox tile276;
        private System.Windows.Forms.PictureBox tile277;
        private System.Windows.Forms.PictureBox tile278;
        private System.Windows.Forms.PictureBox tile280;
        private System.Windows.Forms.PictureBox tile279;
        private System.Windows.Forms.PictureBox tile272;
        private System.Windows.Forms.PictureBox tile271;
        private System.Windows.Forms.PictureBox tile268;
        private System.Windows.Forms.PictureBox tile267;
        private System.Windows.Forms.PictureBox tile266;
        private System.Windows.Forms.PictureBox tile265;
        private System.Windows.Forms.PictureBox tile264;
        private System.Windows.Forms.PictureBox tile263;
        private System.Windows.Forms.PictureBox tile261;
        private System.Windows.Forms.PictureBox tile262;
        private System.Windows.Forms.PictureBox tile269;
        private System.Windows.Forms.PictureBox tile270;
        private System.Windows.Forms.PictureBox tile253;
        private System.Windows.Forms.PictureBox tile254;
        private System.Windows.Forms.PictureBox tile255;
        private System.Windows.Forms.PictureBox tile256;
        private System.Windows.Forms.PictureBox tile257;
        private System.Windows.Forms.PictureBox tile258;
        private System.Windows.Forms.PictureBox tile259;
        private System.Windows.Forms.PictureBox tile260;
        private System.Windows.Forms.PictureBox tile252;
        private System.Windows.Forms.PictureBox tile251;
        private System.Windows.Forms.PictureBox tile243;
        private System.Windows.Forms.PictureBox tile244;
        private System.Windows.Forms.PictureBox tile246;
        private System.Windows.Forms.PictureBox tile247;
        private System.Windows.Forms.PictureBox tile248;
        private System.Windows.Forms.PictureBox tile249;
        private System.Windows.Forms.PictureBox tile250;
        private System.Windows.Forms.PictureBox tile242;
        private System.Windows.Forms.PictureBox tile241;
        private System.Windows.Forms.PictureBox tile233;
        private System.Windows.Forms.PictureBox tile234;
        private System.Windows.Forms.PictureBox tile235;
        private System.Windows.Forms.PictureBox tile236;
        private System.Windows.Forms.PictureBox tile237;
        private System.Windows.Forms.PictureBox tile238;
        private System.Windows.Forms.PictureBox tile240;
        private System.Windows.Forms.PictureBox tile239;
        private System.Windows.Forms.PictureBox tile232;
        private System.Windows.Forms.PictureBox tile231;
        private System.Windows.Forms.PictureBox tile228;
        private System.Windows.Forms.PictureBox tile227;
        private System.Windows.Forms.PictureBox tile226;
        private System.Windows.Forms.PictureBox tile225;
        private System.Windows.Forms.PictureBox tile224;
        private System.Windows.Forms.PictureBox tile223;
        private System.Windows.Forms.PictureBox tile221;
        private System.Windows.Forms.PictureBox tile222;
        private System.Windows.Forms.PictureBox tile229;
        private System.Windows.Forms.PictureBox tile213;
        private System.Windows.Forms.PictureBox tile214;
        private System.Windows.Forms.PictureBox tile215;
        private System.Windows.Forms.PictureBox tile216;
        private System.Windows.Forms.PictureBox tile217;
        private System.Windows.Forms.PictureBox tile218;
        private System.Windows.Forms.PictureBox tile219;
        private System.Windows.Forms.PictureBox tile220;
        private System.Windows.Forms.PictureBox tile212;
        private System.Windows.Forms.PictureBox tile211;
        private System.Windows.Forms.PictureBox tile203;
        private System.Windows.Forms.PictureBox tile204;
        private System.Windows.Forms.PictureBox tile205;
        private System.Windows.Forms.PictureBox tile206;
        private System.Windows.Forms.PictureBox tile207;
        private System.Windows.Forms.PictureBox tile208;
        private System.Windows.Forms.PictureBox tile209;
        private System.Windows.Forms.PictureBox tile210;
        private System.Windows.Forms.PictureBox tile202;
        private System.Windows.Forms.PictureBox tile201;
        private System.Windows.Forms.PictureBox tile193;
        private System.Windows.Forms.PictureBox tile194;
        private System.Windows.Forms.PictureBox tile195;
        private System.Windows.Forms.PictureBox tile196;
        private System.Windows.Forms.PictureBox tile197;
        private System.Windows.Forms.PictureBox tile198;
        private System.Windows.Forms.PictureBox tile200;
        private System.Windows.Forms.PictureBox tile199;
        private System.Windows.Forms.PictureBox tile192;
        private System.Windows.Forms.PictureBox tile191;
        private System.Windows.Forms.PictureBox tile188;
        private System.Windows.Forms.PictureBox tile187;
        private System.Windows.Forms.PictureBox tile186;
        private System.Windows.Forms.PictureBox tile185;
        private System.Windows.Forms.PictureBox tile184;
        private System.Windows.Forms.PictureBox tile183;
        private System.Windows.Forms.PictureBox tile181;
        private System.Windows.Forms.PictureBox tile182;
        private System.Windows.Forms.PictureBox tile189;
        private System.Windows.Forms.PictureBox tile190;
        private System.Windows.Forms.PictureBox tile174;
        private System.Windows.Forms.PictureBox tile175;
        private System.Windows.Forms.PictureBox tile176;
        private System.Windows.Forms.PictureBox tile177;
        private System.Windows.Forms.PictureBox tile178;
        private System.Windows.Forms.PictureBox tile179;
        private System.Windows.Forms.PictureBox tile180;
        private System.Windows.Forms.PictureBox tile172;
        private System.Windows.Forms.PictureBox tile171;
        private System.Windows.Forms.PictureBox tile163;
        private System.Windows.Forms.PictureBox tile164;
        private System.Windows.Forms.PictureBox tile166;
        private System.Windows.Forms.PictureBox tile167;
        private System.Windows.Forms.PictureBox tile168;
        private System.Windows.Forms.PictureBox tile169;
        private System.Windows.Forms.PictureBox tile170;
        private System.Windows.Forms.PictureBox tile162;
        private System.Windows.Forms.PictureBox tile161;
        private System.Windows.Forms.PictureBox tile153;
        private System.Windows.Forms.PictureBox tile154;
        private System.Windows.Forms.PictureBox tile155;
        private System.Windows.Forms.PictureBox tile156;
        private System.Windows.Forms.PictureBox tile157;
        private System.Windows.Forms.PictureBox tile158;
        private System.Windows.Forms.PictureBox tile160;
        private System.Windows.Forms.PictureBox tile159;
        private System.Windows.Forms.PictureBox tile152;
        private System.Windows.Forms.PictureBox tile151;
        private System.Windows.Forms.PictureBox tile148;
        private System.Windows.Forms.PictureBox tile147;
        private System.Windows.Forms.PictureBox tile146;
        private System.Windows.Forms.PictureBox tile145;
        private System.Windows.Forms.PictureBox tile144;
        private System.Windows.Forms.PictureBox tile143;
        private System.Windows.Forms.PictureBox tile141;
        private System.Windows.Forms.PictureBox tile142;
        private System.Windows.Forms.PictureBox tile149;
        private System.Windows.Forms.PictureBox tile150;
        private System.Windows.Forms.PictureBox tile133;
        private System.Windows.Forms.PictureBox tile134;
        private System.Windows.Forms.PictureBox tile135;
        private System.Windows.Forms.PictureBox tile136;
        private System.Windows.Forms.PictureBox tile137;
        private System.Windows.Forms.PictureBox tile138;
        private System.Windows.Forms.PictureBox tile139;
        private System.Windows.Forms.PictureBox tile140;
        private System.Windows.Forms.PictureBox tile132;
        private System.Windows.Forms.PictureBox tile131;
        private System.Windows.Forms.PictureBox tile123;
        private System.Windows.Forms.PictureBox tile124;
        private System.Windows.Forms.PictureBox tile125;
        private System.Windows.Forms.PictureBox tile126;
        private System.Windows.Forms.PictureBox tile127;
        private System.Windows.Forms.PictureBox tile128;
        private System.Windows.Forms.PictureBox tile129;
        private System.Windows.Forms.PictureBox tile130;
        private System.Windows.Forms.PictureBox tile122;
        private System.Windows.Forms.PictureBox tile121;
        private System.Windows.Forms.PictureBox tile113;
        private System.Windows.Forms.PictureBox tile114;
        private System.Windows.Forms.PictureBox tile115;
        private System.Windows.Forms.PictureBox tile116;
        private System.Windows.Forms.PictureBox tile117;
        private System.Windows.Forms.PictureBox tile118;
        private System.Windows.Forms.PictureBox tile120;
        private System.Windows.Forms.PictureBox tile119;
        private System.Windows.Forms.PictureBox tile112;
        private System.Windows.Forms.PictureBox tile111;
        private System.Windows.Forms.PictureBox tile108;
        private System.Windows.Forms.PictureBox tile107;
        private System.Windows.Forms.PictureBox tile106;
        private System.Windows.Forms.PictureBox tile105;
        private System.Windows.Forms.PictureBox tile104;
        private System.Windows.Forms.PictureBox tile103;
        private System.Windows.Forms.PictureBox tile101;
        private System.Windows.Forms.PictureBox tile102;
        private System.Windows.Forms.PictureBox tile109;
        private System.Windows.Forms.PictureBox tile110;
        private System.Windows.Forms.PictureBox tile93;
        private System.Windows.Forms.PictureBox tile94;
        private System.Windows.Forms.PictureBox tile95;
        private System.Windows.Forms.PictureBox tile96;
        private System.Windows.Forms.PictureBox tile97;
        private System.Windows.Forms.PictureBox tile98;
        private System.Windows.Forms.PictureBox tile99;
        private System.Windows.Forms.PictureBox tile100;
        private System.Windows.Forms.PictureBox tile92;
        private System.Windows.Forms.PictureBox tile91;
        private System.Windows.Forms.PictureBox tile83;
        private System.Windows.Forms.PictureBox tile84;
        private System.Windows.Forms.PictureBox tile85;
        private System.Windows.Forms.PictureBox tile86;
        private System.Windows.Forms.PictureBox tile87;
        private System.Windows.Forms.PictureBox tile88;
        private System.Windows.Forms.PictureBox tile89;
        private System.Windows.Forms.PictureBox tile90;
        private System.Windows.Forms.PictureBox tile82;
        private System.Windows.Forms.PictureBox tile81;
        private System.Windows.Forms.PictureBox tile73;
        private System.Windows.Forms.PictureBox tile74;
        private System.Windows.Forms.PictureBox tile75;
        private System.Windows.Forms.PictureBox tile76;
        private System.Windows.Forms.PictureBox tile77;
        private System.Windows.Forms.PictureBox tile78;
        private System.Windows.Forms.PictureBox tile80;
        private System.Windows.Forms.PictureBox tile79;
        private System.Windows.Forms.PictureBox tile72;
        private System.Windows.Forms.PictureBox tile71;
        private System.Windows.Forms.PictureBox tile68;
        private System.Windows.Forms.PictureBox tile67;
        private System.Windows.Forms.PictureBox tile66;
        private System.Windows.Forms.PictureBox tile65;
        private System.Windows.Forms.PictureBox tile64;
        private System.Windows.Forms.PictureBox tile63;
        private System.Windows.Forms.PictureBox tile61;
        private System.Windows.Forms.PictureBox tile62;
        private System.Windows.Forms.PictureBox tile69;
        private System.Windows.Forms.PictureBox tile70;
        private System.Windows.Forms.PictureBox tile53;
        private System.Windows.Forms.PictureBox tile54;
        private System.Windows.Forms.PictureBox tile55;
        private System.Windows.Forms.PictureBox tile56;
        private System.Windows.Forms.PictureBox tile57;
        private System.Windows.Forms.PictureBox tile58;
        private System.Windows.Forms.PictureBox tile59;
        private System.Windows.Forms.PictureBox tile60;
        private System.Windows.Forms.PictureBox tile52;
        private System.Windows.Forms.PictureBox tile51;
        private System.Windows.Forms.PictureBox tile43;
        private System.Windows.Forms.PictureBox tile44;
        private System.Windows.Forms.PictureBox tile45;
        private System.Windows.Forms.PictureBox tile46;
        private System.Windows.Forms.PictureBox tile47;
        private System.Windows.Forms.PictureBox tile48;
        private System.Windows.Forms.PictureBox tile49;
        private System.Windows.Forms.PictureBox tile50;
        private System.Windows.Forms.PictureBox tile42;
        private System.Windows.Forms.PictureBox tile41;
        private System.Windows.Forms.PictureBox tile33;
        private System.Windows.Forms.PictureBox tile34;
        private System.Windows.Forms.PictureBox tile35;
        private System.Windows.Forms.PictureBox tile36;
        private System.Windows.Forms.PictureBox tile37;
        private System.Windows.Forms.PictureBox tile38;
        private System.Windows.Forms.PictureBox tile40;
        private System.Windows.Forms.PictureBox tile39;
        private System.Windows.Forms.PictureBox tile32;
        private System.Windows.Forms.PictureBox tile31;
        private System.Windows.Forms.PictureBox tile28;
        private System.Windows.Forms.PictureBox tile27;
        private System.Windows.Forms.PictureBox tile26;
        private System.Windows.Forms.PictureBox tile25;
        private System.Windows.Forms.PictureBox tile24;
        private System.Windows.Forms.PictureBox tile23;
        private System.Windows.Forms.PictureBox tile21;
        private System.Windows.Forms.PictureBox tile22;
        private System.Windows.Forms.PictureBox tile29;
        private System.Windows.Forms.PictureBox tile30;
        private System.Windows.Forms.PictureBox tile13;
        private System.Windows.Forms.PictureBox tile14;
        private System.Windows.Forms.PictureBox tile15;
        private System.Windows.Forms.PictureBox tile16;
        private System.Windows.Forms.PictureBox tile17;
        private System.Windows.Forms.PictureBox tile18;
        private System.Windows.Forms.PictureBox tile19;
        private System.Windows.Forms.PictureBox tile20;
        private System.Windows.Forms.PictureBox tile12;
        private System.Windows.Forms.PictureBox tile11;
        private System.Windows.Forms.PictureBox tile3;
        private System.Windows.Forms.PictureBox tile4;
        private System.Windows.Forms.PictureBox tile5;
        private System.Windows.Forms.PictureBox tile6;
        private System.Windows.Forms.PictureBox tile7;
        private System.Windows.Forms.PictureBox tile8;
        private System.Windows.Forms.PictureBox tile9;
        private System.Windows.Forms.PictureBox tile10;
        private System.Windows.Forms.PictureBox tile2;
        private System.Windows.Forms.PictureBox tile1;
        private System.Diagnostics.Process process1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox tile165;
        private System.Windows.Forms.PictureBox tile173;
        private System.Windows.Forms.PictureBox tile230;
        private System.Windows.Forms.PictureBox tile245;
        private System.Windows.Forms.PictureBox tile284;
        private System.Windows.Forms.PictureBox tile339;
        private System.Windows.Forms.PictureBox tile389;
        private System.Windows.Forms.PictureBox tile393;
        private System.Windows.Forms.PictureBox tile426;
        private System.Windows.Forms.PictureBox tile606;
        private System.Windows.Forms.PictureBox tile620;
        private System.Windows.Forms.PictureBox tile642;
        private System.Windows.Forms.PictureBox tile654;
        private System.Windows.Forms.PictureBox tile663;
        private System.Windows.Forms.PictureBox tile675;
        private System.Windows.Forms.PictureBox tile676;
        private System.Windows.Forms.PictureBox tile690;
        private System.Windows.Forms.PictureBox tile702;
        private System.Windows.Forms.PictureBox tile764;
        private System.Windows.Forms.PictureBox tile783;
        private System.Windows.Forms.Label labelSaveName;
        private System.Windows.Forms.TextBox levelNameBox;
        private System.Windows.Forms.GroupBox groupBoxInstructions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox tile873;
        private System.Windows.Forms.PictureBox tile874;
        private System.Windows.Forms.PictureBox tile875;
        private System.Windows.Forms.PictureBox tile876;
        private System.Windows.Forms.PictureBox tile877;
        private System.Windows.Forms.PictureBox tile878;
        private System.Windows.Forms.PictureBox tile880;
        private System.Windows.Forms.PictureBox tile879;
        private System.Windows.Forms.PictureBox tile872;
        private System.Windows.Forms.PictureBox tile871;
        private System.Windows.Forms.PictureBox tile868;
        private System.Windows.Forms.PictureBox tile867;
        private System.Windows.Forms.PictureBox tile866;
        private System.Windows.Forms.PictureBox tile865;
        private System.Windows.Forms.PictureBox tile864;
        private System.Windows.Forms.PictureBox tile863;
        private System.Windows.Forms.PictureBox tile861;
        private System.Windows.Forms.PictureBox tile862;
        private System.Windows.Forms.PictureBox tile869;
        private System.Windows.Forms.PictureBox tile870;
        private System.Windows.Forms.PictureBox tile853;
        private System.Windows.Forms.PictureBox tile854;
        private System.Windows.Forms.PictureBox tile855;
        private System.Windows.Forms.PictureBox tile856;
        private System.Windows.Forms.PictureBox tile857;
        private System.Windows.Forms.PictureBox tile858;
        private System.Windows.Forms.PictureBox tile859;
        private System.Windows.Forms.PictureBox tile860;
        private System.Windows.Forms.PictureBox tile852;
        private System.Windows.Forms.PictureBox tile851;
        private System.Windows.Forms.PictureBox tile843;
        private System.Windows.Forms.PictureBox tile844;
        private System.Windows.Forms.PictureBox tile845;
        private System.Windows.Forms.PictureBox tile846;
        private System.Windows.Forms.PictureBox tile847;
        private System.Windows.Forms.PictureBox tile848;
        private System.Windows.Forms.PictureBox tile849;
        private System.Windows.Forms.PictureBox tile850;
        private System.Windows.Forms.PictureBox tile842;
        private System.Windows.Forms.PictureBox tile841;
        private System.Windows.Forms.PictureBox tile833;
        private System.Windows.Forms.PictureBox tile834;
        private System.Windows.Forms.PictureBox tile835;
        private System.Windows.Forms.PictureBox tile836;
        private System.Windows.Forms.PictureBox tile837;
        private System.Windows.Forms.PictureBox tile838;
        private System.Windows.Forms.PictureBox tile840;
        private System.Windows.Forms.PictureBox tile839;
        private System.Windows.Forms.PictureBox tile832;
        private System.Windows.Forms.PictureBox tile831;
        private System.Windows.Forms.PictureBox tile828;
        private System.Windows.Forms.PictureBox tile827;
        private System.Windows.Forms.PictureBox tile826;
        private System.Windows.Forms.PictureBox tile825;
        private System.Windows.Forms.PictureBox tile824;
        private System.Windows.Forms.PictureBox tile823;
        private System.Windows.Forms.PictureBox tile821;
        private System.Windows.Forms.PictureBox tile822;
        private System.Windows.Forms.PictureBox tile829;
        private System.Windows.Forms.PictureBox tile830;
        private System.Windows.Forms.PictureBox tile813;
        private System.Windows.Forms.PictureBox tile814;
        private System.Windows.Forms.PictureBox tile815;
        private System.Windows.Forms.PictureBox tile816;
        private System.Windows.Forms.PictureBox tile817;
        private System.Windows.Forms.PictureBox tile818;
        private System.Windows.Forms.PictureBox tile819;
        private System.Windows.Forms.PictureBox tile820;
        private System.Windows.Forms.PictureBox tile812;
        private System.Windows.Forms.PictureBox tile811;
        private System.Windows.Forms.PictureBox tile803;
        private System.Windows.Forms.PictureBox tile804;
        private System.Windows.Forms.PictureBox tile805;
        private System.Windows.Forms.PictureBox tile806;
        private System.Windows.Forms.PictureBox tile807;
        private System.Windows.Forms.PictureBox tile808;
        private System.Windows.Forms.PictureBox tile809;
        private System.Windows.Forms.PictureBox tile810;
        private System.Windows.Forms.PictureBox tile802;
        private System.Windows.Forms.PictureBox tile801;
    }
}

