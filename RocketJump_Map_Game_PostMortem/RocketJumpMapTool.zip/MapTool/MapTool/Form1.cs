﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MapTool
{
    /*Purpose: To create a GUI for generating map files for the game Rocket Jump.
     *The user clicks on a color, and then clicks a square to paint it the designated color.
     *When the save button is pressed, the user is prompted for a name for the file, and then 
     *the squares are processed into various characters, explained in the buttonSave_Click event code.
     *This allows us to expediate design, while also allowing easy creation and replication of possible bug situations
     *The map editor is currently feature complete for what is implemented in Rocket Jump as of 4/3/15.  However, as new features are 
     *added in, new colors can be easily added and the code systematically changed.
     *
     * Writers: Robert and Kenny
     * Date: 4/3/15
    */
    public partial class Form1 : Form
    {
        Color mouseColor;

        // array of tiles
        PictureBox[] tiles = new PictureBox[880];

        public Form1()
        {
            InitializeComponent();
            mouseColor = Color.White;
            levelNameBox.Text = null;
            // populate tiles array
            int n = 0;

            // simplistic event handler for all tiles to follow
            foreach (PictureBox tile in editor.Controls)
            {
                string name = tile.Name;
                int length = name.Length;
                string s = name.Substring(4);
                Boolean parse = int.TryParse(s, out n);
                tiles[n-1] = tile;
            }

            // border of black tiles, as to not roam free around map
            for (int i = 0; i < 41; i++ )
            {
                tiles[i].BackColor = Color.Black;
                tiles[879 - i].BackColor = Color.Black;
            }
            for (int j = 0; j < 20; j++)
            {
              tiles[40 * j].BackColor = Color.Black;
              tiles[879 - (40 * j)].BackColor = Color.Black;
            }

            tiles[79].BackColor = Color.Black;
            tiles[800].BackColor = Color.Black;


                // set events
                foreach (Object obj in editor.Controls) // get each control on the form
                {
                    if (obj is PictureBox) // see if it's a PictureBox
                    {

                        PictureBox pbox = (PictureBox)obj; // cast it as a PictureBox
                        // adding the event handler to the PictureBox
                        pbox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tile2_MouseClick);
                    }
                }

                timer1.Start();
        }

        private void labelLedge_Click(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }

        private void groupBoxKey_Enter(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }

        private void pictureBox390_Click(object sender, EventArgs e)
        {
            //placeHolder, accidental double-click
        }

        private void t_Click(object sender, EventArgs e)
        {
            //placeHolder, accidental double-click
        }

        // Clear button, change all tiles to white except the boarder
        private void buttonClear_Click(object sender, EventArgs e)
        {
            foreach (PictureBox tile in tiles)
            {
                tile.BackColor = Color.White;
            }

            // border of black tiles, as to not allow the player to roam free around the map
            for (int i = 0; i < 41; i++)
            {
              tiles[i].BackColor = Color.Black;
              tiles[879 - i].BackColor = Color.Black;
            }
            for (int j = 0; j < 20; j++)
            {
                tiles[40 * j].BackColor = Color.Black;
                tiles[879 - (40 * j)].BackColor = Color.Black;
            }

            tiles[79].BackColor = Color.Black;
            tiles[800].BackColor = Color.Black;
        }

        // method for all tiles on the map editor, changes color according to color selected from reference
        public void tilePaint(PictureBox t)
        {
            
            PictureBox oldTile = referenceBlank;
            
            // first, check for already existing player spawn, then replace if already there
            if(mouseColor == Color.Aqua)
            {
                //This is to prevent multiple player spawns creating issues, and to insure that the level is designed
                //with only one player in mind
                Boolean alreadyBlue = false ;
                foreach(PictureBox tile in tiles)
                {
                    if(tile.BackColor == Color.Aqua)
                    {
                        string tileNum = tile.Name;
                        alreadyBlue = true;
                        oldTile = tile;
                        break;
                    }

                }
                if (alreadyBlue)
                {
                    oldTile.BackColor = Color.White;
                    alreadyBlue = false;
                }
            }
            // will color the chosen tile
            t.BackColor = mouseColor;

        }

        // access to choosing a color from the reference
        public void colorPick(PictureBox t)
        {
            mouseColor = t.BackColor;
        }

        
        private void tile1_Click(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }


        // CHANGING COLOR PICK BY CLICKING REFERENCE PICTUREBOX
        //Player (Aqua box)
        private void referencePlayer_Click(object sender, EventArgs e)
        {
            colorPick(referencePlayer);
            labelPlayer.ForeColor = Color.YellowGreen;
            labelFloor.ForeColor = Control.DefaultForeColor;
            labelLedge.ForeColor = Control.DefaultForeColor;
            labelEnemy.ForeColor = Control.DefaultForeColor;
            labelBlank.ForeColor = Control.DefaultForeColor;
        }
        //Enemy(Red box)
        private void referenceEnemy_Click(object sender, EventArgs e)
        {
            colorPick(referenceEnemy);
            labelPlayer.ForeColor = Control.DefaultForeColor;
            labelFloor.ForeColor = Control.DefaultForeColor;
            labelLedge.ForeColor = Control.DefaultForeColor;
            labelEnemy.ForeColor = Color.YellowGreen;
            labelBlank.ForeColor = Control.DefaultForeColor;
        }
        //Floor (black box)
        private void referenceFloor_Click(object sender, EventArgs e)
        {
            colorPick(referenceFloor);
            labelPlayer.ForeColor = Control.DefaultForeColor;
            labelFloor.ForeColor = Color.YellowGreen;
            labelLedge.ForeColor = Control.DefaultForeColor;
            labelEnemy.ForeColor = Control.DefaultForeColor;
            labelBlank.ForeColor = Control.DefaultForeColor;
        }
        //Ledge (Yellow box)
        private void referenceLedge_Click(object sender, EventArgs e)
        {
            colorPick(referenceLedge);
            labelPlayer.ForeColor = Control.DefaultForeColor;
            labelFloor.ForeColor = Control.DefaultForeColor;
            labelLedge.ForeColor = Color.YellowGreen;
            labelEnemy.ForeColor = Control.DefaultForeColor;
            labelBlank.ForeColor = Control.DefaultForeColor;
        }
        //Space (white box)
        private void referenceBlank_Click(object sender, EventArgs e)
        {
            colorPick(referenceBlank);
            labelPlayer.ForeColor = Control.DefaultForeColor;
            labelFloor.ForeColor = Control.DefaultForeColor;
            labelLedge.ForeColor = Control.DefaultForeColor;
            labelEnemy.ForeColor = Control.DefaultForeColor;
            labelBlank.ForeColor = Color.YellowGreen;
        }

        // SAVE BUTTON CLICKED, CREATES A FILE, splits up into 40 rows, 20 columns
        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (levelNameBox.Text.Length == 0)
                {
                    //Requires a level name
                    MessageBox.Show("No Level Name Entered, please name your level!", "Error: No Name!");
                    return;
                }

                StreamWriter writer = new StreamWriter(levelNameBox.Text + ".txt");
                int n = 0;

                foreach (PictureBox tile in tiles)
                {
                    Color color = tile.BackColor;

                    // player spawn
                    if (color == referencePlayer.BackColor)
                    {
                        writer.Write("P");
                        n++;
                        if (n == 40)
                        {
                            n = 0;
                            writer.WriteLine();
                        }
                    }

                    // enemy spawn
                    if (color == referenceEnemy.BackColor)
                    {
                        writer.Write("E");
                        n++;
                        if (n == 40)
                        {
                            n = 0;
                            writer.WriteLine();
                        }
                    }

                    // floor spawn
                    if (color == referenceFloor.BackColor)
                    {
                        writer.Write("#");
                        n++;
                        if (n == 40)
                        {
                            n = 0;
                            writer.WriteLine();
                        }
                    }

                    //ledge spawn
                    if (color == referenceLedge.BackColor)
                    {
                        writer.Write("-");
                        n++;
                        if (n == 40)
                        {
                            n = 0;
                            writer.WriteLine();
                        }
                    }

                    // spawn nothing
                    if (color == referenceBlank.BackColor)
                    {
                        writer.Write(" ");
                        n++;
                        if (n == 40)
                        {
                            n = 0;
                            writer.WriteLine();
                        }
                    }
                }

                MessageBox.Show("Level correctly saved as " + levelNameBox.Text + ".txt", "Level Saved!");

                writer.Close();
            }
                // catch any IOException
            catch (IOException ioe)
            {
                MessageBox.Show("Error: IOException " + ioe.Message, "IOException");
            }
        }

        private void tile2_Click(object sender, EventArgs e)
        {
            //placeholder, accidental double-click
        }


        // event handler for all PictureBoxes to follow, excluding the reference PictureBoxes
        private void tile2_MouseClick(object sender, MouseEventArgs e)
        {
            // get the sender as a PictureBox
            PictureBox pbox = (PictureBox)sender;

            tilePaint(pbox);
        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            // placeholder, accidental double-click
        }

        // every tick, the pictureBoxMouse will move and change color to the specified location, based on the mouse.
        private void timer1_Tick(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }

        private void editor_Enter(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }

        private void labelSaveName_Click(object sender, EventArgs e)
        {
            // placeholder, accidental double-click
        }
      
    }
}
